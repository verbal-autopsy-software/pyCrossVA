#' CrossVA
#' @param csv_inputfile Path to a csv file with records
#' @param csv_outputfile Path to a file to write transformed data to.
#' @return A csv file, with the VA records mapped to the variables required by a coding algorithm, as specified in the mapping file.
#' @import reticulate
#' @export

map_records_insilicova <- function(csv_inputfile, csv_outputfile) {

  data <- read.csv(csv_inputfile, check.names = FALSE)
  data2 <- apply(data, 2, function(x) x <- replace(x, is.na(x), "0.001"))
  write.csv(data2, file =(csv_inputfile))

  path <- paste(system.file(package="CrossVApy"), "InsilicoVA.py", sep="/")
  source_python(path)
  source(csv_inputfile, csv_outputfile)
}

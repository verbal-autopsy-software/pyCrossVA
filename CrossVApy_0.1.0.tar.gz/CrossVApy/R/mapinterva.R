#' CrossVA
#' @param csv_inputfile Path to a csv file with records
#' @param csv_outputfile Path to a file to write transformed data to.
#' @return A csv file, with the VA records mapped to the variables required by a coding algorithm, as specified in the mapping file.
#' @import reticulate
#' @export

map_records_interva <- function(csv_inputfile, csv_outputfile) {

  data <- read.csv(csv_inputfile, check.names = FALSE)
  write.csv(data, file =(csv_inputfile))

  path <- paste(system.file(package="CrossVApy"), "InterVA.py", sep="/")
  source_python(path)
  source(csv_inputfile, csv_outputfile)
}

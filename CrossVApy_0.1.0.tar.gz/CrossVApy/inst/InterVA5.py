# coding: utf-8

import pandas as pd
import numpy as np 

def source(file, final):

	source = pd.read_csv(file)
	source = source.astype(object)


	# 1) Did s(he) die during the wet season? d wet
	source['a'] = source.filter(regex='Id10004')
	source.loc[(source['a'] == 'wet'), 'i004a'] = 'y'
	source.loc[(source['a'] == 'dry'), 'i004a'] = 'n'

	# 2) Did s(he) die during the dry season? d dry
	source['a'] = source.filter(regex='Id10004')
	source.loc[(source['a'] == 'wet'), 'i004b'] = 'n'
	source.loc[(source['a'] == 'dry'), 'i004b'] = 'y'

	#3) Was he male? male 
	source['a'] = source.filter(regex='Id10019')
	source.loc[(source['a'] == 'male'), 'i019a'] = 'y'
	source.loc[(source['a'] == 'female'), 'i019a'] = 'n'

	##4) Was he female? female
	source['a'] = source.filter(regex='Id10019')
	source.loc[(source['a'] == 'male'), 'i019b'] = 'n'
	source.loc[(source['a'] == 'female'), 'i019b'] = 'y'

	###5) Was s(he) aged 65 years or more at death? 65+
	source['a'] = source.filter(regex='ageInYears')
	source['b'] = source.filter(regex='age_adult')
	source['c'] = source.filter(regex='age_group')
	source['d'] = source.filter(regex='age_child_unit')
	source['e'] = source.filter(regex='age_child_days')
	source['f'] = source.filter(regex='ageInDays')

	source.loc[(source["a"] >= 65), "i022a"] = "y"
	source.loc[(source["b"] >= 65), "i022a"] = "y"

	###6) Was s(he) aged 50 to 64 years at death? 50 to 64
	source.loc[(source["a"] >= 50) & (source["a"]<=64), "i022b"] = "y"
	source.loc[(source["b"] >= 50) & (source["b"]<=64), "i022b"] = "y"

	###7) Was s(he) aged 15 to 49 years at death? 15-49
	source.loc[(source["a"] >= 15) & (source["a"]<=49), "i022c"] = "y"
	source.loc[(source["b"] >= 15) & (source["b"]<=49), "i022c"] = "y"

	###8) Was s(he) aged 5-14 years at death? 5-14 (adult or child)
	source.loc[(source["a"] >= 5) & (source["a"]<=14), "i022d"] = "y"
	source.loc[(source["b"] >= 5) & (source["b"]<=14), "i022d"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'days') & (source["e"] >= 5*365.25) & (source["e"] < 15*365.25) , "i022d"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'months') & (source["c"] >= 5*12) & (source["e"] < 15*12) , "i022d"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'years') & (source["e"] >= 5) & (source["e"] < 15) , "i022d"] = "y"


	###9) Was s(he) aged 1 to 4 years at death? 1 to 4 (child)
	source.loc[(source["a"] >= 1) & (source["a"] <= 4), "i022e"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'days') & (source["e"] >= 1*365.25) & (source["e"] < 5*365.25) , "i022e"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'months') & (source["e"] >= 1*12) & (source["e"] < 5*12) , "i022e"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'years') & (source["e"] >= 1) & (source["e"] < 5) , "i022e"] = "y"

	###10) Was s(he) aged 1 to 11 months at death? 1-11 months (child or neonate?)
	source.loc[(source['f'] >= 30.4) & (source['f'] < 365.25), "i022f"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'days') & (source["e"] >= 29) & (source["e"] <= 12*30.4-1) , "i022f"] = "y"
	source.loc[(source['c'] == 'child' ) & (source["d"] == 'months') & (source["e"] >=1) & (source["e"] < 12) , "i022f"] = "y" 

	###11) Was s(he) aged < 1 month (28 days) at death? 0 - 27 days (neonate)
	source['a'] = source.filter(regex='isNeonatal')
	source['b'] = source.filter(regex='isNeonatal1')
	source['c'] = source.filter(regex='isNeonatal2')

	source.loc[(source['f'] < 28), "i022g"] = "y"
	source.loc[(source["a"] == 1), "i022g"] = 'y'
	source.loc[(source["b"] == 1), "i022g"] = 'y'
	source.loc[(source["c"] == 1), "i022g"] = 'y'

	###12) Was s(he) a live baby who died within 24 hours of birth? day0 iv5Names[12]
	source.loc[(source['f'] < 1), 'i022h'] = 'y'

	###13) Was s(he) a baby who died between 24 and 48 hours of birth? day1 iv5Names[13]
	source['a'] = source.filter(regex='displayAgeNeonate')
	source.loc[(source['a'] >= 1) & (source['a'] < 2), 'i022i'] = 'y'

	###14)  Was s(he) a baby who died more than 48 hours from birth, but within the first week? day2-6 iv5Names[14]
	source.loc[(source['a'] >= 2) & (source['a'] < 7), 'i022j'] = 'y'

	###15) Was s(he) a baby who died after the first week, but within the first month? wk2-4 iv5Names[15]
	source.loc[(source['a'] >= 7) & (source['a'] < 28), 'i022k'] = 'y'

	#16) Was she a woman aged 12-19 years at death? f-19
	source['a'] = source.filter(regex='ageInYears')
	source['b'] = source.filter(regex='age_adult')
	source['c'] = source.filter(regex='age_group')
	source['d'] = source.filter(regex='age_child_unit')
	source['e'] = source.filter(regex='age_child_days')
	source['f'] = source.filter(regex='ageInDays')
	source['g'] = source.filter(regex='Id10019')
	source['i022l'] = "NA"
	source.loc[(source['g'] == 'female') & (source["a"] >= 12) & (source["a"] <= 19) , "i022l"] = "y"
	source.loc[(source['g'] == 'female') & (source['c'] == 'adult') & (source['b'] >= 12) &(source['b'] <= 19) , "i022l"] = 'y'

	#17) Was she a woman aged 57-34 years at death? f20-34
	source['i022m'] = "NA"
	source.loc[(source['g'] == 'female') & (source["a"] >= 20) & (source["a"] <= 34) , "i022m"] = "y"
	source.loc[(source['g'] == 'female') & (source['c'] == 'adult') & (source['b'] >= 20) &(source['b'] <= 34) , "i022m"] = 'Y'

	#18) Was she a woman aged 35 to 49 years at death? f35-49
	source['i022n'] = "NA"
	source.loc[(source['g'] == 'female') & (source["a"] >= 35) & (source["a"] <= 49) , "i022n"] = "y"
	source.loc[(source['g'] == 'female') & (source['c'] == 'adult') & (source['b'] >= 35) &(source['b'] <= 49) , "i022n"] = 'Y'

	#19) Was she married at the time of death? married
	source['a'] = source.filter(regex='Id10059')
	source.loc[(source['a'] == 'married'), "i059o"] ='y'
	source.loc[(source['a'] == 'single'), "i059o"] ='n'
	source.loc[(source['a'] == 'partner'), "i059o"] ='n'
	source.loc[(source['a'] == 'divorced'), "i059o"] ='n'
	source.loc[(source['a'] == 'widowed'), "i059o"] ='n'
	source.loc[(source['a'] == 'too_young_to_be_married'), "i059o"] ='n'
	source.loc[(source['a'] == 'child'), "i059o"] ='n'

	#20) Did (s)he suffer from any injury or accident that led to her/his death? injury
	source['a'] = source.filter(regex='Id10077')
	source.loc[(source['a'] == 'yes'), "i077o"] ='y'
	source.loc[(source['a'] == 'no'), "i077o"] ='n'

	#21) Was (s)he injured in a road traffic accident? inj rta
	source['a'] = source.filter(regex='Id10079')
	source.loc[(source['a'] == 'yes'), "i079o"] ='y'
	source.loc[(source['a'] == 'no'), "i079o"] ='n'

	#22) Was (s)he injured in a non-road transport accident? inj nrta
	source['a'] = source.filter(regex='Id10082')
	source.loc[(source['a'] == 'yes'), "i082o"] ='y'
	source.loc[(source['a'] == 'no'), "i082o"] ='n'

	#23) Was (s)he injured in a fall? inj fall
	source['a'] = source.filter(regex='Id10077')
	source['b'] = source.filter(regex='Id10083')
	source['c'] = source.filter(regex='Id10084')
	source['d'] = source.filter(regex='Id10085')

	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "i083o"] ='y'
	source.loc[(source['a'] == 'yes') & (source['b'] == 'no'), "i083o"] ='n'

	#24) Was (s)he poisoned in any way? inj poison
	source.loc[(source['a'] == 'yes') & (source['c'] == 'yes'), "i084o"] ='y'
	source.loc[(source['a'] == 'yes') & (source['c'] == 'no'), "i084o"] ='n'

	#25) Did (s)he die of drowning? inj drown
	source.loc[(source['a'] == 'yes') & (source['d'] == 'yes'), "i085o"] ='y'
	source.loc[(source['a'] == 'yes') & (source['d'] == 'no'), "i085o"] ='n'

	#26) Was (s)he injured by the bite or sting of a venomous animal? inj venom
	source['a'] = source.filter(regex='Id10086')
	source.loc[(source['a'] == 'yes'), "i086o"] ='y'
	source.loc[(source['a'] == 'no'), "i086o"] ='n'

	#27) Was (s)he injured by an animal or insect (non-venomous) inj anim
	source['a'] = source.filter(regex='Id10087')
	source.loc[(source['a'] == 'yes'), "i087o"] ='y'
	source.loc[(source['a'] == 'no'), "i087o"] ='n'

	#28) Was (s)he injured by burns or fire? inj burn
	source['a'] = source.filter(regex='Id10077')
	source['b'] = source.filter(regex='Id10089')

	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "i089o"] ='y'
	source.loc[(source['a'] == 'yes') & (source['b'] == 'no'), "i089o"] ='n'

	#29) Was (s)he subject to violence (suicide, homicide, abuse)? inj viol
	source['a'] = source.filter(regex='Id10090')
	source.loc[(source['a'] == 'yes'), 'i090o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i090o'] = 'n'

	#30) Was (s)he injured by a fire arm? inj gun
	source['a'] = source.filter(regex='Id10091')
	source.loc[(source['a'] == 'yes'), 'i091o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i091o'] = 'n'

	#31) Was (s)he stabbed, cut or pierced? inj stab
	source['a'] = source.filter(regex='Id10092')
	source.loc[(source['a'] == 'yes'), 'i092o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i092o'] = 'n'

	#32) Was (s)he strangled? inj strng
	source['a'] = source.filter(regex='Id10093')
	source.loc[(source['a'] == 'yes'), 'i093o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i093o'] = 'n'

	#33) Was (s)he injured by a blunt force? inj blfor
	source['a'] = source.filter(regex='Id10094')
	source.loc[(source['a'] == 'yes'), 'i094o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i094o'] = 'n'

	#34) Was (s)he injured by a force of nature? inj nature
	source['a'] = source.filter(regex='Id10095')
	source.loc[(source['a'] == 'yes'), 'i095o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i095o'] = 'n'

	#35) Was (s)he electrocuted? inj elec
	source['a'] = source.filter(regex='Id10096')
	source.loc[(source['a'] == 'yes'), 'i096o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i096o'] = 'n'

	#36) Was the injury accidental? inj accid
	source['a'] = source.filter(regex='Id10098')
	source.loc[(source['a'] == 'yes'), 'i098o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i098o'] = 'n'

	#37) Was the injury or accident self-inflicted? inj suic
	source['a'] = source.filter(regex='Id10099')
	source.loc[(source['a'] == 'yes'), 'i099o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i099o'] = 'n'

	#38) Was the injury or accident intentionally inflicted by someone else? inj int
	source['a'] = source.filter(regex='Id10100')
	source.loc[(source['a'] == 'yes'), 'i100o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i100o'] = 'n'

	#39) Did the baby ever cry? ever cry
	source['a'] = source.filter(regex='Id10104')
	source.loc[(source['a'] == 'yes'), 'i104o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i104o'] = 'n'

	#40) Did the baby cry immediately after birth, even if only a little bit? cry little
	source['a'] = source.filter(regex='Id10105')
	source.loc[(source['a'] == 'yes'), 'i105o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i105o'] = 'n'

	#41) Was it more than 5 minutes after birth before the baby first cried? cry 5+m
	source['a'] = source.filter(regex='Id10106')
	source.loc[(source['a'] > 5), 'i106a'] = 'y' 
	source.loc[(source['a'] <= 5), 'i106a'] = 'n'

	#42) Did the baby stop being able to cry? cry stop
	source['a'] = source.filter(regex='Id10107')
	source.loc[(source['a'] == 'yes'), 'i107o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i107o'] = 'n'

	#43) Did the baby stop crying more than a day before (s)he died? cry st 1+d
	source['a'] = source.filter(regex='Id10108')
	source.loc[(source['a'] > 24), 'i108a'] = 'y'
	source.loc[(source['a'] <= 24), 'i108a'] = 'n'

	#44) Did the baby ever move? ever move
	source['a'] = source.filter(regex='Id10109')
	source.loc[(source['a'] == 'yes'), 'i109o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i109o'] = 'n'

	#45) Did the baby ever breathe? ever breathe
	source['a'] = source.filter(regex='Id10110')
	source.loc[(source['a'] == 'yes'), 'i110o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i110o'] = 'n'

	#46) Did the baby breathe immediately after birth, even a little? brth littlesource['a'] = source.filter(regex='Id10111')
	source.loc[(source['a'] == 'yes'), 'i111o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i111o'] = 'n'

	#47) Did the baby have a breathing problem? brth prob
	source['a'] = source.filter(regex='Id10112')
	source.loc[(source['a'] == 'yes'), 'i112o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i112o'] = 'n'

	#48) Was the baby given assistance to breathe at birth? brth assis
	source['a'] = source.filter(regex='Id10113')
	source.loc[(source['a'] == 'yes'), 'i113o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i113o'] = 'n'

	#49) If the baby didn't show any sign of life, was it born dead? born dead
	source['a'] = source.filter(regex='Id10114')
	source.loc[(source['a'] == 'yes'), 'i114o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i114o'] = 'n'

	#50) Were there any bruises or signs of injury on child's body after the birth? bruised
	source['a'] = source.filter(regex='Id10115')
	source.loc[(source['a'] == 'yes'), 'i115o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i115o'] = 'n'

	#51) Was the baby's body soft, pulpy and discoloured with the skin peeling away? macerated
	source['a'] = source.filter(regex='Id10116')
	source.loc[(source['a'] == 'yes'), 'i116o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i116o'] = 'n'

	#52) Did the final illness last less than 3 weeks? ill <3w. HERE -- check for multiple entries?
	source['a'] = source.filter(regex='Id10120')
	source['b'] = source.filter(regex='Id10122')
	source['c'] = source.filter(regex='Id10121')

	source.loc[(source['a'] < 21 ), "i120a"] = 'y'
	source.loc[(source['b'] < 3 ), "i120a"] = 'y`'
	source.loc[(source['c'] < 1 ), "i120a"] = 'y'
	source.loc[(source['a'] >= 21 ), "i120a"] = 'n'
	source.loc[(source['b'] >= 3 ), "i120a"] = 'n'
	source.loc[(source['c'] >= 1 ), "i120a"] = 'n'


	#53) Did the final illness last at least 3 weeks? ill 3+w
	source.loc[(source['a'] >= 21 ), "i120b"] = 'y'
	source.loc[(source['b'] >= 3 ), "i120b"] = 'y'
	source.loc[(source['c'] >= 1 ), "i120b"] = 'y'
	source.loc[(source['a'] < 21 ), "i120b"] = 'n'
	source.loc[(source['b'] < 3 ), "i120b"] = 'n'
	source.loc[(source['c'] < 1 ), "i120b"] = 'n'

	#54) Did (s)he die suddenly? sudden
	source['a'] = source.filter(regex='Id10123')
	source.loc[(source['a'] == 'yes'), 'i123o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i123o'] = 'n'

	#55) Was there any diagnosis by a health professional of tuberculosis? dia tb
	source['a'] = source.filter(regex='Id10125')
	source.loc[(source['a'] == 'yes'), 'i125o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i125o'] = 'n'

	#56) Was there any diagnosis by a health professional of HIV/AIDS? dia HIV
	source['a'] = source.filter(regex='Id10127')
	source.loc[(source['a'] == 'yes'), 'i127o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i127o'] = 'n'

	#57) Did (s)he have a recent positive test by a health professional for malaria? dia mal+
	source['a'] = source.filter(regex='Id10128')
	source.loc[(source['a'] == 'yes'), 'i128o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i128o'] = 'n'

	#58) Did (s)he have a recent negative test by a health professional for malaria? dia mal-
	source['a'] = source.filter(regex='Id10129')
	source.loc[(source['a'] == 'yes'), 'i129o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i129o'] = 'n'

	#59) Was there any diagnosis by a health professional of dengue fever? dia deng
	source['a'] = source.filter(regex='Id10130')
	source.loc[(source['a'] == 'yes'), 'i130o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i130o'] = 'n'

	#60 )Was there any diagnosis by a health professional of measles? dia meas
	source['a'] = source.filter(regex='Id10131')
	source.loc[(source['a'] == 'yes'), 'i131o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i131o'] = 'n'

	#61) Was there any diagnosis by a health professional of high blood pressure? dia hypt
	source['a'] = source.filter(regex='Id10132')
	source.loc[(source['a'] == 'yes'), 'i132o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i132o'] = 'n'

	#62) Was there any diagnosis by a health professional of heart disease? dia cvd
	source['a'] = source.filter(regex='Id10133')
	source.loc[(source['a'] == 'yes'), 'i133o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i133o'] = 'n'

	#63) Was there any diagnosis by a health professional of diabetes? dia diab
	source['a'] = source.filter(regex='Id10134')
	source.loc[(source['a'] == 'yes'), 'i134o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i134o'] = 'n'

	#64) Was there any diagnosis by a health professional of asthma? dia asth
	source['a'] = source.filter(regex='Id10135')
	source.loc[(source['a'] == 'yes'), 'i135o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i135o'] = 'n'

	#65) Was there any diagnosis by a health professional of epilepsy? dia epil
	source['a'] = source.filter(regex='Id10136')
	source.loc[(source['a'] == 'yes'), 'i136o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i136o'] = 'n'

	#66) Was there any diagnosis by a health professional of cancer? dia canc
	source['a'] = source.filter(regex='Id10137')
	source.loc[(source['a'] == 'yes'), 'i137o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i137o'] = 'n'

	#67) Was there any diagnosis by a health professional of Chronic Obstructive Pulmonary Disease (COPD)? dia copd
	source['a'] = source.filter(regex='Id10138')
	source.loc[(source['a'] == 'yes'), 'i138o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i138o'] = 'n'

	#68) Was there any diagnosis by a physician or health worker of dementia? dia demt
	source['a'] = source.filter(regex='Id10139')
	source.loc[(source['a'] == 'yes'), 'i139o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i139o'] = 'n'

	#69) Was there any diagnosis by a health professional of depression? dia depr
	source['a'] = source.filter(regex='Id10140')
	source.loc[(source['a'] == 'yes'), 'i140o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i140o'] = 'n'

	#70) Was there any diagnosis by a health professional of stroke? dia strk
	source['a'] = source.filter(regex='Id10141')
	source.loc[(source['a'] == 'yes'), 'i141o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i141o'] = 'n'

	#71) Was there any diagnosis by a health professional of sickle cell disease? dia scd
	source['a'] = source.filter(regex='Id10142')
	source.loc[(source['a'] == 'yes'), 'i142o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i142o'] = 'n'

	#72) Was there any diagnosis by a health professional of kidney disease? dia kidn
	source['a'] = source.filter(regex='Id10143')
	source.loc[(source['a'] == 'yes'), 'i143o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i143o'] = 'n'

	#73) Was there any diagnosis by a health professional of liver disease? dia liver
	source['a'] = source.filter(regex='Id10144')
	source.loc[(source['a'] == 'yes'), 'i144o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i144o'] = 'n'

	#74) During the illness that led to death, did (s)he have a fever? fever
	source['a'] = source.filter(regex='Id10147')
	source.loc[(source['a'] == 'yes'), 'i147o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i147o'] = 'n'

	#75) Did the fever last less than a week before death? fev <1w
	source['a'] = source.filter(regex='Id10148')
	source.loc[(source['a'] < 7), 'i148a'] = 'y'
	source.loc[(source['a'] >=7), 'i148a'] = 'n'

	#76) Did the fever last at least one week, but less than 2 weeks before death? fev 1-2w
	source.loc[(source['a'] >= 7) & (source['a'] <14), 'i148b'] = 'y'
	source.loc[(source['a'] <7 ), 'i148b'] = 'n'

	#77) Did the fever last at least 2 weeks before death? fev 2+w
	source.loc[(source['a'] >= 14), 'i148c'] = 'y'
	source.loc[(source['a'] < 14), 'i148c'] = 'n'

	#78) Did the fever continue until death? fev death
	source['a'] = source.filter(regex='Id10149')
	source.loc[(source['a'] == 'yes'), 'i149o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i149o'] = 'n'

	#79) Was the fever severe? fev sev
	source['a'] = source.filter(regex='Id10150')
	source.loc[(source['a'] == 'severe'), 'i150a'] = 'y'
	source.loc[(source['a'] == 'mild'), 'i150a'] = 'n'
	source.loc[(source['a'] == 'moderate'), 'i150a'] = 'n'

	#80) Was the fever continuous? fev cont
	source['a'] = source.filter(regex='Id10151')
	source.loc[(source['a'] == 'continuous'), 'i151a'] = 'y'
	source.loc[(source['a'] == 'nightly'), 'i151a'] = 'n'
	source.loc[(source['a'] == 'on_and_off'), 'i151a'] = 'n'

	#81) Did (s)he have night sweats? fev nsw
	source['a'] = source.filter(regex='Id10152')
	source.loc[(source['a'] == 'yes'), 'i152o'] = 'y' 
	source.loc[(source['a'] == 'no'), 'i152o'] = 'n'

	#82) During the illness that led to death, did (s)he have a cough? cough
	source['a'] = source.filter(regex='Id10153')
	source.loc[(source['a'] == 'yes'), 'i153o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i153o'] = 'n'

	#83) Did the cough last less than 3 weeks before death? cou <3w
	source['a'] = source.filter(regex='Id10154')
	source.loc[(source['a'] < 21), 'i154a'] = 'y'
	source.loc[(source['a'] >= 21), 'i154a'] = 'n'

	#84) Did the cough last at least 3 weeks before death? cou 3+w
	source.loc[(source['a'] >= 21), 'i154b'] = 'y'
	source.loc[(source['a'] < 21), 'i154b'] = 'n'

	#85) Was the cough productive, with sputum? cou prod
	source['a'] = source.filter(regex='Id10155')
	source.loc[(source['a'] == 'yes'), 'i155o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i155o'] = 'n'

	#86) Was the cough very severe? cou sev
	source['a'] = source.filter(regex='Id10156')
	source.loc[(source['a'] == 'yes'), 'i156o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i156o'] = 'n'

	#87) Did (s)he cough up blood? cou bld
	source['a'] = source.filter(regex='Id10157')
	source.loc[(source['a'] == 'yes'), 'i157o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i158o'] = 'n'

	#88) Did (s)he make a whooping sound when coughing? cou whoop
	source['a'] = source.filter(regex='Id10158')
	source.loc[(source['a'] == 'yes'), 'i158o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i158o'] = 'n'

	#89) During the illness that led to death, did (s)he have any difficulty breathing? dif br
	source['a'] = source.filter(regex='Id10159')
	source.loc[(source['a'] == 'yes'), 'i159o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i159o'] = 'n'

	#90) Did the difficult breathing last for at least 3 days before death? dif br 3d
	source['a'] = source.filter(regex='Id10161')
	source['b'] = source.filter(regex='Id10162')
	source['c'] = source.filter(regex='Id10163')

	source.loc[(source['a'] >= 3), 'i161a'] = 'y'
	source.loc[(source['a'] < 3), 'i161a'] = 'n'

	source.loc[(source['b'] >= 1), 'i161a'] = 'y'
	source.loc[(source['c'] >= 1), 'i161a'] = 'y'


	#91) Was the difficult breathing continuous during this period? dif br con
	source['a'] = source.filter(regex='Id10165')
	source.loc[(source['a'] == 'yes'), 'i165a'] = 'y'
	source.loc[(source['a'] == 'no'), 'i165a'] = 'n'

	#92) Did (s)he have fast breathing? br fast
	source['a'] = source.filter(regex='Id10166')
	source.loc[(source['a'] == 'yes'), 'i166o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i166o'] = 'n'

	#93) Did the fast breathing last for less than two weeks before death? br fs <2w
	source['a'] = source.filter(regex='Id10167')
	source.loc[(source['a'] < 14), 'i167a'] = 'y'
	source.loc[(source['a'] >= 14), 'i167a'] = 'n'

	#94) Did the fast breathing last for at least 2 weeks before death? br fs 2+w
	source.loc[(source['a'] >= 14), 'i167b'] = 'y'
	source.loc[(source['a'] < 14), 'i167b'] = 'n'

	#95) Did (s)he have breathlessness? brless
	source['a'] = source.filter(regex='Id10168')
	source.loc[(source['a'] == 'yes'), 'i168o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i168o'] = 'n'

	#96) Did the breathlessness last for less than 2 weeks before death? brl <2w
	source['a'] = source.filter(regex='Id10169')
	source.loc[(source['a'] < 14), 'i169a'] = 'y'
	source.loc[(source['a'] >= 14), 'i169a'] = 'n'

	#97) Did the breathlessness last for at least 2 weeks before death? brl 2+w
	source.loc[(source['a'] >= 14), 'i169b'] = 'y'
	source.loc[(source['a'] < 14), 'i169b'] = 'n'

	#98) Was (s)he unable to carry out daily routines due to breathlessness? brl unab
	source['a'] = source.filter(regex='Id10170')
	source.loc[(source['a'] == 'yes'), 'i170o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i170o'] = 'n'

	#99) Was (s)he breathless while lying flat? brl flat
	source['a'] = source.filter(regex='Id10171')
	source.loc[(source['a'] == 'yes'), 'i171o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i171o'] = 'n'

	#100) Did you see the lower chest wall/ribs being pulled in as the child breathed? indraw
	source['a'] = source.filter(regex='Id10172')
	source.loc[(source['a'] == 'yes'), 'i172o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i172o'] = 'n'

	#101) Did his/her breathing sound like wheezing or grunting? whz grun
	source['a'] = source.filter(regex='Id10173')
	source.loc[(source['a'] == 'grunting'), 'i173a'] = 'y'
	source.loc[(source['a'] == 'stridor'), 'i173a'] = 'y'
	source.loc[(source['a'] == 'wheezing'), 'i173a'] = 'y'
	source.loc[(source['a'] == 'no'), 'i173a'] = 'n'

	#102) During the illness that led to death, did (s)he have chest pain? ch pain
	source['a'] = source.filter(regex='Id10174')
	source.loc[(source['a'] == 'yes'), 'i174o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i174o'] = 'n'

	#103) Was the chest pain severe? chp sev
	source['a'] = source.filter(regex='Id10175')
	source.loc[(source['a'] == 'yes'), 'i175o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i175o'] = 'n'

	#104) Did (s)he experience chest pain at least 3 days before death? chp 3d
	source['a'] = source.filter(regex='Id10176')
	source.loc[(source['a'] >= 3), 'i176a'] = 'y'
	source.loc[(source['a'] < 3), 'i176a'] = 'n'

	#105) Did the chest pain last for at least 30 minutes? chp 30m
	source['a'] = source.filter(regex='Id10178')
	source['b'] = source.filter(regex='Id10179')
	source.loc[(source['a'] >= 30), 'i178a'] = 'y'
	source.loc[(source['b'] >= .5), 'i178a'] = 'y'

	source.loc[(source['a'] < 30), 'i178a'] = 'n'
	source.loc[(source['b'] < .5), 'i178a'] = 'n'

	#106) Did (s)he have diarrhoea? diarr
	source['a'] = source.filter(regex='Id10181')
	source.loc[(source['a'] == 'yes'), 'i181o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i181o'] = 'n'

	#107) Did (s)he have diarrhoea for less than 2 weeks before death? drr <2w
	source['a'] = source.filter(regex='Id10182')
	source.loc[(source['a'] < 14), 'i182a'] = 'y'
	source.loc[(source['a'] >= 14), 'i182a'] = 'n'

	#108) Did (s)he have diarrhoea for at least 2 weeks but less than 4 weeks before death? drr 2-4w
	source.loc[(source['a'] >= 14) & (source['consented-illhistory-signs_symptoms_final_illness-Id10182'] <28), 'i182b'] = 'y'
	source.loc[(source['a'] < 14), 'i182b'] = 'n'
	source.loc[(source['a'] >= 28), 'i182b'] = 'n'

	#109) Did (s)he have diarrhoea for at least 4 weeks before death? drr 4+w
	source.loc[(source['a'] >= 28), 'i182c'] = 'y'
	source.loc[(source['a'] < 28), 'i182c'] = 'n'

	#110) Did the baby or child have at least 4 stools on the day that loose liquid stools were most frequent? 4+ stls
	source['a'] = source.filter(regex='Id10183')
	source.loc[(source['a'] >= 4) & (source['a'] < 999), 'i183o'] = 'y'
	source.loc[(source['a'] < 4), 'i183o'] = 'n'

	#111) Did the frequent loose or liquid stools start at least 3 days before death? drr 3d
	source['a'] = source.filter(regex='Id10184')
	source.loc[(source['a'] >= 3) & (source['a'] < 999), 'i184a'] = 'y'
	source.loc[(source['a'] < 3), 'i184a'] = 'n'

	#112) Did the frequent loose or liquid stools continue up until death? drr to d
	source['a'] = source.filter(regex='Id10185')
	source.loc[(source['a'] == 'yes'), 'i185o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i185o'] = 'n'

	#113) At any time during the final illness was there blood in the stools? drr bld
	source['a'] = source.filter(regex='Id10186')
	source.loc[(source['a'] == 'yes'), 'i186o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i186o'] = 'n'

	#114) Was there blood in the stool up until death? dr bld d
	source['a'] = source.filter(regex='Id10187')
	source.loc[(source['a'] == 'yes'), 'i187o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i187o'] = 'n'

	#115) During the illness that led to death, did (s)he vomit? vomit
	source['a'] = source.filter(regex='Id10188')
	source.loc[(source['a'] == 'yes'), 'i188o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i188o'] = 'n'

	#116) Did (s)he vomit in the week preceding the death? vom bd
	source['a'] = source.filter(regex='Id10189')
	source.loc[(source['a'] == 'yes'), 'i189o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i189o'] = 'n'

	#117) Did (s)he vomit for at least 3 days before death? vom 3d
	source['a'] = source.filter(regex='Id10190')
	source.loc[(source['a'] == 'yes'), 'i190o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i190o'] = 'n'

	#118) Was there blood in the vomit? vom bld
	source['a'] = source.filter(regex='Id10191')
	source.loc[(source['a'] == 'yes'), 'i191o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i191o'] = 'n'

	#119) Was the vomit black? vom blck
	source['a'] = source.filter(regex='Id10192')
	source.loc[(source['a'] == 'yes'), 'i192o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i192o'] = 'n'

	#120) During the illness that led to death, did (s)he have any abdominal (belly) problem? abdom
	source['a'] = source.filter(regex='Id10193')
	source.loc[(source['a'] == 'yes'), 'i193o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i193o'] = 'n'

	#121) Did (s)he have abdominal pain? abd pain
	source['a'] = source.filter(regex='Id10194')
	source.loc[(source['a'] == 'yes'), 'i194o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i194o'] = 'n'

	#122) Was the abdominal pain severe? abd p sev
	source['a'] = source.filter(regex='Id10195')
	source.loc[(source['a'] == 'yes'), 'i195o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i195o'] = 'n'

	#123) Did (s)he have severe abdominal pain for less than 2 weeks before death? abd p <2w
	source['a'] = source.filter(regex='Id10194')
	source['b'] = source.filter(regex='Id10197')
	source['c'] = source.filter(regex='Id10196')
	source['d'] = source.filter(regex='Id10197b')

	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i197a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14), 'i197a'] = 'n'

	source.loc[(source['a'] == 'yes') & (source['c'] < 24*14), 'i197a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['c'] >= 24*14), 'i197a'] = 'n'

	source.loc[(source['a'] == 'yes') & (source['d'] < 2), 'i197a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['d'] >= 2), 'i197a'] = 'n'

	source.loc[(source['a'] == 'yes') & (source['d'] < 1), 'i197a'] = 'y'
	source.loc[(source['a'] == 'no'), 'i197a'] = 'n'

	#124) Did (s)he have severe abdominal pain for at least 2 weeks before death? abd p 2+w
	source.loc[(source['a'] == 'yes') & (source['b'] >=  14), 'i197b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i197b'] = 'n'

	source.loc[(source['a'] == 'yes') & (source['c'] >= 24*14), 'i197b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['c'] < 24*14), 'i197b'] = 'n'

	source.loc[(source['a'] == 'yes') & (source['d'] >= 2), 'i197b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['d'] < 2), 'i197b'] = 'n'

	source.loc[(source['a'] == 'yes') & (source['d'] >= 1), 'i197b'] = 'y'
	source.loc[(source['a'] == 'no'), 'i197b'] = 'n'

	#125) Was the pain in the upper abdomen? abd p up
	source['a'] = source.filter(regex='Id10199')
	source.loc[(source['a'] == 'upper_abdomen'), 'i199a'] = 'y'
	source.loc[(source['a'] == 'upper_lower_abdomen'), 'i199a'] = 'y'
	source.loc[(source['a'] == 'lower_abdomen'), 'i199a'] = 'n'

	#126) Was the pain in the lower abdomen? abd p lo
	source['a'] = source.filter(regex='Id10199')
	source.loc[(source['a'] == 'upper_abdomen'), 'i199b'] = 'n'
	source.loc[(source['a'] == 'upper_lower_abdomen'), 'i199b'] = 'y'
	source.loc[(source['a'] == 'lower_abdomen'), 'i199b'] = 'y'

	#127) Did (s)he have a more than usually protruding abdomen? abd prot
	source['a'] = source.filter(regex='Id10200')
	source.loc[(source['a'] == 'yes'), 'i200o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i200o'] = 'n'

	#128) Did (s)he have a more than usually protruding abdomen for less than 2 weeks before death? abd pr <2w
	source['a'] = source.filter(regex='Id10200')
	source['b'] = source.filter(regex='Id10201')
	source['c'] = source.filter(regex='Id10202')


	source.loc[(source['a'] == 'yes') & (source['b'] < 14) & (source['c'] == 0), 'i201a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i201a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14) & (source['c'] == 0), 'i201a'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14), 'i201a'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['c'] >= 1), 'i201a'] = 'n'
	source.loc[(source['a'] == 'no'), 'i201a'] = 'n'

	#129) Did (s)he have a more than usually protruding abdomen for at least 2 weeks before death? abd pr 2+w
	source.loc[(source['a'] == 'yes') & (source['c'] >= 1) & (source['c'] == 0), 'i201b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14), 'i201b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14) & (source['c'] == 0), 'i201b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i201b'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i201b'] = 'n'
	source.loc[(source['a'] == 'no'), 'i201b'] = 'n'

	#130) Did (s)he develop the protruding abdomen rapidly? abd pr rap
	source['a'] = source.filter(regex='Id10203')
	source.loc[(source['a'] == 'rapidly'), 'i203a'] = 'y'
	source.loc[(source['a'] == 'slowly'), 'i203a'] = 'n'

	#131) Did (s)he have any mass in the abdomen? abd mass
	source['a'] = source.filter(regex='Id10204')
	source.loc[(source['a'] == 'yes'), 'i204o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i204o'] = 'n'

	#132) Did (s)he have a mass in the abdomen for less than 2 weeks before death? ab ms <2w
	source['a'] = source.filter(regex='Id10204')
	source['b'] = source.filter(regex='Id10205')
	source['c'] = source.filter(regex='Id10206')

	source.loc[(source['a'] == 'yes') & (source['b'] < 14) & (source['c'] == 0), 'i205a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i205a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14) & (source['c'] == 0), 'i205a'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14), 'i205a'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['c'] >= 1), 'i205a'] = 'n'
	source.loc[(source['a'] == 'no'), 'i205a'] = 'n'

	#133) Did (s)he have a mass in the abdomen for at least 2 weeks before death? ab ms 2+w
	source.loc[(source['a'] == 'yes') & (source['b'] < 14) & (source['c'] == 0), 'i205b'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['b'] < 14), 'i205b'] = 'n'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14) & (source['c'] == 0), 'i205b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 14), 'i205b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['c'] >= 1), 'i205b'] = 'y'
	source.loc[(source['a'] == 'no'), 'i205b'] = 'n'

	#134) During the illness that led to death, did (s)he have a severe headache? headache
	source['a'] = source.filter(regex='Id10207')
	source.loc[(source['a'] == 'yes'), 'i207o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i207o'] = 'n'

	#135) During the illness that led to death, did (s)he have a stiff neck? st neck
	source['a'] = source.filter(regex='Id10208')
	source.loc[(source['a'] == 'yes'), 'i208o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i208o'] = 'n'

	#136) Did (s)he have a stiff neck for less than one week before death? st n <1w
	source['a'] = source.filter(regex='Id10208')
	source['b'] = source.filter(regex='Id10209')

	source.loc[(source['a'] == 'yes') & (source['b'] < 7), 'i209a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] >= 7), 'i209a'] = 'n'
	source.loc[(source['a'] == 'no'), 'i209a'] = 'n'

	#137) Did (s)he have a stiff neck for at least one week before death? st n 1+w
	source.loc[(source['a'] == 'yes') & (source['b'] >= 7), 'i209b'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] < 7), 'i209b'] = 'n'
	source.loc[(source['a'] == 'no'), 'i209b'] = 'n'

	#138) During the illness that led to death, did (s)he have a painful neck? pain neck
	source['a'] = source.filter(regex='Id10210')
	source.loc[(source['a'] == 'yes'), 'i210o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i210o'] = 'n'

	#139) Did (s)he have a painful neck for at least one week before death? pa n 1+w
	source['a'] = source.filter(regex='Id10210')
	source['b'] = source.filter(regex='Id10211')

	source.loc[(source['a'] == 'yes') & (source['b'] >= 7), 'i211a'] = 'y'
	source.loc[(source['a'] == 'yes') & (source['b'] < 7), 'i211a'] = 'n'
	source.loc[(source['a'] == 'no'), 'i211a'] = 'n'

	#140) During the illness that led to death, did (s)he have mental confusion?	ment conf
	source['a'] = source.filter(regex='Id10212')
	source.loc[(source['a'] == 'yes'), 'i212o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i212o'] = 'n'

	#141) Did (s)he have mental confusion for at least 3 months before death?	menc 3+m
	source['a'] = source.filter(regex='Id10213')
	source.loc[(source['a'] == 'yes'), 'i213o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i213o'] = 'n'

	#142) During the illness that led to death, was (s)he unconscious?	uncons
	source['a'] = source.filter(regex='Id10214')
	source.loc[(source['a'] == 'yes'), 'i214o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i214o'] = 'n'

	#143) Was (s)he unconscious for at least 24 hours before death?	unc 24+h
	source['a'] = source.filter(regex='Id10215')
	source.loc[(source['a'] == 'yes'), 'i215o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i215o'] = 'n'

	#144) Was (s)he unsconscious for at least 6 hours before death?	unc 6+h
	source['a'] = source.filter(regex='Id10216')
	source.loc[(source['a'] >= 6), 'i216a'] = 'y'
	source.loc[(source['a'] < 6), 'i216a'] = 'n'

	#145) Did the unconsciousness start suddenly, quickly (at least within a single day)?	unc sudd
	source['a'] = source.filter(regex='Id10217')
	source.loc[(source['a'] == 'yes'), 'i217o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i217o'] = 'n'

	#146) Did the unconsciousness continue until death?	unc to d
	source['a'] = source.filter(regex='Id10218')
	source.loc[(source['a'] == 'yes'), 'i218o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i218o'] = 'n'

	#147) During the illness that led to death, did (s)he have any convulsions?	conv
	source['a'] = source.filter(regex='Id10219')
	source.loc[(source['a'] == 'yes'), 'i219o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i219o'] = 'n'

	#148) Did (s)he experience any generalized convulsions or fits?	conv gen
	source['a'] = source.filter(regex='Id10220')
	source.loc[(source['a'] == 'yes'), 'i220o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i220o'] = 'n'

	#149) Did the convulsions last for less than 10 minutes?	conv <10m
	source['a'] = source.filter(regex='Id10221')
	source.loc[(source['a'] < 10), 'i221a'] = 'y'
	source.loc[(source['a'] >= 10), 'i221a'] = 'n'

	#150) Did the convulsions last for at least 10 minutes?	conv 10+m
	source['a'] = source.filter(regex='Id10221')
	source.loc[(source['a'] < 10), 'i221b'] = 'n'
	source.loc[(source['a'] >= 10), 'i221b'] = 'y'

	#151) Did (s)he become unconscious immediately after the convulsion?	conv unc
	source['a'] = source.filter(regex='Id10222')
	source.loc[(source['a'] == 'yes'), 'i222o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i222o'] = 'n'

	#152) During the illness that led to death, did (s)he have any urine problems?	urine
	source['a'] = source.filter(regex='Id10223')
	source.loc[(source['a'] == 'yes'), 'i223o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i223o'] = 'n'

	#153) Did (s)he stop urinating?	uri none
	source['a'] = source.filter(regex='Id10224')
	source.loc[(source['a'] == 'yes'), 'i224o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i224o'] = 'n'

	#154) Did (s)he go to urinate more often than usual?	uri more
	source['a'] = source.filter(regex='Id10225')
	source.loc[(source['a'] == 'yes'), 'i225o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i225o'] = 'n'

	#155) Did (s)he pass blood in the urine?	uri bld
	source['a'] = source.filter(regex='Id10226')
	source.loc[(source['a'] == 'yes'), 'i226o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i226o'] = 'n'

	#156) During the illness that led to death, did (s)he have any sores or ulcers anywhere?	skin
	source['a'] = source.filter(regex='Id10227')
	source.loc[(source['a'] == 'yes'), 'i227o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i227o'] = 'n'

	#157) Did (s)he have sores?	sk sores
	source['a'] = source.filter(regex='Id10228')
	source.loc[(source['a'] == 'yes'), 'i228o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i228o'] = 'n'

	#158) Did the sores have clear fluid and/or pus?	sk s pus
	source['a'] = source.filter(regex='Id10229')
	source.loc[(source['a'] == 'yes'), 'i229o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i229o'] = 'n'

	#159) Did (s)he have an ulcer (pit) on the foot?	sk ul ft
	source['a'] = source.filter(regex='Id10230')
	source.loc[(source['a'] == 'yes'), 'i230o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i230o'] = 'n'

	#160) Did any ulcer ooze pus?	sk ul pus
	source['a'] = source.filter(regex='Id10231')
	source.loc[(source['a'] == 'yes'), 'i231o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i231o'] = 'n'

	#161) Did the ulcer ooze pus for at least 2 weeks?	sk ul 2+w
	source['a'] = source.filter(regex='Id10232')
	source.loc[(source['a'] >= 14 ), 'i232a'] = 'y'
	source.loc[(source['a'] < 14), 'i232a'] = 'n'

	#162) During the illness that led to death, did (s)he have any skin rash?	sk rash
	source['a'] = source.filter(regex='Id10233')
	source.loc[(source['a'] == 'yes'), 'i233o'] = 'y'
	source.loc[(source['a'] == ''), 'i233o'] = 'n'

	#163) Did (s)he have the skin rash for less than one week?	sk ra <1w
	source['a'] = source.filter(regex='Id10234')
	source.loc[(source['a'] < 7), 'i234a'] = 'y'
	source.loc[(source['a'] >= 7), 'i234a'] = 'n'

	#164) Did (s)he have the skin rash for at least one week?	sk ra 1+w
	source['a'] = source.filter(regex='Id10234')
	source.loc[(source['a'] >= 7), 'i234b'] = 'y'
	source.loc[(source['a'] < 7), 'i234b'] = 'n'

	#165) Did (s)he have a rash on the face?	sk ra face
	source['a'] = source.filter(regex='Id10235')
	source.loc[(source['a'] == 'face'), 'i235a'] = 'y'
	source.loc[(source['a'] != 'face'), 'i235a'] = 'n'
	source.loc[(source['a'] == ''), 'i235a'] = '.'

	#166) Did (s)he have a rash on the trunk or abdomen?	sk ra abd
	source['a'] = source.filter(regex='Id10235')
	source.loc[(source['a'] == 'abdomen') | (source['a'] == 'trunk'), 'i235b'] = 'y'
	source.loc[(source['a'] != 'abdomen') | (source['a'] == 'trunk'), 'i235b'] = 'n'
	source.loc[(source['a'] == ''), 'i235b'] = '.'

	#167) Did (s)he have a rash on the extremities?	sk ra ext
	source['a'] = source.filter(regex='Id10235')
	source.loc[(source['a'] == 'extremities'), 'i235c'] = 'y'
	source.loc[(source['a'] != 'extremities'), 'i235c'] = 'n'
	source.loc[(source['a'] == ''), 'i235c'] = '.'

	#168) Did (s)he have a rash everywhere?	sk ra all
	source['a'] = source.filter(regex='Id10235')
	source.loc[(source['a'] == 'everywhere'), 'i235d'] = 'y'
	source.loc[(source['a'] != 'everywhere'), 'i235d'] = 'n'
	source.loc[(source['a'] == ''), 'i235d'] = '.'

	#169) Did (s)he have measles rash?	sk ra meas
	source['a'] = source.filter(regex='Id10236')
	source.loc[(source['a'] == 'yes'), 'i236o'] = 'y'
	source.loc[(source['a'] == ''), 'i236o'] = 'n'

	#170) Did (s)he ever have shingles or herpes zoster?	sk ra herp
	source['a'] = source.filter(regex='Id10237')
	source.loc[(source['a'] == 'yes'), 'i237o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i237o'] = 'n'

	#171) During the illness that led to death, did her/his skin flake off in patches?	sk flake
	source['a'] = source.filter(regex='Id10238')
	source.loc[(source['a'] == 'yes'), 'i238o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i238o'] = 'n'

	#172) During the illness that led to death, did he/she have areas of the skin that turned black?	sk black
	source['a'] = source.filter(regex='Id10239')
	source.loc[(source['a'] == 'yes'), 'i239o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i239o'] = 'n'

	#173) During the illness that led to death, did he/she have areas of the skin with redness and swelling?	sk red
	source['a'] = source.filter(regex='Id10240')
	source.loc[(source['a'] == 'yes'), 'i240o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i240o'] = 'n'

	#174) During the illness that led to death, did (s)he bleed from anywhere?	bleed
	source['a'] = source.filter(regex='Id10241')
	source.loc[(source['a'] == 'yes'), 'i241o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i241o'] = 'n'

	#175) Did (s)he bleed from the nose, mouth or anus?	bld orif
	source['a'] = source.filter(regex='Id10242')
	source.loc[(source['a'] == 'yes'), 'i242o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i242o'] = 'n'

	#176) During the illness that led to death, did (s)he have noticeable weight loss?	wt loss
	source['a'] = source.filter(regex='Id10243')
	source.loc[(source['a'] == 'yes'), 'i243o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i243o'] = 'n'

	#177) Was (s)he severely thin or wasted?	wt waste
	source['a'] = source.filter(regex='Id10244')
	source.loc[(source['a'] == 'yes'), 'i244o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i244o'] = 'n'

	#178) During the illness that led to death, did s/he have a whitish rash inside the mouth or on the tongue?	wht rash
	source['a'] = source.filter(regex='Id10245')
	source.loc[(source['a'] == 'yes'), 'i245o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i245o'] = 'n'

	#179) During the illness that led to death, did (s)he have stiffness of the whole body or was unable to open the mouth?	stiff
	source['a'] = source.filter(regex='Id10246')
	source.loc[(source['a'] == 'yes'), 'i246o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i246o'] = 'n'

	#180) During the illness that led to death, did (s)he have puffiness of the face?	sw pu face
	source['a'] = source.filter(regex='Id10247')
	source.loc[(source['a'] == 'yes'), 'i247o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i247o'] = 'n'

	#181) Did (s)he have puffiness of the face for at least one week before death?	sw p f 1+w
	source['a'] = source.filter(regex='Id10248')
	source.loc[(source['a'] >= 7), 'i248a'] = 'y'
	source.loc[(source['a'] < 7), 'i248a'] = 'n'

	#182)During the illness that led to death, did (s)he have swollen legs or feet?	sw lg ft
	source['a'] = source.filter(regex='Id10249')
	source.loc[(source['a'] == 'yes'), 'i249o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i249o'] = 'n'

	#183) Did the swelling last for at least 3 days before death?	sw lf 3+d
	source['a'] = source.filter(regex='Id10250')
	source.loc[(source['a'] >= 3), 'i250a'] = 'y'
	source.loc[(source['a'] < 3), 'i250a'] = 'n'

	#184) Did (s)he have both feet swollen?	sw lf bth
	source['a'] = source.filter(regex='Id10251')
	source.loc[(source['a'] == 'yes'), 'i251o'] = 'y'
	source.loc[(source['a'] == ''), 'i251o'] = 'n'

	#185) During the illness that led to death, did (s)he have general puffiness all over his/her body?	sw puf all
	source['a'] = source.filter(regex='Id10252')
	source.loc[(source['a'] == 'yes'), 'i252o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i252o'] = 'n'

	#186) During the illness that led to death, did (s)he have any lumps?	lumps
	source['a'] = source.filter(regex='Id10253')
	source.loc[(source['a'] == 'yes'), 'i253o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i253o'] = 'n'

	#187) Did (s)he have any lumps or lesions in the mouth?	lm mou
	source['a'] = source.filter(regex='Id10254')
	source.loc[(source['a'] == 'yes'), 'i254o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i254o'] = 'n'

	#188) Did (s)he have any lumps in the neck?	lm nck
	source['a'] = source.filter(regex='Id10255')
	source.loc[(source['a'] == 'yes'), 'i255o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i255o'] = 'n'

	#189) Did (s)he have any lumps in the armpit?	lm arm
	source['a'] = source.filter(regex='Id10256')
	source.loc[(source['a'] == 'yes'), 'i256o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i256o'] = 'n'

	#190) Did (s)he have any lumps in the groin?	lm grn
	source['a'] = source.filter(regex='Id10257')
	source.loc[(source['a'] == 'yes'), 'i257o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i257o'] = 'n'

	#191) During the illness that led to death, was (s)he in any way paralysed?	paral
	source['a'] = source.filter(regex='Id10258')
	source.loc[(source['a'] == 'yes'), 'i258o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i258o'] = 'n'

	#192) Did (s)he have paralysis of only one side of the body?	par 1 side
	source['a'] = source.filter(regex='Id10259')
	source.loc[(source['a'] == 'yes'), 'i259o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i259o'] = 'n'

	#193) Was only the right side of the body paralysed?	par rs
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'right_side'), 'i260a'] = 'y'
	source.loc[(source['a'] != 'right_side'), 'i260a'] = 'n'
	source.loc[(source['a'] == ''), 'i260a'] = '.'

	#194) Was only the left side of the body paralysed?	par ls
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'left_side'), 'i260b'] = 'y'
	source.loc[(source['a'] != 'left_side'), 'i260b'] = 'n'
	source.loc[(source['a'] == ''), 'i260b'] = '.'

	#195) Was only the lower part of the body paralysed?	par lo
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'lower_part_of_body'), 'i260c'] = 'y'
	source.loc[(source['a'] != 'lower_part_of_body'), 'i260c'] = 'n'
	source.loc[(source['a'] == ''), 'i260c'] = '.'

	#196) Was only the upper part of the body paralysed?	par up
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'upper_part_of_body'), 'i260d'] = 'y'
	source.loc[(source['a'] != 'upper_part_of_body'), 'i260d'] = 'n'
	source.loc[(source['a'] == ''), 'i260d'] = '.'

	#197) Was only one leg paralysed?	par leg
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'one_leg_only'), 'i260e'] = 'y'
	source.loc[(source['a'] != 'one_leg_only'), 'i260e'] = 'n'
	source.loc[(source['a'] == ''), 'i260e'] = '.'

	#198) Was only one arm paralysed?	par arm
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'one_arm_only'), 'i260f'] = 'y'
	source.loc[(source['a'] != 'one_arm_only'), 'i260f'] = 'n'
	source.loc[(source['a'] == ''), 'i260f'] = '.'

	#199) Was the entire body paralysed?	par all
	source['a'] = source.filter(regex='Id10260')
	source.loc[(source['a'] == 'whole_body'), 'i260g'] = 'y'
	source.loc[(source['a'] != 'whole_body'), 'i260g'] = 'n'
	source.loc[(source['a'] == ''), 'i260g'] = '.'

	#200) During the illness that led to death, did (s)he have difficulty swallowing?	swallow
	source['a'] = source.filter(regex='Id10261')
	source.loc[(source['a'] == 'yes'), 'i261o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i261o'] = 'n'

	#201) Did (s)he have difficulty swallowing for at least one week before death?	swa 1+w
	source['a'] = source.filter(regex='Id10262')
	source.loc[(source['a'] >= 7), 'i262a'] = 'y'
	source.loc[(source['a'] < 7), 'i262a'] = 'n'

	#202) Did (s)he have difficulty with swallowing solids?	swa sol
	source['a'] = source.filter(regex='Id10263')
	source.loc[(source['a'] == 'solids'), 'i263a'] = 'y'
	source.loc[(source['a'] == 'both'), 'i263a'] = 'y'
	source.loc[(source['a'] == 'liquids'), 'i263a'] = 'n'

	#203) Did (s)he have difficulty with swallowing liquids?	swa liq
	source['a'] = source.filter(regex='Id10263')
	source.loc[(source['a'] == 'solids'), 'i263b'] = 'n'
	source.loc[(source['a'] == 'both'), 'i263b'] = 'y'
	source.loc[(source['a'] == 'liquids'), 'i263b'] = 'y'

	#204) Did (s)he have pain upon swallowing?	swa pain
	source['a'] = source.filter(regex='Id10264')
	source.loc[(source['a'] == 'yes'), 'i264o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i264o'] = 'n'

	#205) During the illness that led to death, did (s)he have yellow discolouration of the eyes?	yellow
	source['a'] = source.filter(regex='Id10265')
	source.loc[(source['a'] == 'yes'), 'i265o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i265o'] = 'n'

	#206) Did (s)he have the yellow discolouration for at least 3 weeks before death?	yell 3+w
	source['a'] = source.filter(regex='Id10266')
	source.loc[(source['a'] >= 21), 'i266a'] = 'y'
	source.loc[(source['a'] < 21), 'i266a'] = 'n'

	#207) During the illness that led to death, did her/his hair change to a reddish or yellowish colour?	hair
	source['a'] = source.filter(regex='Id10267')
	source.loc[(source['a'] == 'yes'), 'i267o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i267o'] = 'n'

	#208) During the illness that led to death, did (s)he look pale (thinning/lack of blood) or have pale palms, eyes or nail beds?	pale
	source['a'] = source.filter(regex='Id10268')
	source.loc[(source['a'] == 'yes'), 'i268o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i268o'] = 'n'

	#209) During the illness that led to death, did (s)he have sunken eyes?	eyes sunk
	source['a'] = source.filter(regex='Id10269')
	source.loc[(source['a'] == 'yes'), 'i269o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i269o'] = 'n'

	#210) During the illness that led to death, did (s)he drink a lot more water than usual?	drink ++
	source['a'] = source.filter(regex='Id10270')
	source.loc[(source['a'] == 'yes'), 'i270o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i270o'] = 'n'

	#211) Was the baby able to suckle or bottle-feed within the first 24 hours after birth?	suckle
	source['a'] = source.filter(regex='Id10271')
	source.loc[(source['a'] == 'yes'), 'i271o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i271o'] = 'n'

	#212) Did the baby ever suckle in a normal way?	suck ev
	source['a'] = source.filter(regex='Id10272')
	source.loc[(source['a'] == 'yes'), 'i272o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i272o'] = 'n'

	#213) Did the baby stop suckling?	suck st
	source['a'] = source.filter(regex='Id10273')
	source.loc[(source['a'] == 'yes'), 'i273o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i273o'] = 'n'

	#214) Did the baby stop suckling on the 2nd day of life or later?	suck st d1
	source['a'] = source.filter(regex='Id10274')
	source.loc[(source['a'] >= 2), 'i274a'] = 'y'
	source.loc[(source['a'] < 2), 'i274a'] = 'n'

	#215) Did the baby have convulsions starting within the first 24 hours of life?	conv d0
	source['a'] = source.filter(regex='Id10275')
	source.loc[(source['a'] == 'yes'), 'i275o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i275o'] = 'n'

	#216) Did the baby have convulsions starting more than 24 hours after birth?	conv d1+
	source['a'] = source.filter(regex='Id10276')
	source.loc[(source['a'] == 'yes'), 'i276o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i276o'] = 'n'

	#217) Did the baby's body become stiff, with the back arched backwards?	stiff
	source['a'] = source.filter(regex='Id10277')
	source.loc[(source['a'] == 'yes'), 'i277o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i276o'] = 'n'

	#218) During the illness that led to death, did the baby have a bulging or raised fontanelle?	font up
	source['a'] = source.filter(regex='Id10278')
	source.loc[(source['a'] == 'yes'), 'i278o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i278o'] = 'n'

	#219) During the illness that led to death, did the baby have a sunken fontanelle?	font lo
	source['a'] = source.filter(regex='Id10279')
	source.loc[(source['a'] == 'yes'), 'i279o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i279o'] = 'n'

	#220) During the illness that led to death, did the baby become unresponsive or unconscious?	unresp
	source['a'] = source.filter(regex='Id10281')
	source.loc[(source['a'] == 'yes'), 'i281o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i281o'] = 'n'

	#221) Did the baby become unresponsive or unconscious soon after birth, within less than 24 hours?	unc d0
	source['a'] = source.filter(regex='Id10282')
	source.loc[(source['a'] == 'yes'), 'i282o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i282o'] = 'n'

	#222) Did the baby become unresponsive or unconscious more than 24 hours after birth?	unc d1+
	source['a'] = source.filter(regex='Id10283')
	source.loc[(source['a'] == 'yes'), 'i283o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i283o'] = 'n'

	#223) During the illness that led to death, did the baby become cold to touch?	cold
	source['a'] = source.filter(regex='Id10284')
	source.loc[(source['a'] == 'yes'), 'i284o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i284o'] = 'n'

	#224) Was the baby more than 3 days old when it started feeling cold to touch?	cold 3+d
	source['a'] = source.filter(regex='Id10285')
	source.loc[(source['a'] > 3), 'i285a'] = 'y'
	source.loc[(source['a'] <= 3), 'i285a'] = 'n'

	#225) During the illness that led to death, did the baby become lethargic, after a period of normal activity?	lethargy
	source['a'] = source.filter(regex='Id10286')
	source.loc[(source['a'] == 'yes'), 'i286o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i286o'] = 'n'

	#226) Did the baby have redness or discharge from the umbilical cord stump?	umbil dis
	source['a'] = source.filter(regex='Id10287')
	source.loc[(source['a'] == 'yes'), 'i287o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i287o'] = 'n'

	#227) During the illness that led to death, did the baby have skin ulcer(s) or pits?	sk ulcer
	source['a'] = source.filter(regex='Id10288')
	source.loc[(source['a'] == 'yes'), 'i288o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i288o'] = 'n'

	#228) During the illness that led to death, did the baby have yellow skin, palms (hand) or soles (foot)?	yellow
	source['a'] = source.filter(regex='Id10289')
	source.loc[(source['a'] == 'yes'), 'i289o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i289o'] = 'n'

	#229) Did the baby or infant appear to be healthy and then just die suddenly?	sudd d
	source['a'] = source.filter(regex='Id10290')
	source.loc[(source['a'] == 'yes'), 'i290o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i290o'] = 'n'

	#230) During the illness that led to death, did she have any swelling or lump in the breast?	sw lm bre
	source['a'] = source.filter(regex='Id10294')
	source.loc[(source['a'] == 'yes'), 'i294o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i294o'] = 'n'

	#231) During the illness that led to death, did she have any ulcers (pits) in the breast?	sw ul bre
	source['a'] = source.filter(regex='Id10295')
	source.loc[(source['a'] == 'yes'), 'i295o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i295o'] = 'n'

	#232) Did she ever have a period or menstruate?	menstr
	source['a'] = source.filter(regex='Id10296')
	source.loc[(source['a'] == 'yes'), 'i296o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i296o'] = 'n'

	#233) During the illness that led to death, did she have excessive vaginal bleeding in between menstrual periods?	men betw
	source['a'] = source.filter(regex='Id10297')
	source.loc[(source['a'] == 'yes'), 'i297o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i297o'] = 'n'

	#234) Was the bleeding excessive?	men exc
	source['a'] = source.filter(regex='Id10298')
	source.loc[(source['a'] == 'yes'), 'i298o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i298o'] = 'n'

	#235) Did her menstrual period stop naturally because of menopause?	men mpse
	source['a'] = source.filter(regex='Id10299')
	source.loc[(source['a'] == 'yes'), 'i299o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i299o'] = 'n'

	#236) Did she have vaginal bleeding after cessation of menstruation?	men mp bl
	source['a'] = source.filter(regex='Id10300')
	source.loc[(source['a'] == 'yes'), 'i300o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i300o'] = 'n'

	#237) Was there excessive vaginal bleeding in the week prior to death?	vb <1w
	source['a'] = source.filter(regex='Id10301')
	source.loc[(source['a'] == 'yes'), 'i301o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i301o'] = 'n'

	#238) At the time of death was her period overdue?	men late
	source['a'] = source.filter(regex='Id10302')
	source.loc[(source['a'] == 'yes'), 'i302o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i302o'] = 'n'

	#239) Had her period been overdue for at least 4 weeks?	men l 4+w
	source['a'] = source.filter(regex='Id10303')
	source.loc[(source['a'] >= 4), 'i303a'] = 'y'
	source.loc[(source['a'] < 4), 'i303a'] = 'n'

	#240) Did she have a sharp pain in her abdomen shortly before death?	obs pain
	source['a'] = source.filter(regex='Id10304')
	source.loc[(source['a'] == 'yes'), 'i304o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i304o'] = 'n'

	#241) Was she pregnant at the time of death?	pregnant
	source['a'] = source.filter(regex='Id10305')
	source.loc[(source['a'] == 'yes'), 'i305o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i305o'] = 'n'

	#242) Did she die within 6 weeks of delivery, abortion or miscarriage?	d <6w pend
	source['a'] = source.filter(regex='Id10306')
	source.loc[(source['a'] == 'yes'), 'i306o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i306o'] = 'n'

	#243) Was she, or had she been, pregnant for less than 6 months when she died?	d <6m pr
	source['a'] = source.filter(regex='Id10309')
	source.loc[(source['a'] == 'yes'), 'i309o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i309o'] = 'n'

	#244) Please confirm: When she died, she was NEITHER pregnant NOR had recently been pregnant NOR had recently delivered when she died - is that right?	not preg
	source['a'] = source.filter(regex='Id10310')
	source.loc[(source['a'] == 'yes'), 'i310o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i310o'] = 'n'

	#245) Did she die during labour, but before delivery?	d lab
	source['a'] = source.filter(regex='Id10312')
	source.loc[(source['a'] == 'yes'), 'i312o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i312o'] = 'n'

	#246) Did she die during labour, but before delivery?	d lab
	source['a'] = source.filter(regex='Id10313')
	source.loc[(source['a'] == 'yes'), 'i313o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i313o'] = 'n'

	#247) Did she die within 24 hours after delivery?	d <24h del
	source['a'] = source.filter(regex='Id10314')
	source.loc[(source['a'] == 'yes'), 'i314o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i314o'] = 'n'

	#248) Did she die within 6 weeks of childbirth?	d <6w chb
	source['a'] = source.filter(regex='Id10315')
	source.loc[(source['a'] == 'yes'), 'i315o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i315o'] = 'n'

	#249) Did she give birth to a live baby (within 6 weeks of her death)?	live baby
	source['a'] = source.filter(regex='Id10316')
	source.loc[(source['a'] == 'yes'), 'i316o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i316o'] = 'n'

	#250) Did she die during or after a multiple pregnancy?	mult pr
	source['a'] = source.filter(regex='Id10317')
	source.loc[(source['a'] == 'yes'), 'i317o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i317o'] = 'n'

	#251) Was she breastfeeding the child in the days before death?	br feed
	source['a'] = source.filter(regex='Id10318')
	source.loc[(source['a'] == 'yes'), 'i318o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i318o'] = 'n'

	#252) Did she die during or after her first pregnancy?	1st pr. ## HERE
	source['a'] = source.filter(regex='Id10319')
	source.loc[(source['a'] == 0), 'i319a'] = 'y'
	source.loc[(source['a'] > 0), 'i319a'] = 'n'

	#253) Did she have four or more pregnancies before this one?	4+ pr
	source['a'] = source.filter(regex='Id10319')
	source.loc[(source['a'] >= 4), 'i319b'] = 'y'
	source.loc[(source['a'] < 4), 'i319b'] = 'n'

	#254) Had she had any previous Caesarean section?	prev cs
	source['a'] = source.filter(regex='Id10320')
	source.loc[(source['a'] == 'yes'), 'i320o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i320o'] = 'n'

	#255) During pregnancy, did she suffer from high blood pressure?	pr hypt
	source['a'] = source.filter(regex='Id10321')
	source.loc[(source['a'] == 'yes'), 'i321o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i321o'] = 'n'

	#256) Did she have foul smelling vaginal discharge during pregnancy or after delivery?	pr disch
	source['a'] = source.filter(regex='Id10322')
	source.loc[(source['a'] == 'yes'), 'i322o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i322o'] = 'n'

	#257) During the last 3 months of pregnancy, did she suffer from convulsions?	pr conv
	source['a'] = source.filter(regex='Id10323')
	source.loc[(source['a'] == 'yes'), 'i323o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i323o'] = 'n'

	#258) During the last 3 months of pregnancy did she suffer from blurred vision?	pr bl vis
	source['a'] = source.filter(regex='Id10324')
	source.loc[(source['a'] == 'yes'), 'i324o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i324o'] = 'n'

	#259) Did she have excessive bleeding during pregnancy or shortly after delivery?	pr bleed
	source['a'] = source.filter(regex='Id10325')
	source.loc[(source['a'] == 'yes'), 'i325o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i325o'] = 'n'

	#260) Was there vaginal bleeding during the first 6 months of pregnancy?	pr bl <6m
	source['a'] = source.filter(regex='Id10326')
	source.loc[(source['a'] == 'yes'), 'i326o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i326o'] = 'n'

	#261) Was there vaginal bleeding during the last 3 months of pregnancy but before labour started?	pr bl 6+m
	source['a'] = source.filter(regex='Id10327')
	source.loc[(source['a'] == 'yes'), 'i327o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i327o'] = 'n'

	#262) Did she have excessive bleeding during labour, before delivery?	pr bl lab
	source['a'] = source.filter(regex='Id10328')
	source.loc[(source['a'] == 'yes'), 'i328o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i328o'] = 'n'

	#263) Did she have excessive bleeding after delivery or abortion?	pr bl ppt
	source['a'] = source.filter(regex='Id10329')
	source.loc[(source['a'] == 'yes'), 'i329o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i329o'] = 'n'

	#264) Was the placenta completely delivered?	plnta del
	source['a'] = source.filter(regex='Id10330')
	source.loc[(source['a'] == 'yes'), 'i330o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i330o'] = 'n'

	#265) Did she deliver or try to deliver an abnormally positioned baby?	del ab pos
	source['a'] = source.filter(regex='Id10331')
	source.loc[(source['a'] == 'yes'), 'i331o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i331o'] = 'n'

	#266) Did her labour last longer than 24 hours?	lab 24+h
	source['a'] = source.filter(regex='Id10332')
	source.loc[(source['a'] > 24), 'i332a'] = 'y'
	source.loc[(source['a'] <= 24), 'i332a'] = 'n'

	#267) Did she attempt to terminate the pregnancy?	term att
	source['a'] = source.filter(regex='Id10333')
	source.loc[(source['a'] == 'yes'), 'i333o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i333o'] = 'n'

	#268) Did she recently have a pregnancy that ended in an abortion (spontaneous or induced)?	abort
	source['a'] = source.filter(regex='Id10334')
	source.loc[(source['a'] == 'yes'), 'i334o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i334o'] = 'n'

	#269) Did she die during an abortion?	d in abort
	source['a'] = source.filter(regex='Id10335')
	source.loc[(source['a'] == 'yes'), 'i335o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i335o'] = 'n'

	#270) Did she die within 6 weeks of having an abortion?	d after ab
	source['a'] = source.filter(regex='Id10336')
	source.loc[(source['a'] == 'yes'), 'i336o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i336o'] = 'n'

	#271) Did the mother deliver at a health facility or clinic?	del hfac
	source['a'] = source.filter(regex='Id10337')
	source.loc[(source['a'] == 'hospital'), 'i337a'] = 'y'
	source.loc[(source['a'] == 'other_health_facility'), 'i337a'] = 'y'
	source.loc[(source['a'] == 'home'), 'i337a'] = 'n'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), 'i337a'] = 'n'
	source.loc[(source['a'] == 'other'), 'i337a'] = 'n'

	#272) Did the mother deliver at home?	del home
	source.loc[(source['a'] == 'hospital'), 'i337b'] = 'n'
	source.loc[(source['a'] == 'other_health_facility'), 'i337b'] = 'n'
	source.loc[(source['a'] == 'home'), 'i337b'] = 'y'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), 'i337b'] = 'n'
	source.loc[(source['a'] == 'other'), 'i337b'] = 'n'

	#273) Did the mother deliver elsewhere (not at a health facility nor at home)?	del else
	source.loc[(source['a'] == 'hospital'), 'i337c'] = 'n'
	source.loc[(source['a'] == 'other_health_facility'), 'i337c'] = 'n'
	source.loc[(source['a'] == 'home'), 'i337c'] = 'n'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), 'i337c'] = 'y'
	source.loc[(source['a'] == 'other'), 'i337c'] = 'y'

	#274) Did she receive professional assistance during the delivery?	del prof
	source['a'] = source.filter(regex='Id10338')
	source.loc[(source['a'] == 'yes'), 'i338o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i338o'] = 'n'

	#275) Did she have an operation to remove her uterus shortly before death?	hyster
	source['a'] = source.filter(regex='Id10340')
	source.loc[(source['a'] == 'yes'), 'i340o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i340o'] = 'n'

	#276) Was the delivery normal vaginal, without forceps or vacuum?	del norm
	source['a'] = source.filter(regex='Id10342')
	source.loc[(source['a'] == 'yes'), 'i342o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i342o'] = 'n'

	#277) Was the delivery vaginal, with forceps or vacuum?	del assist
	source['a'] = source.filter(regex='Id10343')
	source.loc[(source['a'] == 'yes'), 'i343o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i343o'] = 'n'

	#278) Was the delivery a Caesarean section?	del cs
	source['a'] = source.filter(regex='Id10344')
	source.loc[(source['a'] == 'yes'), 'i344o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i344o'] = 'n'

	#279) Was her baby born more than one month early?	del >1m ea
	source['a'] = source.filter(regex='Id10347')
	source.loc[(source['a'] == 'yes'), 'i347o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i347o'] = 'n'

	#280) Was the child part of a multiple  birth?	mult bir
	source['a'] = source.filter(regex='Id10354')
	source.loc[(source['a'] == 'yes'), 'i354o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i354o'] = 'n'

	#281) If the child was part of a multiple birth, was it born first?	mult fir
	source['a'] = source.filter(regex='Id10355')
	source.loc[(source['a'] == 'first'), 'i355a'] = 'y'
	source.loc[(source['a'] == 'second_or_later'), 'i355a'] = 'n'

	#282) Is the child's mother still alive?	moth aliv
	source['a'] = source.filter(regex='Id10356')
	source.loc[(source['a'] == 'yes'), 'i356o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i356o'] = 'n'

	#283) Did the child's mother die during or shortly after the delivery?	moth d del
	source['a'] = source.filter(regex='Id10357')
	source.loc[(source['a'] == 'after_delivery'), 'i357o'] = 'y'
	source.loc[(source['a'] == 'during_delivery'), 'i357o'] = 'y'

	#284) Did the child's mother die in the baby's first year of life?	moth d y1
	source['a'] = source.filter(regex='Id10358')
	source['b'] = source.filter(regex='Id10359')

	source.loc[(source['a']) + (source['b'])/30.4 <= 12 , 'i358a'] = 'y'
	source.loc[(source['a']) + (source['b'])/30.4 < 12, 'i358a'] = 'n'

	#285) Was the baby born in a health facility or clinic?	born fac
	source['a'] = source.filter(regex='Id10360')
	source.loc[(source['a'] == 'hospital'), 'i360a'] = 'y'
	source.loc[(source['a'] == 'other_health_facility'), 'i360a'] = 'y'
	source.loc[(source['a'] == 'home'), 'i360a'] = 'n'
	source.loc[(source['a'] == 'other'), 'i360a'] = 'n'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), 'i360a'] = 'n'

	#286) Was the baby born at home?	born home
	source.loc[(source['a'] == 'hospital'), 'i360b'] = 'n'
	source.loc[(source['a'] == 'other_health_facility'), 'i360b'] = 'n'
	source.loc[(source['a'] == 'home'), 'i360b'] = 'y'
	source.loc[(source['a'] == 'other'), 'i360b'] = 'n'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), 'i360b'] = 'n'

	#287) Was the baby born somewhere else (e.g. on the way to a clinic)?	born on way
	source.loc[(source['a'] == 'hospital'), 'i360c'] = 'n'
	source.loc[(source['a'] == 'other_health_facility'), 'i360c'] = 'n'
	source.loc[(source['a'] == 'home'), 'i360c'] = 'n'
	source.loc[(source['a'] == 'other'), 'i360c'] = 'y'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), 'i360c'] = 'y'

	#288) Did the mother receive professional assistance during the delivery?	born prof
	source['a'] = source.filter(regex='Id10361')
	source.loc[(source['a'] == 'yes'), 'i361o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i361o'] = 'n'

	#289) At birth, was the baby of usual size?	bwt norm
	source['a'] = source.filter(regex='Id10362')
	source.loc[(source['a'] == 'yes'), 'i362o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i362o'] = 'n'

	#290) At birth, was the baby smaller than normal (weighing under 2.5 kg)?	bwt small
	source['a'] = source.filter(regex='Id10363')
	source.loc[(source['a'] == 'yes'), 'i363o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i363o'] = 'n'

	#291) At birth, was the baby very much smaller than usual, (weighing under 1 kg)?	bwt vsmall
	source['a'] = source.filter(regex='Id10364')
	source.loc[(source['a'] == 'yes'), 'i364o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i364o'] = 'n'

	#292) At birth, was the baby larger than normal (weighing over 4.5 kg)?	bwt big
	source['a'] = source.filter(regex='Id10365')
	source.loc[(source['a'] == 'yes'), 'i365o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i365o'] = 'n'

	#293) Was the baby born during the ninth month (at least 37 weeks) of pregnancy?	gest 9m
	source['a'] = source.filter(regex='Id10367')
	source.loc[(source['a'] >= 9) & (source['a'] < 88), 'i367a'] = 'y'
	source.loc[(source['a'] < 9), 'i367a'] = 'n'

	#294) Was the baby born during the eighth month (34 to 37 weeks) of pregnancy?	gest 8m
	source.loc[(source['a'] > 8) & (source['a'] < 88), 'i367b'] = 'n'
	source.loc[(source['a'] == 8), 'i367b'] = 'y'
	source.loc[(source['a'] < 8), 'i367b'] = 'n'

	#295) Was the baby born before the eighth month (less than 34 weeks) of pregnancy?	gest 7m
	source.loc[(source['a'] >= 8) & (source['a'] < 88), 'i367c'] = 'n'
	source.loc[(source['a'] < 8), 'i367c'] = 'y'

	#296) Were there any complications in the late part of the pregnancy (defined as the last 3 months), but before labour?	cmp bf lab
	source['a'] = source.filter(regex='Id10368')
	source.loc[(source['a'] == 'yes'), 'i368o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i368o'] = 'n'

	#297) Were there any complications during labour or delivery?	cmp in lab
	source['a'] = source.filter(regex='Id10369')
	source.loc[(source['a'] == 'yes'), 'i369o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i369o'] = 'n'

	#298) Was any part of the baby physically abnormal at time of delivery? (for example: body part too large or too small, additional growth on body)?	abnorm
	source['a'] = source.filter(regex='Id10370')
	source.loc[(source['a'] == 'yes'), 'i370o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i370o'] = 'n'

	#299) Did the baby/child have a swelling or defect on the back?	abn back
	source['a'] = source.filter(regex='Id10371')
	source.loc[(source['a'] == 'yes'), 'i371o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i371o'] = 'n'

	#300) Did the baby/child have a very large head?	abn lg hd
	source['a'] = source.filter(regex='Id10372')
	source.loc[(source['a'] == 'yes'), 'i372o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i372o'] = 'n'

	#301) Did the baby/child have a very small head?	abn sm hd
	source['a'] = source.filter(regex='Id10373')
	source.loc[(source['a'] == 'yes'), 'i373o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i373o'] = 'n'

	#302) Was the baby moving in the last few days before the birth?	bab mov
	source['a'] = source.filter(regex='Id10376')
	source.loc[(source['a'] == 'yes'), 'i376o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i376o'] = 'n'

	#303) Did the baby stop moving in the womb before labour started?	bab st mov
	source['a'] = source.filter(regex='Id10377')
	source.loc[(source['a'] == 'yes'), 'i377o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i377o'] = 'n'

	#304) Did labour and delivery take more than 24 hours?	lab 24+h
	source['a'] = source.filter(regex='Id10382')
	source.loc[(source['a'] > 24), 'i382a'] = 'y'
	source.loc[(source['a'] <= 24), 'i382a'] = 'n'

	#305) Was the baby born 24 hours or more after the waters broke?	born 24+h w
	source['a'] = source.filter(regex='Id10383')
	source.loc[(source['a'] == 'yes'), 'i383o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i383o'] = 'n'

	#306) Was the liquor foul smelling when the waters broke?	liq smell
	source['a'] = source.filter(regex='Id10384')
	source.loc[(source['a'] == 'yes'), 'i384o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i384o'] = 'n'

	#307) Was the liquor a green or brown colour when the waters broke?	liq gr-br
	source['a'] = source.filter(regex='Id10385')
	source.loc[(source['a'] == 'green_or_brown'), 'i385a'] = 'y'
	source.loc[(source['a'] == 'clear'), 'i385a'] = 'n'
	source.loc[(source['a'] == 'other'), 'i385a'] = 'n'

	#308) Was the delivery normal vaginal, without forceps or vacuum?	born n del
	source['a'] = source.filter(regex='Id10387')
	source.loc[(source['a'] == 'yes'), 'i387o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i387o'] = 'n'

	#309) Was the delivery vaginal, with forceps or vacuum?	born as del
	source['a'] = source.filter(regex='Id10388')
	source.loc[(source['a'] == 'yes'), 'i388o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i388o'] = 'n'

	#310) Was the delivery a Caesarean section?	born cs
	source['a'] = source.filter(regex='Id10389')
	source.loc[(source['a'] == 'yes'), 'i389o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i389o'] = 'n'

	#311) Did the child's mother receive any vaccinations since reaching adulthood including during this pregnancy?	moth vacc
	source['a'] = source.filter(regex='Id10391')
	source.loc[(source['a'] == 'yes'), 'i391o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i391o'] = 'n'

	#312) Did the child's mother receive tetnus toxoid (TT) vaccine?	moth tt NOTE: this is differnet in probbase.xls
	source['a'] = source.filter(regex='Id10393')
	source.loc[(source['a'] == 'yes'), 'i393o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i393o'] = 'n'

	#313) Was this baby born from the mother's first pregnancy?	born 1st pr
	source['a'] = source.filter(regex='Id10394')
	source.loc[(source['a'] == 0), 'i394a'] = 'y'
	source.loc[(source['a'] > 0), 'i394a'] = 'n'

	#314) Did the baby's mother have four or more births before this one?	born 4+ pr
	source['a'] = source.filter(regex='Id10394')
	source.loc[(source['a'] >= 4), 'i394b'] = 'y'
	source.loc[(source['a'] < 4), 'i394b'] = 'n'

	#315) During labour, did the baby's mother suffer from fever?	moth fev
	source['a'] = source.filter(regex='Id10395')
	source.loc[(source['a'] == 'yes'), 'i395o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i395o'] = 'n'

	#316) During the last 3 months of pregnancy, labour or delivery, did the baby's mother suffer from high blood pressure?	moth hypt
	source['a'] = source.filter(regex='Id10396')
	source.loc[(source['a'] == 'yes'), 'i396o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i396o'] = 'n'

	#317) Did the baby's mother have diabetes mellitus?	moth diab
	source['a'] = source.filter(regex='Id10397')
	source.loc[(source['a'] == 'yes'), 'i397o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i397o'] = 'n'

	#318) Did the baby's mother have foul smelling vaginal discharge during pregnancy or after delivery?	moth disch
	source['a'] = source.filter(regex='Id10398')
	source.loc[(source['a'] == 'yes'), 'i398o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i398o'] = 'n'

	#319) During the last 3 months of pregnancy, labour or delivery, did the baby's mother suffer from convulsions?	moth conv
	source['a'] = source.filter(regex='Id10399')
	source.loc[(source['a'] == 'yes'), 'i399o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i399o'] = 'n'

	#320) During the last 3 months of pregnancy did the baby's mother suffer from blurred vision?	moth bl vis
	source['a'] = source.filter(regex='Id10400')
	source.loc[(source['a'] == 'yes'), 'i400o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i400o'] = 'n'

	#321) Did the baby's mother have severe anaemia?	moth anaem
	source['a'] = source.filter(regex='Id10401')
	source.loc[(source['a'] == 'yes'), 'i401o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i401o'] = 'n'

	#322) Did the baby's mother have vaginal bleeding during the last 3 months of pregnancy but before labour started?	moth bleed
	source['a'] = source.filter(regex='Id10402')
	source.loc[(source['a'] == 'yes'), 'i402o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i402o'] = 'n'

	#323) Did the baby's bottom, feet, arm or hand come out of the vagina before its head?	breech
	source['a'] = source.filter(regex='Id10403')
	source.loc[(source['a'] == 'yes'), 'i403o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i403o'] = 'n'

	#324) Was the umbilical cord wrapped more than once around the baby's neck at birth?	cord wrap
	source['a'] = source.filter(regex='Id10404')
	source.loc[(source['a'] == 'yes'), 'i404o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i404o'] = 'n'

	#325) Was the umbilical cord delivered first?	cord first
	source['a'] = source.filter(regex='Id10405')
	source.loc[(source['a'] == 'yes'), 'i405o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i405o'] = 'n'

	#326) Was the baby blue in colour at birth?	born blue
	source['a'] = source.filter(regex='Id10406')
	source.loc[(source['a'] == 'yes'), 'i406o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i406o'] = 'n'

	#327) Before the illness that led to death, was the baby/child growing normally?	grow norm
	source['a'] = source.filter(regex='Id10408')
	source.loc[(source['a'] == 'yes'), 'i408o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i408o'] = 'n'

	#328) Did (s)he drink alcohol?	alco
	source['a'] = source.filter(regex='Id10411')
	source.loc[(source['a'] == 'yes'), 'i411o'] = 'y'
	source.loc[(source['a'] == ''), 'i411o'] = 'n'

	#329) Did (s)he use tobacco?	tobac
	source['a'] = source.filter(regex='Id10412')
	source.loc[(source['a'] == 'yes'), 'i412o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i412o'] = 'n'

	#330) Did (s)he smoke tobacco (cigarette, cigar, pipe, etc.)?	smoke
	source['a'] = source.filter(regex='Id10413')
	source.loc[(source['a'] == 'yes'), 'i413o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i413o'] = 'n'

	#331) Did (s)he use non-smoking tobacco?	tobac ns
	source['a'] = source.filter(regex='Id10414')
	source.loc[(source['a'] == 'chewing_tobacco'), 'i414a'] = 'y'
	source.loc[(source['a'] == 'cigarettes'), 'i414a'] = 'n'
	source.loc[(source['a'] == 'pipe'), 'i414a'] = 'n'
	source.loc[(source['a'] == 'local_form_of_tobacco'), 'i414a'] = 'n'
	source.loc[(source['a'] == 'other'), 'i414a'] = 'n'

	#332) Did (s)he smoke at least 10 cigarettes daily?	cigs >10
	source['a'] = source.filter(regex='Id10415')
	source.loc[(source['a'] >= 10), 'i415a'] = 'y'
	source.loc[(source['a'] < 10), 'i415a'] = 'n'

	#333) Did (s)he receive any treatment for the illness that led to death?	treat
	source['a'] = source.filter(regex='Id10418')
	source.loc[(source['a'] == 'yes'), 'i418o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i418o'] = 'n'

	#334) Did (s)he receive oral rehydration salts?	tr ors
	source['a'] = source.filter(regex='Id10419')
	source.loc[(source['a'] == 'yes'), 'i419o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i419o'] = 'n'

	#335) Did (s)he receive (or need) intravenous fluids (drip) treatment?	tr drip
	source['a'] = source.filter(regex='Id10420')
	source.loc[(source['a'] == 'yes'), 'i420o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i420o'] = 'n'

	#336) Did (s)he receive (or need) a blood transfusion?	tr blood
	source['a'] = source.filter(regex='Id10421')
	source.loc[(source['a'] == 'yes'), 'i421o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i421o'] = 'n'

	#337) Did (s)he receive (or need) treatment/food through a tube passed through the nose?	tr ngt
	source['a'] = source.filter(regex='Id10422')
	source.loc[(source['a'] == 'yes'), 'i422o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i422o'] = 'n'

	#338) Did (s)he receive (or need) injectable antibiotics?	tr inj ab
	source['a'] = source.filter(regex='Id10423')
	source.loc[(source['a'] == 'yes'), 'i423o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i423o'] = 'n'

	#339) Did (s)he receive (or need) antiretroviral therapy (ART)?	tr art
	source['a'] = source.filter(regex='Id10424')
	source.loc[(source['a'] == 'yes'), 'i424o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i424o'] = 'n'

	#340) Did (s)he have (or need) an operation for the illness?	tr oper
	source['a'] = source.filter(regex='Id10425')
	source.loc[(source['a'] == 'yes'), 'i425o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i425o'] = 'n'

	#341) Did (s)he have the operation within 1 month before death?	tr op <1m
	source['a'] = source.filter(regex='Id10426')
	source.loc[(source['a'] == 'yes'), 'i426o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i426o'] = 'n'

	#342) Was (s)he discharged from hospital very ill?	tr disc ill
	source['a'] = source.filter(regex='Id10427')
	source.loc[(source['a'] == 'yes'), 'i427o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i427o'] = 'n'

	#343) Did (s)he receive appropriate immunizations?	immun
	source['a'] = source.filter(regex='Id10428')
	source.loc[(source['a'] == 'yes'), 'i428o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i428o'] = 'n'

	#344) In the final days before death, did s/he travel to a hospital or health facility?	q trav
	source['a'] = source.filter(regex='Id10450')
	source.loc[(source['a'] == 'yes'), 'i450o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i450o'] = 'n'

	#345) Did (s)he use motorised transport to get to the hospital or health facility?	q trans
	source['a'] = source.filter(regex='Id10451')
	source.loc[(source['a'] == 'yes'), 'i451o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i451o'] = 'n'

	#346) Were there any problems during admission to the hospital or health facility?	q admit
	source['a'] = source.filter(regex='Id10452')
	source.loc[(source['a'] == 'yes'), 'i452o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i452o'] = 'n'

	#347) Were there any problems with the way (s)he was treated (medical treatment, procedures, interpersonal attitudes, respect, dignity) in the hospital or health facility?	q treat
	source['a'] = source.filter(regex='Id10453')
	source.loc[(source['a'] == 'yes'), 'i453o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i453o'] = 'n'

	#348) Were there any problems getting medications, or diagnostic tests in the hospital or health facility?	q meds
	source['a'] = source.filter(regex='Id10454')
	source.loc[(source['a'] == 'yes'), 'i454o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i454o'] = 'n'

	#349) Does it take more than 2 hours to get to the nearest hospital or health facility from the deceased's household?	q dist
	source['a'] = source.filter(regex='Id10455')
	source.loc[(source['a'] == 'yes'), 'i455o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i455o'] = 'n'

	#350) In the final days before death, were there any doubts about whether medical care was needed?	q doubt
	source['a'] = source.filter(regex='Id10456')
	source.loc[(source['a'] == 'yes'), 'i456o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i456o'] = 'n'

	#351) In the final days before death, was traditional medicine used?	q tmed
	source['a'] = source.filter(regex='Id10457')
	source.loc[(source['a'] == 'yes'), 'i457o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i457o'] = 'n'

	#352) In the final days before death, did anyone use a telephone or cell phone to call for help?	q phone
	source['a'] = source.filter(regex='Id10458')
	source.loc[(source['a'] == 'yes'), 'i458o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i458o'] = 'n'

	#353) Over the course of illness, did the total costs of care and treatment prohibit other household payments?	q costs
	source['a'] = source.filter(regex='Id10459')
	source.loc[(source['a'] == 'yes'), 'i459o'] = 'y'
	source.loc[(source['a'] == 'no'), 'i459o'] = 'n'

	# # Out to CSV
	out = source[['meta-instanceID', "i004a", "i004b", "i019a", "i019b", "i022a", "i022b", "i022c", "i022d",
			"i022e", "i022f", "i022g", "i022h", "i022i", "i022j", "i022k", "i022l",
			"i022m", "i022n", "i059o", "i077o", "i079o", "i082o", "i083o", "i084o",
			"i085o", "i086o", "i087o", "i089o", "i090o", "i091o", "i092o", "i093o",
			"i094o", "i095o", "i096o", "i098o", "i099o", "i100o", "i104o", "i105o",
			"i106a", "i107o", "i108a", "i109o", "i110o", "i111o", "i112o", "i113o",
			"i114o", "i115o", "i116o", "i120a", "i120b", "i123o", "i125o", "i127o",
			"i128o", "i129o", "i130o", "i131o", "i132o", "i133o", "i134o", "i135o",
			"i136o", "i137o", "i138o", "i139o", "i140o", "i141o", "i142o", "i143o",
			"i144o", "i147o", "i148a", "i148b", "i148c", "i149o", "i150a", "i151a",
			"i152o", "i153o", "i154a", "i154b", "i155o", "i156o", "i157o", "i158o",
			"i159o", "i161a", "i165a", "i166o", "i167a", "i167b", "i168o", "i169a",
			"i169b", "i170o", "i171o", "i172o", "i173a", "i174o", "i175o", "i176a",
			"i178a", "i181o", "i182a", "i182b", "i182c", "i183o", "i184a", "i185o",
			"i186o", "i187o", "i188o", "i189o", "i190o", "i191o", "i192o", "i193o",
			"i194o", "i195o", "i197a", "i197b", "i199a", "i199b", "i200o", "i201a",
			"i201b", "i203a", "i204o", "i205a", "i205b", "i207o", "i208o", "i209a",
			"i209b", "i210o", "i211a", "i212o", "i213o", "i214o", "i215o", "i216a",
			"i217o", "i218o", "i219o", "i220o", "i221a", "i221b", "i222o", "i223o",
			"i224o", "i225o", "i226o", "i227o", "i228o", "i229o", "i230o", "i231o",
			"i232a", "i233o", "i234a", "i234b", "i235a", "i235b", "i235c", "i235d",
			"i236o", "i237o", "i238o", "i239o", "i240o", "i241o", "i242o", "i243o",
			"i244o", "i245o", "i246o", "i247o", "i248a", "i249o", "i250a", "i251o",
			"i252o", "i253o", "i254o", "i255o", "i256o", "i257o", "i258o", "i259o",
			"i260a", "i260b", "i260c", "i260d", "i260e", "i260f", "i260g", "i261o",
			"i262a", "i263a", "i263b", "i264o", "i265o", "i266a", "i267o", "i268o",
			"i269o", "i270o", "i271o", "i272o", "i273o", "i274a", "i275o", "i276o",
			"i277o", "i278o", "i279o", "i281o", "i282o", "i283o", "i284o", "i285a",
			"i286o", "i287o", "i288o", "i289o", "i290o", "i294o", "i295o", "i296o",
			"i297o", "i298o", "i299o", "i300o", "i301o", "i302o", "i303a", "i304o",
			"i305o", "i306o", "i309o", "i310o", "i312o", "i313o", "i314o", "i315o",
			"i316o", "i317o", "i318o", "i319a", "i319b", "i320o", "i321o", "i322o",
			"i323o", "i324o", "i325o", "i326o", "i327o", "i328o", "i329o", "i330o",
			"i331o", "i332a", "i333o", "i334o", "i335o", "i336o", "i337a", "i337b",
			"i337c", "i338o", "i340o", "i342o", "i343o", "i344o", "i347o", "i354o",
			"i355a", "i356o", "i357o", "i358a", "i360a", "i360b", "i360c", "i361o",
			"i362o", "i363o", "i364o", "i365o", "i367a", "i367b", "i367c", "i368o",
			"i369o", "i370o", "i371o", "i372o", "i373o", "i376o", "i377o", "i382a",
			"i383o", "i384o", "i385a", "i387o", "i388o", "i389o", "i391o", "i393o",
			"i394a", "i394b", "i395o", "i396o", "i397o", "i398o", "i399o", "i400o",
			"i401o", "i402o", "i403o", "i404o", "i405o", "i406o", "i408o", "i411o",
			"i412o", "i413o", "i414a", "i415a", "i418o", "i419o", "i420o", "i421o",
			"i422o", "i423o", "i424o", "i425o", "i426o", "i427o", "i428o", "i450o",
			"i451o", "i452o", "i453o", "i454o", "i455o", "i456o", "i457o", "i458o",
			"i459o"]]


	out.to_csv(final, index=False)

# coding: utf-8

import pandas as pd
import numpy as np 

def source(file, final):

	source = pd.read_csv(file)
	source = source.astype(object)
	source = source.ix[:, ~source.columns.str.contains('Remain')]

	# ### Elder
	source['a'] = source.filter(regex='ageInYears')
	source['b'] = source.filter(regex='age_adult')

	source.loc[(source['a'] >= 65), "ELDER"] = "y"
	source.loc[(source['b'] >= 65), "ELDER"] = "y"

	# ### Midage
	source.loc[(source["a"] >= 50) & (source["a"]<=64), "MIDAGE"] = "y"
	source.loc[(source["b"] >= 50) & (source["b"]<=64), "MIDAGE"] = "y"

	source['MIDAGE'] = source['MIDAGE'].astype(object)

	# ### Adult
	source['a'] = source.filter(regex='isAdult1')
	source['b'] = source.filter(regex='isAdult2')

	source.loc[(source["a"] == 1) & (source["ELDER"] != "y") & (source["MIDAGE"] != "y"), "ADULT"] = "y"
	source.loc[(source["b"] == 1) & (source["ELDER"] != "y") & (source["MIDAGE"] != "y"), "ADULT"] = "y"

	# ### Child
	# #### ischild == TRUE
	source['a'] = source.filter(regex='isChild')
	source['b'] = source.filter(regex='isChild1')
	source['c'] = source.filter(regex='isChild2')

	source.loc[(source['a'] ==1), "CHILD"] = "y"
	source.loc[(source['b'] ==1), "CHILD"] = "y"
	source.loc[(source['c'] ==1), "CHILD"] = "y"

	# #### ageinyears is between 1 and 4
	source['a'] = source.filter(regex='ageInYears')
	source['b'] = source.filter(regex='age_group')
	source['c'] = source.filter(regex='age_child_unit')
	source['d'] = source.filter(regex='ageInMonths')
	source['e'] = source.filter(regex='age_child_days')
	source['f'] = source.filter(regex='age_child_months')
	source['g'] = source.filter(regex='age_child_years')

	source.loc[(source["a"] >= 1) & (source["a"] <= 4), "CHILD"] = "y"

	# #### agegroup child & unit=days & between 1x365.25 and 5x365.25 
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'days') & (source["e"] >= 1*365.25) & (source["e"] <= 5*365.25-1) , "CHILD"] = "y"

	# #### agegroup child & unit=months & between 1x12 and 5x12-1 
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'months') & (source["f"] >= 1*12) & (source["f"] <= 5*12-1) , "CHILD"] = "y" 

	# #### agegroup child & unit=years & between 1 and 4
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'years') & (source["g"] >= 1) & (source["g"] <= 4) , "CHILD"] = "y" 

	# #### age in months between 1 and 11
	source.loc[(source["d"] >= 1) & (source["d"] <= 11) , "CHILD"] = "y" 

	# #### agegroup child & unit=days & age child days between 30.4 and 12X30.4-1
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'days') & (source["e"] >= 30.4) & (source["e"] <= 12*30.4-1), "CHILD"] = "y" 

	# #### agegroup child & unit=months & age child months between 1 and 11
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'months') & (source["f"] >= 1) & (source["f"] <= 11), "CHILD"] = "y" 

	# ### UNDER5
	# #### ageinyears is between 1 and 4
	source.loc[(source["a"] >= 1) & (source["a"] <= 4), "UNDER5"] = "y"

	# #### agegroup child & unit=days & age child days between 1 and 4
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'days') & (source["e"] >= 1*365.25) & (source["e"] <= 5*365.25-1) , "UNDER5"] = "y"

	# #### agegroup child & unit=months & between 1x12 and 5x12-1 
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'months') & (source["f"] >= 1*12) & (source["f"] <= 5*12-1) , "UNDER5"] = "y" 

	# #### agegroup child & unit=years & between 1 and 4
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'years') & (source["g"] >= 1) & (source["g"] <= 4) , "CHILD"] = "y" 

	# ### INFANT
	# #### age in months between 1 and 11
	source.loc[(source["d"] >= 1) & (source["d"] <= 11) , "INFANT"] = "y" 

	# #### agegroup child & unit=days & age child days between 30.4 and 12X30.4-1
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'days') & (source["e"] >= 30.4) & (source["e"] <= 12*30.4-1), "INFANT"] = "y" 

	# #### agegroup child & unit=months & between 1 and 11 
	source.loc[(source['b'] == 'child' ) & (source["c"] == 'months') & (source["f"] >= 1) & (source["f"] <= 11) , "INFANT"] = "y" 

	# ### NEONATE
	source['a'] = source.filter(regex='isNeonatal')
	source['b'] = source.filter(regex='isNeonatal1')
	source['c'] = source.filter(regex='isNeonatal2')

	source.loc[(source["a"] == 1), "NEONATE"] = 'y'
	source.loc[(source["b"] == 1), "NEONATE"] = 'y'
	source.loc[(source["c"] == 1), "NEONATE"] = 'y'

	# ### Male
	source['a'] = source.filter(regex='id1A110')
	source['b'] = source.filter(regex='ageInYears')
	source['c'] = source.filter(regex='age_group')
	source['d'] = source.filter(regex='ageInMonths')
	source['e'] = source.filter(regex='age_adult')


	source.loc[(source['a'] == 'male') , "MALE" ] = "y"

	# ### FEMALE
	source.loc[(source['a'] == 'female') , "FEMALE" ] = "y"

	# ### MAGEP1
	# #### FEMALE & age in years between 12 to 19 
	source.loc[(source['a'] == 'female') & (source["b"] >= 12) & (source["b"] <= 19) , "MAGEP1"] = "y"

	# #### FEMALE adult & age adult between 12 to 19
	source.loc[(source['a'] == 'female') & (source['c'] == 'adult') & (source['e'] >= 12) &(source['e'] <= 19) , "MAGEP1"] = 'Y'

	# ### MAGEP2
	# #### FEMALE & age in years between 20 to 34
	source.loc[(source['a'] == 'female') & (source["b"] >= 20) & (source["b"] <= 34) , "MAGEP2"] = "y"

	# #### FEMALE adult & age adult between 20 to 34
	source.loc[(source['a'] == 'female') & (source['c'] == 'adult') & (source['e'] >= 20) &(source['e'] <= 34) , "MAGEP2"] = 'Y'

	# ### MAGEP3
	# #### FEMALE & age in years between 35 to 49
	source.loc[(source['a'] == 'female') & (source["b"] >= 35) & (source["b"] <= 49) , "MAGEP3"] = "y"

	# #### FEMALE adult & age adult between 35 to 49
	source.loc[(source['a'] == 'female') & (source['c'] == 'adult') & (source['e'] >= 35) &(source['e'] <= 49) , "MAGEP3"] = 'Y'

	# ### DIED_D1
	# #### age in days == 0
	source['a'] = source.filter(regex='ageInDays')
	source['b'] = source.filter(regex='age_group')
	source['c'] = source.filter(regex='age_neonate_days')
	source['d'] = source.filter(regex='age_neonate_minutes')
	source['e'] = source.filter(regex='age_neonate_hours')

	source.loc[(source['a'] == 0), "DIED_D1"] = 'y'

	# #### neonate & neonate days <=1
	source.loc[(source['b'] == 'neonate') & (source['c'] <= 1) , "DIED_D1" ] = 'y'

	# #### neonate & neonate minutes < 24x60
	source.loc[(source['b'] == 'neonate') & (source['d'] <= 24*60) , "DIED_D1" ] = 'y'

	# #### neonate & neonate hours <=24 
	source.loc[(source['b'] == 'neonate') & (source['e'] <= 24) , "DIED_D1" ] = 'y'

	# ### DIED_D23
	# #### age in days == 1
	source.loc[(source['a'] == 1), "DIED_D23"] = 'y'

	# #### neonate & neonate days >0 & <=2
	source.loc[(source['b'] == 'neonate') & (source['c'] > 0) & (source['c'] <=2) , "DIED_D23" ] = 'y'

	# #### neonate & neonate minutes > 24x60 & <= 2x24x60
	source.loc[(source['b'] == 'neonate') & (source['d'] > 24*60) & (source['d'] <= 2*24*60), "DIED_D23" ] = 'y'

	# #### neonate & neonate hours >24 & <=48 
	source.loc[(source['b'] == 'neonate') & (source['e'] > 24) & (source['e'] <= 48) , "DIED_D23" ] = 'y'

	# ### DIED_D36
	# #### age in days >2 & <=7
	source.loc[(source['a'] > 2) & (source['a'] <=7), "DIED_D36"] = 'y'

	# #### neonate & neonate days >2 & <=7
	source.loc[(source['b'] == 'neonate') & (source['c'] > 2) & (source['c'] <= 7) , "DIED_D36" ] = 'y'

	# #### neonate & neonate minutes > 2x24x60 & <= 7x24x60
	source.loc[(source['b'] == 'neonate') & (source['d'] > 2*24*60) & (source['d'] <= 7*24*60), "DIED_D36" ] = 'y'

	# #### neonate & neonate hours > 48 & <=7x24 
	source.loc[(source['b'] == 'neonate') & (source['e'] > 48) & (source['e'] <= 7*24) , "DIED_D36" ] = 'y'

	# ### DIED_W1
	# #### age in days >7 & <=28
	source.loc[(source['a'] > 7) & (source['a'] <=28), "DIED_W1"] = 'y'

	# #### neonate & neonate days >7 & <=28
	source.loc[(source['b'] == 'neonate') & (source['c'] > 7) & (source['c'] <= 28) , "DIED_W1" ] = 'y'

	# #### neonate & neonate minutes > 7x24x60 & <= 28x24x60
	source.loc[(source['b'] == 'neonate') & (source['d'] > 7*24*60) & (source['d'] <= 28*24*60), "DIED_W1" ] = 'y'

	# #### neonate & neonate hours > 7x24  & <=28x24 
	source.loc[(source['b'] == 'neonate') & (source['e'] > 7*24) & (source['e'] <= 28*24) , "DIED_W1" ] = 'y'

	# ### ACUTE
	# #### was ill for less than 3 weeks before death
	source['a'] = source.filter(regex='Id3A300')

	source.loc[(source['a'] > 0 ) & (source['a'] < 21 ), "ACUTE"] = 'y'

	# ### CHRONIC
	# #### ill for 3 weeks or more before death
	source.loc[(source['a'] >= 21 ), "CHRONIC"] = 'y'

	# ### SUDDEN
	source['a'] = source.filter(regex='Id3A310')
	source.loc[(source['a'] == 'yes' ), "SUDDEN"] = 'y'

	# ### WET_SEAS
	source['a'] = source.filter(regex='Id3A280')
	source.loc[(source['a'] =='wet'), "WET_SEAS"] = 'y'

	# ### DRY_SEAS
	source.loc[(source['a'] =='dry'), "DRY_SEAS"] = 'y'

	# ### HEART_DIS
	source['a'] = source.filter(regex='Id3A160')
	source.loc[(source['a'] =='yes'), "HEART_DIS"] = 'y'

	# ### TUBER
	source['a'] = source.filter(regex='Id3A100')
	source.loc[(source['a'] =='yes'), "TUBER"] = 'y'

	# ### HIV_AIDS
	source['a'] = ""
	source.loc[(source['a'] =='yes'), "HIV_AIDS"] = 'y'
	source.loc[(source['a'] =='yes'), "HIV_AIDS"] = 'y'

	# ### HYPERT
	source['a'] = source.filter(regex='Id3A150')
	source.loc[(source['a'] =='yes'), "HYPERT"] = 'y'

	# ### DIABETES
	source['a'] = ""
	source.loc[(source['a'] =='yes'), "DIABETES"] = 'y'

	# ### ASTHMA
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "ASTHMA"] = 'y'
	# ### EPILEPSY
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "EPILEPSY"] = 'y'

	# ### CANCER
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "CANCER"] = 'y'

	# ### COPD
	source['a'] = source.filter(regex='Id3A210')
	source.loc[(source['a'] == 'yes'), "COPD"] = 'y'

	# ### DEMENT
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "DEMENT"] = 'y'

	# ### DEPRESS
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "DEPRESS"] = 'y'

	# ### STROKE
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "STROKE"] ='y'

	# ### SICKLE
	source['a'] = source.filter(regex='Id3A250')
	source.loc[(source['a'] == 'yes'), "SICKLE"] ='y'

	# ### KIDNEY_DIS
	source['a'] = source.filter(regex='Id3A260')
	source.loc[(source['a'] == 'yes'), "KIDNEY_DIS"] ='y'

	# ### LIVER_DIS
	source['a'] = source.filter(regex='Id3A270')
	source.loc[(source['a'] == 'yes'), "LIVER_DIS"] ='y'

	# ### MEASLES
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MEASLES"] ='y'

	# ### MEN_CON
	source['a'] = source.filter(regex='Id3B420')
	source.loc[(source['a'] == 'yes'), "MEN_CON"] ='y'

	# ### MENCON3
	source['a'] = source.filter(regex='Id3B420')
	source['b'] = source.filter(regex='Id3B430')

	source.loc[(source['a'] == 'yes') & (source['b'] >= 3), "MENCON3"] ='y'

	# ### MALARIA
	source['a'] = source.filter(regex='Id3A120')
	source.loc[(source['a'] == 'yes'), "MALARIA"] ='y'

	# ### MALARNEG
	source['a'] = source.filter(regex='Id3A130')
	source.loc[(source['a'] == 'yes'), "MALARNEG"] ='y'

	# ### FEVER
	source['a'] = source.filter(regex='Id3B100')
	source['b'] = ""
	source['c'] = ""
	source.loc[(source['a'] == 'yes') , "FEVER"] ='y' 
	source.loc[(source['b'].str.contains('Fever') == True) , "FEVER"] ='y'
	source.loc[(source['c'].str.contains('fever') == True) , "FEVER"] ='y'

	# ### AC_FEVER
	source['a'] = source.filter(regex='Id3B100')
	source['b'] = np.nan


	source.loc[(source['a'] == 'yes') & (source['b'] <14) & (source['b'] > 0.001), "AC_FEVER"] ='y'

	# ### CH_FEVER
	source.loc[(source['a'] == 'yes') & (source['b'] >=14), "CH_FEVER"] ='y'

	# ### NIGHT_SW
	source['a'] = source.filter(regex='Id3B120')
	source['b'] = source.filter(regex='Id3B130')
	source['c'] = source.filter(regex='Id3B140')


	source.loc[(source['a'] == 'yes'), "NIGHT_SW"] ='y'

	# ### COUGH
	source.loc[(source['b'] == 'yes'), "COUGH"] = 'y'

	# ### AC_COUGH
	source.loc[(source['b'] == 'yes') & (source['c'] < 21) & (source['c'] > 0.001), "AC_COUGH"] ='y'

	# ### CH_COUGH
	source.loc[(source['b'] == 'yes') & (source['c'] >= 21), "CH_COUGH"] ='y'

	# ### PR_COUGH
	source['a'] = source.filter(regex='Id3B150')
	source.loc[(source['a'] == 'yes'), "PR_COUGH"] ='y'

	# ### BL_COUGH
	source['a'] = source.filter(regex='Id3B160')
	source.loc[(source['a'] == 'yes'), "BL_COUGH"] ='y'

	# ### WHOOP
	source['a'] = source.filter(regex='Id3B170')
	source.loc[(source['a'] == 'yes'), "WHOOP"] ='y'

	# ### BREATH
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "BREATH"] ='y'

	# ### RAPID_BR
	source['a'] = source.filter(regex='Id3B190')
	source.loc[(source['a'] == 'yes'), "RAPID_BR"] ='y'

	# ### AC_RPBR
	source['a'] = source.filter(regex='Id3B190')
	source['b'] = np.nan
	source['c'] = source.filter(regex='Id3B210')
	source['d'] = np.nan
	source['e'] = source.filter(regex='Id3B230')
	source['f'] = source.filter(regex='Id3B240')
	source['g'] = source.filter(regex='Id3B250')
	source['h'] = ""
	source['i'] = source.filter(regex='Id3B270')
	source['j'] = ""

	source.loc[(source['a'] == 'yes') & (source['b'] <14) & (source['b'] > 0.001), "AC_RPBR"] ='y'

	# ### CH_RPBR
	source.loc[(source['a'] == 'yes') & (source['b'] >=14), "CH_RPBR"] ='y'

	# ### BR_LESS
	source.loc[(source['c'] == 'yes'), "BR_LESS"] ='y'
	source.loc[(source['j'].str.contains('respiratory_distress') == True) , "BR_LESS"] ='y'

	# ### AC_BRL
	source.loc[(source['c'] == 'yes') & (source['d'] <2*7) & (source['d'] >0), "AC_BRL"] ='y'

	# ### CH_BRL
	source.loc[(source['c'] == 'yes') & (source['d'] >= 2*7), "CH_BRL"] ='y'

	# ### EXERT_BR
	source.loc[(source['c'] == 'yes') & (source['e'] == 'yes'), "EXERT_BR"] ='y'

	# ### LYING_BR
	source.loc[(source['c'] == 'yes') & (source['f'] == 'yes'), "LYING_BR"] ='y'

	# ### CHEST_IN
	source.loc[(source['g'] == 'yes'), "CHEST_IN"] ='y'

	# ### WHEEZE
	source.loc[(source['h'] == 'stridor') | (source['h'] == 'grunting') | (source['h'] == 'wheezing') , "WHEEZE"] ='y'

	# ### CH_PAIN
	source.loc[(source['i'] == 'yes'), "CH_PAIN"] ='y'

	# ### YELLOW
	source['a'] = source.filter(regex='Id3B750')
	source['b'] = ""
	source['c'] = ""
	source['d'] = ""
	source['e'] = np.nan
	source['f'] = source.filter(regex='Id3B300')
	source['g'] = source.filter(regex='Id3B310')
	source['h'] = ""
	source['i'] = ""
	source['j'] = ""

	source.loc[(source['a'] == 'yes')| (source['b'] == 'Jaundice') | (source['b'] == 'jaundice'), "YELLOW"] ='y'

	# ### DIARR
	source.loc[(source['c'] == 'yes') | (source['d'] =='diarrhea' ), "DIARR"] ='y'

	# ### AC_DIARR
	source.loc[(source['c'] == 'yes') & (source['e'] <14) & (source['e'] > 0.001) , "AC_DIARR"] ='y'

	# ### PE_DIARR
	source.loc[(source['c'] == 'yes') & (source['e'] >= 14) & (source['e'] <4*7), "PE_DIARR"] ='y'

	# ### CH_DIARR
	source.loc[(source['c'] == 'yes') & (source['e'] > 4*7), "CH_DIARR"] ='y'

	# ### BL_DIARR
	source.loc[(source['c'] == 'yes') & (source['f'] == 'yes'), "BL_DIARR"] ='y'

	# ### VOMITING
	source.loc[(source['g'] == 'yes'), "VOMITING"] ='y'

	# ### BL_VOMIT
	source.loc[(source['h'] == 'yes') & (source['i'] == 'yes'), "BL_VOMIT"] ='y'
	source.loc[(source['h'] == 'yes') & (source['j'] == 'yes'), "BL_VOMIT"] ='y'

	# ### ABDOM
	source['a'] = source.filter(regex='Id3B330')
	source['b'] = source.filter(regex='Id3B340')
	source['c'] = ""
	source['d'] = np.nan
	source['e'] = np.nan
	source['f'] = np.nan
	source['g'] = np.nan

	source.loc[(source['a'] == 'yes'), "ABDOM"] ='y'

	# ### ABD_PAIN
	source.loc[(source['b'] == 'yes') & (source['c'] == 'yes')  , "ABD_PAIN"] ='y'

	# ### AC_ABDP 
	source.loc[(source['c'] == 'yes') & (source['d'] <= 2*7) & (source['d'] >0.001) & (source['e'] <= 24* 2*7) & (source['e'] >0.001) & (source['e'] >0.001) & (source['f'] <= 2) & (source['g'] < 0) & (source['e'] >0.001) & (source['f'] <= 2) & (source['g'] >0.001), "AC_ABDP"] ='y'

	# ### CH_ABDP
	source.loc[(source['c'] == 'yes') & (source['d'] >= 2*7), "CH_ABDP"] ='y'
	source.loc[(source['c'] == 'yes') & (source['e'] >= 24* 2*7), "CH_ABDP"] ='y'
	source.loc[(source['c'] == 'yes') & (source['f'] >= 2), "CH_ABDP"] ='y'
	source.loc[(source['c'] == 'yes') & (source['g'] > 0), "CH_ABDP"] ='y'

	# ### SWE_ABD
	source['a'] = source.filter(regex='Id3B360')
	source.loc[(source['a'] == 'yes'), "SWE_ABD"] ='y'

	# ### AC_SWAB
	source['a'] = source.filter(regex='Id3B360')
	source['b'] = np.nan
	source['c'] = np.nan
	source['d'] = ""
	source['e'] = source.filter(regex='Id3B380')
	source['f'] = np.nan
	source['g'] = np.nan
	source['h'] = source.filter(regex='Id3B400')

	source.loc[(source['a'] == 'yes') & (source['b'] < 2*7) & (source['b'] > 0.001) & (source['c'] < 0) & (source['c'] >0.001), "AC_SWAB"] ='y'

	# ### CH_SWAB
	source.loc[(source['b'] > 2*7) | (source['c'] > 0.001), "CH_SWAB"] ='y'

	# ### ABD_MASS
	source.loc[(source['e'] == 'yes'), "ABD_MASS"] ='y'

	# ### AC_ABDM
	source.loc[(source['e'] == 'yes') & (source['f'] < 2*7 )& (source['f'] > 0.001) & (source['g'] < 1) & (source['g'] > 0.001), "AC_ABDM"] ='y'

	# ### CH_ABDM
	source.loc[(source['f'] >= 2*7) | (source['g'] >= 1), "CH_ABDM"] ='y'

	# ### HEADACHE
	source.loc[(source['h'] == 'yes'), "HEADACHE"] ='y'

	# ### SKIN
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "SKIN"] ='y'

	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "SKIN"] ='y'

	source['a'] = source.filter(regex='Id3B560')
	source.loc[(source['a'] == 'yes'), "SKIN"] ='y'

	# ### SKIN_LES
	source['a'] = ""
	source['b'] = ""

	source.loc[(source['a'] == 'yes') & (source['b'] != 'yes'), "SKIN_LES"] ='y'

	# ### SK_FEET
	source.loc[(source['b'] == 'yes'), "SK_FEET"] ='y'

	# ### RASH
	source['a'] = ""
	source['b'] = ""

	source.loc[(source['a'] == 'yes'), "RASH"] ='y'
	source.loc[(source['b'] == 'rash'), "RASH"] ='y'

	# ### AC_RASH
	source['a'] = source.filter(regex='Id3B560')
	source['b'] = source.filter(regex='Id3B570')

	source.loc[(source['a'] == 'yes') & (source['b'] > 0.001) & (source['b'] < 7) & (source['b'] > 0.001), "AC_RASH"] ='y'

	# ### CH_RASH
	source.loc[(source['a'] == 'yes') & (source['b'] >= 7), "CH_RASH"] ='y'

	# ### MEASRASH
	source['a'] = source.filter(regex='Id3B560')
	source['b'] = source.filter(regex='Id3B580')
	source['c'] = source.filter(regex='Id3B590')

	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "MEASRASH"] ='y'

	# ### HERPES
	source.loc[(source['c'] == 'yes'), "HERPES"] ='y'

	# ### STIFF_NECK
	source['a'] = source.filter(regex='Id3B405')
	source.loc[(source['a'] == 'yes'), "STIFF_NECK"] ='y'
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "STIFF_NECK"] ='y'

	# ### AC_STNK
	source['a'] = ""
	source['b'] = np.nan
	source['c'] = source.filter(regex='Id3B410')
	source['d'] = source.filter(regex='Id3B405')

	source.loc[(source['a'] == 'yes') & (source['a'] < 7) & (source['a'] > 0.001), "AC_STNK"] ='y'
	source.loc[(source['b'] == 'yes') & (source['c'] < 7) & (source['c'] > 0.001), "AC_STNK"] ='y'

	# ### CH_STNK
	source.loc[(source['d'] == 'yes') & (source['a'] >= 7) , "CH_STNK"] ='y'
	source.loc[(source['b'] == 'yes') & (source['c'] >= 7) , "CH_STNK"] ='y'

	# ### COMA
	source['a'] = source.filter(regex='Id3B440')
	source.loc[(source['a'] == 'yes'), "COMA"] ='y'

	# ### CO_ONS
	source['a'] = source.filter(regex='Id3B440')
	source['b'] = source.filter(regex='Id3B450')
	source.loc[(source['a'] == 'yes') &(source['b'] == 'yes'), "CO_ONS"] ='y'

	# ### CONVUL
	source['a'] = source.filter(regex='Id3B460')
	source.loc[(source['a'] == 'yes'), "CONVUL"] ='y'

	# ### AC_CONV
	source['a'] = source.filter(regex='Id3B460')
	source['b'] = source.filter(regex='Id3B470')
	source['c'] = source.filter(regex='Id3B480')

	source.loc[(source['a'] == 'yes') & (source['b'] > 0.001) & (source['b'] < 10) & (source['b'] >0.001), "AC_CONV"] ='y'

	# ### CH_CONV
	source.loc[(source['a'] == 'yes') & (source['b'] >= 10), "CH_CONV"] ='y'

	# ### UNC_CON
	source.loc[(source['a'] == 'yes') & (source['c'] == 'yes'), "UNC_CON"] ='y'

	# ### URINE
	source['a'] = source.filter(regex='Id3B490')
	source.loc[(source['a'] == 'yes'), "URINE"] ='y'

	# ### URI_RET
	source['a'] = source.filter(regex='Id3B490')
	source['b'] = ""
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "URI_RET"] ='y'

	# ### EXC_URINE
	source['a'] = source.filter(regex='Id3B490')
	source['b'] = source.filter(regex='Id3B510')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "EXC_URINE"] ='y'

	# ### URI_HAEM
	source['a'] = source.filter(regex='Id3B490')
	source['b'] = source.filter(regex='Id3B520')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "URI_HAEM"] ='y'

	# ### WT_LOSS
	source['a'] = source.filter(regex='Id3B610')
	source.loc[(source['a'] == 'yes'), "WT_LOSS"] ='y'

	# ### WASTING
	source['a'] = source.filter(regex='Id3B620')
	source.loc[(source['a'] == 'yes'), "WASTING"] ='y'

	# ### OR_CAND
	source['a'] = source.filter(regex='Id3B630')
	source.loc[(source['a'] == 'yes'), "OR_CAND"] ='y'

	# ### RIGIDITY
	source['a'] = source.filter(regex='Id3B640')
	source.loc[(source['a'] == 'yes'), "RIGIDITY"] ='y'

	# ### SWELL
	source['a'] = source.filter(regex='Id3B670')
	source.loc[(source['a'] == 'yes'), "SWELL"] ='y'

	# ### SWE_ORAL
	source['a'] = source.filter(regex='Id3B670')
	source['b'] = source.filter(regex='Id3B680')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "SWE_ORAL"] ='y'

	# ### SWE_NECK
	source['a'] = source.filter(regex='Id3B670')
	source['b'] = source.filter(regex='Id3B690')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "SWE_NECK"] ='y'

	# ### SWE_ARMP
	source['a'] = source.filter(regex='Id3B670')
	source['b'] = source.filter(regex='Id3B700')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "SWE_ARMP"] ='y'

	# ### SWE_BREAST
	source['a'] = source.filter(regex='Id3B720')
	source.loc[(source['a'] == 'yes'), "SWE_BREAST"] ='y'

	# ### SWE_GEN
	source['a'] = source.filter(regex='Id3B670')
	source['b'] = source.filter(regex='Id3B710')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "SWE_GEN"] ='y'

	# ### SWE_OTH
	source['a'] = source.filter(regex='Id3B650')
	source.loc[(source['a'] == 'yes'), "SWE_OTH"] ='y'

	# ### SWE_LEGS
	source['a'] = source.filter(regex='Id3B660')
	source.loc[(source['a'] == 'yes'), "SWE_LEGS"] ='y'

	# ### ANAEMIA
	source['a'] = source.filter(regex='Id3B770')
	source.loc[(source['a'] == 'yes'), "ANAEMIA"] ='y'

	# ### EXC_DRINK
	source['a'] = source.filter(regex='Id3B790')
	source.loc[(source['a'] == 'yes'), "EXC_DRINK"] ='y'

	# ### HAIR
	source['a'] = source.filter(regex='Id3B760')
	source.loc[(source['a'] == 'yes'), "HAIR"] ='y'

	# ### PARAL_ONE
	source['a'] = source.filter(regex='Id3B730')
	source.loc[(source['a'] == 'yes'), "PARAL_ONE"] ='y'

	# ### EYE_SUNK
	source['a'] = source.filter(regex='Id3B780')
	source.loc[(source['a'] == 'yes'), "EYE_SUNK"] ='y'

	# ### BL_ORIF
	source['a'] = source.filter(regex='Id3B600')
	source.loc[(source['a'] == 'yes'), "BL_ORIF"] ='y'
	source.loc[(source['a'] == 0.001), "BL_ORIF"] ='.'

	# ### VB_BET
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "VB_BET"] ='y'

	# ### VB_MEN
	source['a'] = source.filter(regex='Id3B810')
	source.loc[(source['a'] == 'yes'), "VB_MEN"] ='y'

	# ### VB_AFTER
	source['a'] = source.filter(regex='Id3B820')
	source.loc[(source['a'] == 'yes'), "VB_AFTER"] ='y'

	# ### DIFF_SW
	source['a'] = source.filter(regex='Id3B740')
	source.loc[(source['a'] == 'yes'), "DIFF_SW"] ='y'

	# ### NOT_PREG
	source['a'] = source.filter(regex='Id3C110')
	source['b'] = source.filter(regex='Id3C120')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "NOT_PREG"] ='y'
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "NOT_PREG"] ='y'

	# ### PREGNANT
	source['a'] = source.filter(regex='Id3C110')
	source.loc[(source['a'] == 'yes'), "PREGNANT"] ='y'

	# ### DEL_6WKS
	source['a'] = source.filter(regex='Id3C120')
	source.loc[(source['a'] == 'yes'), "DEL_6WKS"] ='y'

	# ### PEND_6W
	source['a'] = source.filter(regex='Id3C120')
	source['b'] = np.nan

	source.loc[(source['a'] == 'yes') & (source['b'] > 0.001) & (source['b'] < 6) & (source['b'] >0.001), "PEND_6W"] ='y'

	# ### FIRST_P
	source['a'] = source.filter(regex='Id3C230')
	source.loc[(source['a'] == 0), "FIRST_P"] ='y'

	# ### MORE4
	source['a'] = source.filter(regex='Id3C230')
	source.loc[(source['a'] >= 4), "MORE4"] ='y'

	# ### CS_PREV
	source['a'] = source.filter(regex='Id3C240')
	source.loc[(source['a'] == 'yes'), "CS_PREV"] ='y'

	# ### MULTIP
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MULTIP"] ='y'

	# ### LAB_24
	source['a'] = source.filter(regex='Id3C370')
	source.loc[(source['a'] >=24), "LAB_24"] ='y'

	# ### DIED_LAB
	source['a'] = source.filter(regex='Id3C210')
	source.loc[(source['a'] == 'yes'), "DIED_LAB"] ='y'

	# ### DEATH_24
	source['a'] = source.filter(regex='Id3C200')
	source.loc[(source['a'] == 'yes'), "DEATH_24"] ='y'

	# ### BABY_AL
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "BABY_AL"] ='y'

	# ### BREAST_FD
	source['a'] = source.filter(regex='Id3C220')
	source.loc[(source['a'] == 'yes'), "BREAST_FD"] ='y'

	# ### DEL_FAC
	source['a'] = source.filter(regex='Id3C400')
	source['b'] = source.filter(regex='Id3C430')


	source.loc[(source['a'] == 'hospital') | (source['a'] == 'other_health_facility'), "DEL_FAC"] ='y'

	# ### DEL_HOME
	source.loc[(source['a'] == 'home'), "DEL_HOME"] ='y'

	# ### DEL_ELSE
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility') | (source['a'] == 'other'), "DEL_ELSE"] ='y'

	# ### PROF_ASS
	source.loc[(source['b'] == 'yes'), "PROF_ASS"] ='y'

	# ### DEL_NORM
	source['a'] = source.filter(regex='Id3C450')
	source.loc[(source['a'] == 'yes'), "DEL_NORM"] ='y'

	# ### DEL_ASS
	source['a'] = source.filter(regex='Id3C460')
	source.loc[(source['a'] == 'yes'), "DEL_ASS"] ='y'

	# ### DEL_CS
	source['a'] = source.filter(regex='Id3C470')
	source.loc[(source['a'] == 'yes'), "DEL_CS"] ='y'

	# ### BABY_POS
	source['a'] = source.filter(regex='Id3C365')
	source.loc[(source['a'] == 'yes'), "BABY_POS"] ='y'

	# ### MON_EARLY
	source['a'] = source.filter(regex='Id3C480')
	source.loc[(source['a'] == 'yes'), "MON_EARLY"] ='y'

	# ### HYSTER
	source['a'] = source.filter(regex='Id3C440')
	source.loc[(source['a'] == 'yes'), "HYSTER"] ='y'

	# ### BPR_PREG
	source['a'] = source.filter(regex='Id3C260')
	source.loc[(source['a'] == 'yes'), "BPR_PREG"] ='y'

	# ### FIT_PREG
	source['a'] = source.filter(regex='Id3C280')
	source.loc[(source['a'] == 'yes'), "FIT_PREG"] ='y'

	# ### VIS_BL
	source['a'] = source.filter(regex='Id3C290')
	source.loc[(source['a'] == 'yes'), "VIS_BL"] ='y'

	# ### BLEED
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "BLEED"] ='y'
	source['a'] = source.filter(regex='Id3C350')
	source.loc[(source['a'] == 'yes'), "BLEED"] ='y'

	# ### E_BLEED
	source['a'] = source.filter(regex='Id3C320')
	source.loc[(source['a'] == 'yes'), "E_BLEED"] ='y'

	# ### S_BLEED
	source['a'] = source.filter(regex='Id3C330')
	source.loc[(source['a'] == 'yes'), "S_BLEED"] ='y'

	# ### D_BLEED
	source['a'] = source.filter(regex='Id3C340')
	source.loc[(source['a'] == 'yes'), "D_BLEED"] ='y'

	# ### P_BLEED
	source['a'] = source.filter(regex='Id3C350')
	source.loc[(source['a'] == 'yes'), "P_BLEED"] ='y'

	# ### PLACENT_R
	source['a'] = source.filter(regex='Id3C360')
	source.loc[(source['a'] == 'no'), "PLACENT_R"] ='y'

	# ### DISCH_SM
	source['a'] = source.filter(regex='Id3C270')
	source.loc[(source['a'] == 'yes'), "DISCH_SM"] ='y'

	# ### TERM_ATT
	source['a'] = source.filter(regex='Id3C380')
	source.loc[(source['a'] == 'yes'), "TERM_ATT"] ='y'

	# ### ABORT
	source['a'] = source.filter(regex='Id3C390')
	source.loc[(source['a'] == 'yes'), "ABORT"] ='y'

	# ### BORN_EARLY
	source['a'] = source.filter(regex='Id3D210')
	source['b'] = source.filter(regex='Id3D210')
	source.loc[(source['a'] > 0.001) & (source['b'] < 9), "BORN_EARLY"] ='y'
	source['a'] = source.filter(regex='Id3C480')
	source.loc[(source['a'] == 'yes'), "BORN_EARLY"] ='y'

	# ### BORN_3437
	source['a'] = source.filter(regex='Id3D210')
	source.loc[(source['a'] == 9), "BORN_3437"] ='y'

	# ### BORN_38
	source['a'] = source.filter(regex='Id3D210')
	source.loc[(source['a'] >9), "BORN_38"] ='y'

	# ### AB_SIZE
	source['a'] = source.filter(regex='Id3D180')
	source.loc[(source['a'] == 'no'), "AB_SIZE"] ='y'

	# ### BORN_SMALL
	source['a'] = source.filter(regex='Id3D190')
	source.loc[(source['a'] == 'yes'), "BORN_SMALL"] ='y'

	# ### BORN_BIG
	source['a'] = source.filter(regex='Id3D200')
	source.loc[(source['a'] == 'yes'), "BORN_BIG"] ='y'

	# ### TWIN
	source['a'] = source.filter(regex='Id3D100')
	source.loc[(source['a'] == 'yes'), "TWIN"] ='y'

	# ### COMDEL
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "COMDEL"] ='y'

	# ### CORD
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "CORD"] ='y'

	# ### WATERS
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "WATERS"] ='y'

	# ### MOVE_LB
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MOVE_LB"] ='y'

	# ### CYANOSIS
	source['a'] = source.filter(regex='Id3D280')
	source.loc[(source['a'] == 'yes'), "CYANOSIS"] ='y'

	# ### BABY_BR
	source['a'] = source.filter(regex='Id3D300')
	source.loc[(source['a'] == 'yes'), "BABY_BR"] ='y'

	# ### BORN_NOBR
	source['a'] = source.filter(regex='Id3D310')
	source.loc[(source['a'] == 'yes'), "BORN_NOBR"] ='y'

	# ### CRIED
	source['a'] = source.filter(regex='Id3D290')
	source.loc[(source['a'] == 'yes'), "CRIED"] ='y'

	# ### NO_LIFE
	source['a'] = source.filter(regex='Id3D320')
	source.loc[(source['a'] == 'yes'), "NO_LIFE"] ='y'

	# ### MUSHY
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MUSHY"] ='y'

	# ### FED_D1
	source['a'] = source.filter(regex='Id3D340')
	source.loc[(source['a'] == 'yes'), "FED_D1"] ='y'

	# ### ST_SUCK
	source['a'] = ""
	source['b'] = np.nan
	source.loc[(source['a'] == 'yes') & (source['b'] >= 3), "ST_SUCK"] ='y'

	# ### AB_POSIT
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "AB_POSIT"] ='y'

	# ### CONV_D1
	source['a'] = source.filter(regex='Id3D360')
	source.loc[(source['a'] == 'yes'), "CONV_D1"] ='y'

	# ### CONV_D2
	source['a'] = source.filter(regex='Id3D370')
	source.loc[(source['a'] == 'yes'), "CONV_D2"] ='y'

	# ### ARCH_B
	source['a'] = source.filter(regex='Id3D380')
	source.loc[(source['a'] == 'yes'), "ARCH_B"] ='y'

	# ### FONT_HI
	source['a'] = source.filter(regex='Id3D390')
	source.loc[(source['a'] == 'yes'), "FONT_HI"] ='y'

	# ### FONT_LO
	source['a'] = source.filter(regex='Id3D400')
	source.loc[(source['a'] == 'yes'), "FONT_LO"] ='y'

	# ### UNW_D1
	source['a'] = source.filter(regex='Id3D410')
	source.loc[(source['a'] == 'yes'), "UNW_D1"] ='y'

	# ### UNW_D2
	source['a'] = source.filter(regex='Id3D420')
	source.loc[(source['a'] == 'yes'), "UNW_D2"] ='y'

	# ### COLD
	source['a'] = source.filter(regex='Id3D430')
	source.loc[(source['a'] == 'yes'), "COLD"] ='y'

	# ### UMBINF
	source['a'] = source.filter(regex='Id3D440')
	source.loc[(source['a'] == 'yes'), "UMBINF"] ='y'

	# ### B_YELLOW
	source['a'] = source.filter(regex='Id3D450')
	source.loc[(source['a'] == 'yes'), "B_YELLOW"] ='y'

	# ### DEVEL
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "DEVEL"] ='y'

	# ### BORN_MALF
	source['a'] = source.filter(regex='Id3D230')
	source.loc[(source['a'] == 'yes'), "BORN_MALF"] ='y'

	# ### MLF_BK
	source['a'] = source.filter(regex='Id3D240')
	source.loc[(source['a'] == 'yes'), "MLF_BK"] ='y'

	# ### MLF_LH
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MLF_LH"] ='y'

	# ### MLF_SH
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MLF_SH"] ='y'

	# ### MTTV
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "MTTV"] ='y'

	# ### B_NORM
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_NORM"] ='y'

	# ### B_ASSIST
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_ASSIST"] ='y'

	# ### B_CAES
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_CAES"] ='y'

	# ### B_FIRST
	source['a'] = ""
	source.loc[(source['a'] == 0 ), "B_FIRST"] ='y'

	# ### B_MORE4
	source['a'] = ""
	source.loc[(source['a'] >= 4), "B_MORE4"] ='y'

	# ### B_MBPR
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_MBPR"] ='y'

	# ### B_MSMDS
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_MSMDS"] ='y'

	# ### B_MCON
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_MCON"] ='y'

	# ### B_MBVI
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_MBVI"] ='y'

	# ### B_MVBL
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "B_MVBL"] ='y'

	# ### B_BFAC
	source['a'] = ""
	source['b'] = ""

	source.loc[(source['a'] == 'hospital') | (source['a'] == 'other_health_facility'), "B_BFAC"] ='y'

	# ### B_BHOME
	source.loc[(source['a'] == 'home'), "B_BHOME"] ='y'

	# ### B_BWAY
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility') | (source['a'] == 'other'), "B_BWAY"] ='y'

	# ### B_BPROF
	source.loc[(source['b'] == 'yes'), "B_BPROF"] ='y'

	# ### INJURY
	source['a'] = source.filter(regex='Id3E100')
	source.loc[(source['a'] == 'yes'), "INJURY"] ='y'

	# ### TRAFFIC
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "TRAFFIC"] ='y'

	# ### O_TRANS
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "O_TRANS"] ='y'

	# ### FALL
	source['a'] = source.filter(regex='Id3E100')
	source['b'] = source.filter(regex='Id3E310')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "FALL"] ='y'

	# ### DROWN
	source['a'] = source.filter(regex='Id3E100')
	source['b'] = source.filter(regex='Id3E320')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "DROWN"] ='y'

	# ### FIRE
	source['a'] = source.filter(regex='Id3E100')
	source['b'] = ""
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "FIRE"] ='y'

	# ### ASSAULT
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "ASSAULT"] ='y'

	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "ASSAULT"] ='y'

	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "ASSAULT"] ='y'

	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "ASSAULT"] ='y'

	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "ASSAULT"] ='y'

	# ### VENOM
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "VENOM"] ='y'

	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "VENOM"] ='y'

	# ### FORCE
	source['a'] = source.filter(regex='Id3E100')
	source['b'] = source.filter(regex='Id3E500')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "FORCE"] ='y'

	# ### POISON
	source['a'] = source.filter(regex='Id3E100')
	source['b'] = source.filter(regex='Id3E510')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "POISON"] ='y'

	# ### INFLICT
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "INFLICT"] ='y'

	# ### SUICIDE
	source['a'] = source.filter(regex='Id3E100')
	source['b'] = ""
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "SUICIDE"] ='y'

	# ### ALCOHOL
	source['a'] = source.filter(regex='Id3F100')
	source.loc[(source['a'] == 'yes'), "ALCOHOL"] ='y'

	# ### SMOKING
	source['a'] = source.filter(regex='Id3F110')
	source.loc[(source['a'] == 'yes'), "SMOKING"] ='y'

	# ### MARRIED
	source['a'] = source.filter(regex='Id1A600')
	source.loc[(source['a'] == 'married'), "MARRIED"] ='y'

	# ### VACCIN
	source['a'] = ""
	source.loc[(source['a'] == 'yes'), "VACCIN"] ='y'

	# ### TREAT
	source['a'] = source.filter(regex='Id3G110')
	source.loc[(source['a'] == 'yes'), "TREAT"] ='y'

	# ### T_ORT
	source['a'] = source.filter(regex='Id3G110')
	source['b'] = source.filter(regex='Id3G120')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "T_ORT"] ='y'

	# ### T_IV
	source['a'] = source.filter(regex='Id3G110')
	source['b'] = source.filter(regex='Id3G130')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "T_IV"] ='y'

	# ### BLOOD_TR
	source['a'] = source.filter(regex='Id3G140')
	source.loc[(source['a'] == 'yes'), "BLOOD_TR"] ='y'

	# ### T_NGT
	source['a'] = source.filter(regex='Id3G110')
	source['b'] = source.filter(regex='Id3G150')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "T_NGT"] ='y'

	# ### ANTIB_I
	source['a'] = source.filter(regex='Id3G160')
	source.loc[(source['a'] == 'yes'), "ANTIB_I"] ='y'

	# ### SURGERY
	source['a'] = source.filter(regex='Id3G110')
	source['b'] = source.filter(regex='Id3G170')
	source.loc[(source['a'] == 'yes') & (source['b'] == 'yes'), "SURGERY"] ='y'

	# ### SUR_1M
	source['a'] = source.filter(regex='Id3G180')
	source.loc[(source['a'] == 'yes'), "SUR_1M"] ='y'

	# ### DISCH
	source['a'] = source.filter(regex='Id3G190')
	source.loc[(source['a'] == 'yes'), "DISCH"] ='y'

	# ### SHOSPF
	source['a'] = source.filter(regex='Id4A100')
	source.loc[(source['a'] == 'yes'), "SHOSPF"] ='y'

	# ### STRANS
	source['a'] = source.filter(regex='Id4A110')
	source.loc[(source['a'] == 'yes'), "STRANS"] ='y'

	# ### SADMIT
	source['a'] = source.filter(regex='Id4A120')
	source.loc[(source['a'] == 'yes'), "SADMIT"] ='y'

	# ### STREAT
	source['a'] = source.filter(regex='Id4A130')
	source.loc[(source['a'] == 'yes'), "STREAT"] ='y'

	# ### SMEDIC
	source['a'] = source.filter(regex='Id4A140')
	source.loc[(source['a'] == 'yes'), "SMEDIC"] ='y'

	# ### SMORE2
	source['a'] = source.filter(regex='Id4A150')
	source.loc[(source['a'] == 'yes'), "SMORE2"] ='y'

	# ### SDOUBT
	source['a'] = source.filter(regex='Id4A160')
	source.loc[(source['a'] == 'yes'), "SDOUBT"] ='y'

	# ### STRADM
	source['a'] = source.filter(regex='Id4A170')
	source.loc[(source['a'] == 'yes'), "STRADM"] ='y'

	# ### SMOBPH
	source['a'] = source.filter(regex='Id4A180')
	source.loc[(source['a'] == 'yes'), "SMOBPH"] ='y'

	# ### SCOSTS
	source['a'] = source.filter(regex='Id4A190')
	source.loc[(source['a'] == 'yes'), "SCOSTS"] ='y'

	# # Out to CSV
	out = source[['ELDER', 'MIDAGE', 'ADULT', 'CHILD', 'UNDER5', 'INFANT', 'NEONATE', 'MALE', 'FEMALE', 'MAGEP1', 
	              'MAGEP2', 'MAGEP3', 'DIED_D1', 'DIED_D23', 'DIED_D36','DIED_W1', 'ACUTE', 'CHRONIC','SUDDEN', 
	              'WET_SEAS', 'DRY_SEAS', 'HEART_DIS', 'TUBER', 'HIV_AIDS', 'HYPERT', 'DIABETES', 'ASTHMA',
	              'EPILEPSY', 'CANCER', 'COPD', 'DEMENT', 'DEPRESS','STROKE','SICKLE', 'KIDNEY_DIS', 'LIVER_DIS',
	              'MEASLES', 'MEN_CON', 'MENCON3', 'MALARIA', 'MALARNEG', 'FEVER', 'AC_FEVER','CH_FEVER', 
	              'NIGHT_SW', 'COUGH', 'AC_COUGH', 'CH_COUGH', 'PR_COUGH', 'BL_COUGH', 'WHOOP', 'BREATH',
	              'RAPID_BR', 'AC_RPBR', 'CH_RPBR', 'BR_LESS', 'AC_BRL', 'CH_BRL', 'EXERT_BR', 'LYING_BR', 
	              'CHEST_IN', 'WHEEZE', 'CH_PAIN', 'YELLOW', 'DIARR', 'AC_DIARR', 'PE_DIARR', 'CH_DIARR', 'BL_DIARR',
	              'VOMITING', 'BL_VOMIT', 'ABDOM', 'ABD_PAIN', 'AC_ABDP', 'CH_ABDP', 'SWE_ABD', 'AC_SWAB', 'CH_SWAB',
	              'ABD_MASS', 'AC_ABDM', 'CH_ABDM', 'HEADACHE', 'SKIN', 'SKIN_LES', 'SK_FEET', 'RASH', 'AC_RASH', 
	              'CH_RASH', 'MEASRASH', 'HERPES', 'STIFF_NECK', 'AC_STNK', 'CH_STNK', 'COMA', 'CO_ONS', 'CONVUL', 
	              'AC_CONV', 'CH_CONV', 'UNC_CON', 'URINE' , 'URI_RET', 'EXC_URINE', 'URI_HAEM', 'WT_LOSS' , 'WASTING',
	              'OR_CAND', 'RIGIDITY', 'SWELL', 'SWE_ORAL', 'SWE_NECK', 'SWE_ARMP' ,'SWE_BREAST','SWE_GEN', 
	              'SWE_OTH', 'SWE_LEGS', 'ANAEMIA', 'EXC_DRINK', 'HAIR', 'PARAL_ONE', 'EYE_SUNK', 'BL_ORIF', 
	              'VB_BET', 'VB_MEN', 'VB_AFTER', 'DIFF_SW', 'NOT_PREG', 'PREGNANT', 'DEL_6WKS', 'PEND_6W', 
	              'FIRST_P', 'MORE4', 'CS_PREV', 'MULTIP', 'LAB_24', 'DIED_LAB', 'DEATH_24', 'BABY_AL', 
	              'BREAST_FD', 'DEL_FAC', 'DEL_HOME', 'DEL_ELSE', 'PROF_ASS', 'DEL_NORM', 'DEL_ASS', 'DEL_CS',
	              'BABY_POS', 'MON_EARLY', 'HYSTER', 'BPR_PREG', 'FIT_PREG', 'VIS_BL', 'BLEED', 'E_BLEED', 'S_BLEED',
	              'D_BLEED', 'P_BLEED', 'PLACENT_R', 'DISCH_SM', 'TERM_ATT', 'ABORT', 'BORN_EARLY', 'BORN_3437',
	              'BORN_38', 'AB_SIZE', 'BORN_SMALL', 'BORN_BIG', 'TWIN', 'COMDEL', 'CORD', 'WATERS', 'MOVE_LB', 
	              'CYANOSIS', 'BABY_BR', 'BORN_NOBR', 'CRIED', 'NO_LIFE', 'MUSHY', 'FED_D1', 'ST_SUCK', 'AB_POSIT', 
	              'CONV_D1', 'CONV_D2', 'ARCH_B', 'FONT_HI', 'FONT_LO', 'UNW_D1', 'UNW_D2', 'COLD', 'UMBINF', 
	              'B_YELLOW', 'DEVEL', 'BORN_MALF', 'MLF_BK', 'MLF_LH', 'MLF_SH', 'MTTV', 'B_NORM', 'B_ASSIST', 
	              'B_CAES', 'B_FIRST', 'B_MORE4', 'B_MBPR', 'B_MSMDS', 'B_MCON', 'B_MBVI', 'B_MVBL', 'B_BFAC', 
	              'B_BHOME', 'B_BWAY', 'B_BPROF', 'INJURY', 'TRAFFIC', 'O_TRANS', 'FALL', 'DROWN', 'FIRE', 
	              'ASSAULT', 'VENOM', 'FORCE', 'POISON', 'INFLICT', 'SUICIDE', 'ALCOHOL', 'SMOKING', 'MARRIED', 
	              'VACCIN', 'TREAT', 'T_ORT', 'T_IV', 'BLOOD_TR', 'T_NGT', 'SUR_1M', 'DISCH', 'SHOSPF', 'STRANS', 
	              'SADMIT', 'STREAT', 'SMEDIC', 'SMORE2', 'SDOUBT', 'STRADM', 'SMOBPH', 'SCOSTS']]


	out.index = range(1, len(out)+1)
	out.to_csv(final, index_label='ID')



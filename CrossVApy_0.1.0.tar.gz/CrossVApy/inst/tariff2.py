# coding: utf-8

import pandas as pd
import numpy as np
def source(file, final):

	source = pd.read_csv(file)
	source = source.astype(object)

	## interviewstarttime
	time = source['SubmissionDate'].dt.time
	source['interviewstarttime'] = time

	## interviewdate
	d = source['SubmissionDate'].dt
	source['interviewdate'] = d.strftime("%d.%m.%Y")

	## sid
	source['a'] = pd.Series(np.arange(len(source)+1)[1:])
	source['b'] = "StudyIDNo"
	source['sid'] = source['b'].astype(str) + source['a'].astype(str)

	## gen_2_4
	source['gen_2_4'] = source.filter(regex='Id10055')

	## gen_3_1
	source['a'] = source.filter(regex='Id10013')
	source.loc[(source['a'] == 'yes'), "gen_3_1"] = '1'
	source.loc[(source['a'] == 'no'), "gen_3_1"] = '0'
	source.loc[(source['a'] == 'dk'), "gen_3_1"] = '9'
	source.loc[(source['a'] == 'ref'), "gen_3_1"] = '8'

	## gen_5_0
	source['gen_5_0'] = source.filter(regex='10018')

	## gen_5_1a
	source['a'] = source.filter(regex='Id10021')
	source['gen_5_1a'] = pd.to_datetime(source['a']).dt.year

	## gen_5_1b
	source['gen_5_1b'] = pd.to_datetime(source['a']).dt.month

	## gen_5_1c
	source['gen_5_1c'] = pd.to_datetime(source['a']).dt.day

	## gen_5_2
	source['a'] = source.filter(regex='Id10019')
	source.loc[source['a'] == 'male', "gen_5_2"] = '1'
	source.loc[source['a'] == 'female', "gen_5_2"] = '2'

	## gen_5_3a
	source['a'] = source.filter(regex='Id10023')
	source['gen_5_3a'] = pd.to_datetime(source['a']).dt.year

	## gen_5_3b
	source['gen_5_3b'] = pd.to_datetime(source['a']).dt.month

	## gen_5_3c
	source['gen_5_3c'] = pd.to_datetime(source['a']).dt.day

	## gen_5_4
	source['a'] = source.filter(regex='ageInDays')
	source['gen_5_4'] = '9'
	source.loc[(source['a'] >= -1) & (source['a'] < 31), "gen_5_4" ] = '4'
	source.loc[(source['a'] >= 31) & (source['a'] < 365), "gen_5_4" ] = '2'
	source.loc[(source['a'] >= 365) & (source['a'] < 999999), "gen_5_4" ] = '1'

	## gen_5_4a
	source['a'] = source.filter(regex='ageInYears')
	source.loc[source['gen_5_4'] == '1', 'gen_5_4a'] = source['a']

	## gen_5_4b
	source['a'] = source.filter(regex='ageInMonths')
	source.loc[source['gen_5_4'] == '2', 'gen_5_4b'] = source['a']

	## gen_5_4c
	source['a'] = source.filter(regex='ageInDays')
	source.loc[source['gen_5_4'] == '4', 'gen_5_4c'] = source['a']

	## gen_5_4d
	source['a'] = source.filter(regex='ageInDays')
	source['gen_5_4d'] = '9'
	source.loc[(source['a'] >= -1) & (source['a'] < 28), "gen_5_4d" ] = '1'
	source.loc[(source['a'] >= 28) & (source['a'] < 365*11), "gen_5_4d" ] = '2'
	source.loc[(source['a'] >= 365*12), "gen_5_4d" ] = '3'

	## gen_5_5
	source['a'] = source.filter(regex='Id10058')
	source.loc[(source['a'] == 'hospital'), "gen_5_5" ] = '1'
	source.loc[(source['a'] == 'other_health_facility'), "gen_5_5" ] = '2'
	source.loc[(source['a'] == 'home'), "gen_5_5" ] = '4'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), "gen_5_5" ] = '3'
	source.loc[(source['a'] == 'other'), "gen_5_5" ] = '5'
	source.loc[(source['a'] == 'DK'), "gen_5_5" ] = '9'
	source.loc[(source['a'] == 'Ref'), "gen_5_5" ] = '8'

	## gen_5_2b
	source['gen_5_2b'] = source.filter(regex='Id10058')

	## gen_6_1
	source['a'] = source.filter(regex='Id10462')
	source.loc[(source['a'] == 'yes'), "gen_6_1" ] = '1'
	source.loc[(source['a'] == 'no'), "gen_6_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "gen_6_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "gen_6_1" ] = '8'

	## gen_6_2b
	source['a'] = source.filter(regex='Id10071')
	source['gen_6_2b'] = pd.to_datetime(source['a']).dt.year

	## gen_6_2c
	source['gen_6_2c'] = pd.to_datetime(source['a']).dt.month


	## gen_6_2d
	source['gen_6_2d'] = pd.to_datetime(source['a']).dt.day


	## gen_6_3
	source['gen_6_3'] = source.filter(regex='Id10070')


	## gen_6_4
	source['gen_6_4'] = np.nan

	## gen_6_5
	source['gen_6_5'] = np.nan

	## gen_6_6
	source['gen_6_6'] = np.nan

	## gen_6_7
	source['gen_6_7'] = source.filter(regex='Id10073')

	## gen_6_8
	source['gen_6_8'] = np.nan

	## gen_6_9
	source['gen_6_9'] = np.nan

	## gen_6_10
	source['gen_6_10'] = np.nan

	## adult_5_1
	source['a'] = source.filter(regex='Id10077')
	source.loc[(source['a'] == 'yes'), "adult_5_1" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_5_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_5_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_5_1" ] = '8'

	## adult_5_2
	source['a'] = source.filter(regex='Id10079').astype(str)
	source.loc[source['a'] == 'yes', "1"] = '1'
	source['a'] = source.filter(regex='Id10083').astype(str)
	source.loc[source['a'] == 'yes', "2"] = '2'
	source['a'] = source.filter(regex='Id10085').astype(str)
	source.loc[source['a'] == 'yes', "3"] = '3'
	source['a'] = source.filter(regex='Id10084').astype(str)
	source.loc[source['a'] == 'yes', "4"] = '4'
	source['a'] = source.filter(regex='Id10086').astype(str)
	source.loc[source['a'] == 'yes', "5"] = '5'
	source['a'] = source.filter(regex='Id10089').astype(str)
	source.loc[source['a'] == 'yes', "6"] = '6'
	source['a'] = source.filter(regex='Id10091').astype(str)
	source.loc[source['a'] == 'yes', "7"] = '7'
	source['a'] = source.filter(regex='Id10082').astype(str)
	source.loc[source['a'] == 'yes', "11"] = '11'
	source['a'] = source.filter(regex='Id10087').astype(str)
	source.loc[source['a'] == 'yes', "12"] = '11'
	source['a'] = source.filter(regex='Id10095').astype(str)
	source.loc[source['a'] == 'yes', "13"] = '11'
	source['a'] = source.filter(regex='Id10096').astype(str)
	source.loc[source['a'] == 'yes', "14"] = '11'
	source['a'] = source.filter(regex='Id10097').astype(str)
	source.loc[source['a'] == 'yes', "15"] = '11'
	source['a'] = source.filter(regex='Id10091').astype(str)
	source.loc[source['a'] == 'yes', "16"] = '11'
	source['a'] = source.filter(regex='Id10092').astype(str)
	source.loc[source['a'] == 'yes', "17"] = '11'
	source['a'] = source.filter(regex='Id10093').astype(str)
	source.loc[source['a'] == 'yes', "18"] = '11'
	source['a'] = source.filter(regex='Id10094').astype(str)
	source.loc[source['a'] == 'yes', "19"] = '11'
	s = source[['1', '2', '3', '4', '5', '6', '7', '11', '12', '13', '14', '15', '16', '17', '18', '19']]
	source['adult_5_2'] = s.apply(lambda x: x.str.cat(sep=' '), axis=1)

	## adult_5_2a
	source['adult_5_2a'] = np.nan

	## adult_5_3
	source['a'] = source.filter(regex='Id10099').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_5_3" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_5_3" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_5_3" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_5_3" ] = '8'

	## adult_5_4
	source['a'] = source.filter(regex='Id10100').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_5_4" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_5_4" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_5_4" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_5_4" ] = '8'

	## adult_1_1
	source['adult_1_1'] = np.nan

	## adult_1_1a
	source['a'] = source.filter(regex='Id10135').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1a" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1a" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1a" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1a" ] = '8'

	## adult_1_1c
	source['a'] = source.filter(regex='Id10137').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1c" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1c" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1c" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1c" ] = '8'

	## adult_1_1m
	source['a'] = source.filter(regex='Id10138').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1m" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1m" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1m" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1m" ] = '8'

	## adult_1_1g
	source['a'] = source.filter(regex='Id10134').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1g" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1g" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1g" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1g" ] = '8'

	## adult_1_1h
	source['a'] = source.filter(regex='Id10136').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1h" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1h" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1h" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1h" ] = '8'

	## adult_1_1i
	source['a'] = source.filter(regex='Id10133').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1i" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1i" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1i" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1i" ] = '8'

	## adult_1_1d
	source['a'] = source.filter(regex='Id10125').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1d" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1d" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1d" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1d" ] = '8'

	## adult_1_1l
	source['a'] = source.filter(regex='Id10141').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1l" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1l" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1l" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1l" ] = '8'

	## adult_1_1n
	source['a'] = source.filter(regex='Id10127').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_1_1n" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_1_1n" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_1_1n" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_1_1n" ] = '8'

	## adult_2_2
	source['a'] = source.filter(regex='Id10147').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_2" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_2" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_2" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_2" ] = '8'

	## adult_2_4
	source['a'] = source.filter(regex='Id10150').astype(str)
	source.loc[(source['a'] == 'mild'), "adult_2_4" ] = '1'
	source.loc[(source['a'] == 'moderate'), "adult_2_4" ] = '2'
	source.loc[(source['a'] == 'severe'), "adult_2_4" ] = '3'

	## adult_2_5
	source['a'] = source.filter(regex='Id10151').astype(str)
	source.loc[(source['a'] == 'continuous'), "adult_2_5" ] = '1'
	source.loc[(source['a'] == 'on_and_off'), "adult_2_5" ] = '2'
	source.loc[(source['a'] == 'nightly'), "adult_2_5" ] = '3'
	source.loc[(source['a'] == 'DK'), "adult_2_5" ] = '9'
	source.loc[(source['a'] == 'Ref'), "adult_2_5" ] = '8'

	## adult_2_7
	source['a'] = source.filter(regex='Id10233').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_7" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_7" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_7" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_7" ] = '8'

	## adult_2_9
	source['a'] = source.filter(regex='Id10235').astype(str)
	source.loc[(source['a'] == 'face'), "adult_2_9" ] = '1'
	source.loc[(source['a'] == 'trunk'), "adult_2_9" ] = '2'
	source.loc[(source['a'] == 'extremities'), "adult_2_9" ] = '3'
	source.loc[(source['a'] == 'everywhere'), "adult_2_9" ] = '4'

	## adult_2_10
	source['a'] = source.filter(regex='Id10228').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_10" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_10" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_10" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_10" ] = '8'

	## adult_2_11
	source['a'] = source.filter(regex='Id10229').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_11" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_11" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_11" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_11" ] = '8'

	## adult_2_13
	source['a'] = source.filter(regex='Id10230').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_13" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_13" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_13" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_13" ] = '8'

	## adult_2_14
	source['a'] = source.filter(regex='Id10231').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_14" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_14" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_14" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_14" ] = '8'

	## adult_2_15
	source['adult_2_15'] = ''
	source.loc[source['adult_2_14'].astype(str) == '1', 'adult_2_15'] ='4'

	## adult_2_15a
	source['adult_2_15a'] = source.filter(regex='Id10232')

	## adult_2_21
	source['a'] = source.filter(regex='Id10265').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_21" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_21" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_21" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_21" ] = '8'

	## adult_2_22
	source.loc[source['adult_2_21'].astype(str) == '1', 'adult_2_22'] ='4'

	## adult_2_22a
	source['adult_2_22a'] = source.filter(regex='Id10266').astype(int)

	## adult_2_22b
	source['adult_2_22b'] = (source['adult_2_22a'])/30

	## adult_2_25
	source['a'] = source.filter(regex='Id10247').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_25" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_25" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_25" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_25" ] = '8'

	## adult_2_26
	source['adult_2_26'] = ''
	source.loc[source['adult_2_25'].astype(str) == '1', 'adult_2_26'] ='4'

	## adult_2_26a
	source['adult_2_26a'] = source.filter(regex='Id10248')

	## adult_2_26b
	source['adult_2_26b'] = (source['adult_2_26a'])/30

	## adult_2_27
	source['a'] = source.filter(regex='Id10252').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_27" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_27" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_27" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_27" ] = '8'

	## adult_2_29
	source['a'] = source.filter(regex='Id10255').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_29" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_29" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_29" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_29" ] = '8'

	## adult_2_30
	source['a'] = source.filter(regex='Id10256').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_30" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_30" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_30" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_30" ] = '8'

	## adult_2_31
	source['a'] = source.filter(regex='Id10257').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_31" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_31" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_31" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_31" ] = '8'

	## adult_2_32
	source['a'] = source.filter(regex='Id10153').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_32" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_32" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_32" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_32" ] = '8'

	## adult_2_34
	source['a'] = source.filter(regex='Id10155').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_34" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_34" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_34" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_34" ] = '8'

	## adult_2_35
	source['a'] = source.filter(regex='Id10157').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_35" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_35" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_35" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_35" ] = '8'

	## adult_2_36
	source['a'] = source.filter(regex='Id10159').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_36" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_36" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_36" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_36" ] = '8'

	## adult_2_43
	source['a'] = source.filter(regex='Id10174').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_43" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_43" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_43" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_43" ] = '8'

	## adult_2_44
	source['a'] = source.filter(regex='Id10176')
	source['b'] = source.filter(regex='Id10178')
	source['c'] = source.filter(regex='Id10179')
	source.loc[(source['b']*60)+(source['c']) >24*60 | (source['a'] >= 2), "adult_2_44" ] = '3'
	source.loc[((source['b']*60)+(source['c']) >=30) & ((source['b']*60)+(source['c'])<=24*60), "adult_2_44" ] = '2'
	source.loc[((source['b']*60)+(source['c']) > 0) & ((source['b']*60)+(source['c']) < 30), "adult_2_44" ] = '1'

	## adult_2_47
	source['a'] = source.filter(regex='Id10181').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_47" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_47" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_47" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_47" ] = '8'

	## adult_2_50
	source['a'] = source.filter(regex='Id10186').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_50" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_50" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_50" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_50" ] = '8'

	## adult_2_51
	source['a'] = source.filter(regex='Id10187').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_51" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_51" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_51" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_51" ] = '8'

	## adult_2_52
	source['a'] = source.filter(regex='Id10224').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_52" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_52" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_52" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_52" ] = '8'

	## adult_2_53
	source['a'] = source.filter(regex='Id10189').astype(str)
	source['b'] = source.filter(regex='Id10191').astype(str)
	source['c'] = source.filter(regex='Id10192').astype(str)

	source.loc[(source['a'] == 'yes'), "adult_2_53" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_53" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_53" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_53" ] = '8'

	## adult_2_55
	source.loc[(source['a'] =='yes') & (source['b'] == 'yes'), "adult_2_55" ] = '1'
	source.loc[(source['a'] =='yes') & (source['b'] == 'no'), "adult_2_55" ] = '0'
	source.loc[(source['a'] =='yes') & (source['b'] == 'dk'), "adult_2_55" ] = '9'
	source.loc[(source['a'] =='yes') & (source['b'] == 'ref'), "adult_2_55" ] = '8'

	## adult_2_56
	source.loc[(source['a'] =='yes') & (source['c'] == 'yes'), "adult_2_56" ] = '1'
	source.loc[(source['a'] =='yes') & (source['c'] == 'no'), "adult_2_56" ] = '0'
	source.loc[(source['a'] =='yes') & (source['c'] == 'dk'), "adult_2_56" ] = '9'
	source.loc[(source['a'] =='yes') & (source['c'] == 'ref'), "adult_2_56" ] = '8'

	## adult_2_57
	source['a'] = source.filter(regex='Id10261').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_57" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_57" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_57" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_57" ] = '8'


	## adult_2_58
	source.loc[(source['adult_2_57'] == 1), 'adult_2_58'] = '4'


	## adult_2_58a
	source['adult_2_26a'] = source.filter(regex='Id10262')


	## adult_2_58b
	source['adult_2_58b'] = (source['adult_2_26a'])/30

	## adult_2_59
	source['a'] = source.filter(regex='Id10263').astype(str)
	source.loc[(source['a'] == 'solids'), "adult_2_59" ] = '1'
	source.loc[(source['a'] == 'liquids'), "adult_2_59" ] = '2'
	source.loc[(source['a'] == 'both'), "adult_2_59" ] = '3'

	## adult_2_60
	source['a'] = source.filter(regex='Id10264').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_60" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_60" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_60" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_60" ] = '8'

	## adult_2_61
	source['a'] = source.filter(regex='Id10194').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_61" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_61" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_61" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_61" ] = '8'

	## adult_2_62
	source.loc[(source['adult_2_61'] == 1), 'adult_2_62'] = '5'


	## adult_2_62a
	source['a'] = source.filter(regex='Id10198')
	source['b'] = source.filter(regex='Id10197b')
	source['c'] = source.filter(regex='Id10197')
	source['d'] = source.filter(regex='Id10196')
	source['adult_2_62a'] = (source['a']*30.4*24) + (source['b']*7*24) + (source['c']*24) + (source['d'])

	## adult_2_62b
	source['adult_2_62b'] = source['c']

	## adult_2_62c
	source['adult_2_62c'] = source['a']

	## adult_2_63
	source['a'] = source.filter(regex='Id10199').astype(str)
	source.loc[(source['a'] == 'upper_abdomen'), "adult_2_63" ] = '1'
	source.loc[(source['a'] == 'lower_abdomen'), "adult_2_63" ] = '2'

	## adult_2_64
	source['a'] = source.filter(regex='Id10200').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_64" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_64" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_64" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_64" ] = '8'

	## adult_2_65
	source.loc[(source['adult_2_64'] == 1), 'adult_2_65'] = '4'

	## adult_2_65a
	source['a'] = source.filter(regex='Id10201')
	source['b'] = source.filter(regex='Id10202')
	source['adult_2_65a'] = (source['a']) + (source['b']*30.4)


	## adult_2_65b
	source['adult_2_65b'] = source['b']

	## adult_2_66
	source['a'] = source.filter(regex='Id10203').astype(str)
	source.loc[(source['a'] == 'rapidly'), "adult_2_66" ] = '1'
	source.loc[(source['a'] == 'slowly'), "adult_2_66" ] = '2'

	## adult_2_67
	source['a'] = source.filter(regex='Id10204').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_67" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_67" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_67" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_67" ] = '8'

	## adult_2_68
	source.loc[(source['adult_2_67'] == 1), 'adult_2_68'] = '4'

	## adult_2_68a
	source['a'] = source.filter(regex='Id10205')
	source['b'] = source.filter(regex='Id10206')
	source['adult_2_68a'] = (source['a']) + (source['b']*30.4)

	## adult_2_68b
	source['adult_2_68b'] = source['b']

	## adult_2_72
	source['a'] = source.filter(regex='Id10208').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_72" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_72" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_72" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_72" ] = '8'

	## adult_2_73
	source.loc[(source['adult_2_72'] == 1), 'adult_2_73'] = '4'

	## adult_2_73a
	source['adult_2_73a'] = source.filter(regex='Id10209')

	## adult_2_73b
	source['adult_2_73b'] = (source['adult_2_73a'])/30

	## adult_2_74
	source['a'] = source.filter(regex='Id10214').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_74" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_74" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_74" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_74" ] = '8'

	## adult_2_75
	source['a'] = source.filter(regex='Id10217').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_75" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_75" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_75" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_75" ] = '8'

	## adult_2_77
	source['a'] = source.filter(regex='Id10218').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_77" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_77" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_77" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_77" ] = '8'

	## adult_2_82
	source['a'] = source.filter(regex='Id10219').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_82" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_82" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_82" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_82" ] = '8'

	## adult_2_83
	source.loc[(source['adult_2_82'] == 1), 'adult_2_83'] = '6'

	## adult_2_83a
	source['a'] = source.filter(regex='Id10220')
	source['b'] = source.filter(regex='Id10221').astype(int)
	source.loc[source['a'] == 'yes', 'adult_2_83a'] = source['b']

	## adult_2_83b
	source['adult_2_83b'] = (source['b'])/60

	## adult_2_84
	source['a'] = source.filter(regex='Id10222').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_84" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_84" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_84" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_84" ] = '8'

	## adult_2_85
	source['a'] = source.filter(regex='Id10258').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_2_85" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_2_85" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_2_85" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_2_85" ] = '8'

	## adult_2_87
	source['a'] = source.filter(regex='Id10260').astype(str)
	source.loc[(source['a'] == 'right_side'), "adult_2_87" ] = '1'
	source.loc[(source['a'] == 'left_side'), "adult_2_87" ] = '2'
	source.loc[(source['a'] == 'lower_part_of_body'), "adult_2_87" ] = '3'
	source.loc[(source['a'] == 'upper_part_of_body'), "adult_2_87" ] = '4'
	source.loc[(source['a'] == 'one_leg_only'), "adult_2_87" ] = '5'
	source.loc[(source['a'] == 'one_arm_only'), "adult_2_87" ] = '6'
	source.loc[(source['a'] == 'whole_body'), "adult_2_87" ] = '7'
	source.loc[(source['a'] == 'other'), "adult_2_87" ] = '11'

	## adult_2_87a
	source['adult_2_87a'] = np.nan

	## adult_3_1
	source['a'] = source.filter(regex='Id10294').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_1" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_1" ] = '8'

	## adult_3_2
	source['a'] = source.filter(regex='Id10295').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_2" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_2" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_2" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_2" ] = '8'

	## adult_3_3a
	source['a'] = source.filter(regex='Id10296').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_3a" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_3a" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_3a" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_3a" ] = '8'

	## adult_3_3
	source['a'] = source.filter(regex='Id10299').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_3" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_3" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_3" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_3" ] = '8'

	## adult_3_4
	source['a'] = source.filter(regex='Id10300').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_4" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_4" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_4" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_4" ] = '8'

	## adult_3_5
	source['a'] = source.filter(regex='Id10297').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_5" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_5" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_5" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_5" ] = '8'

	## adult_3_6
	source['a'] = source.filter(regex='Id10301').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_6" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_6" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_6" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_6" ] = '8'

	## adult_3_7
	source['a'] = source.filter(regex='Id10302').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_7" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_7" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_7" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_7" ] = '8'

	## adult_3_8
	source.loc[(source['adult_3_7'] == 1), 'adult_3_8'] = '3'

	## adult_3_8a
	source['adult_3_8a'] = source.filter(regex='Id10303')


	## adult_3_9
	source['a'] = source.filter(regex='Id10304').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_9" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_9" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_9" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_9" ] = '8'

	## adult_3_10
	source['a'] = source.filter(regex='Id10305').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_10" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_10" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_10" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_10" ] = '8'

	## adult_3_11
	source.loc[(source['adult_3_10'] == 1), 'adult_3_11'] = '2'

	## adult_3_11a
	source['adult_3_11a'] = source.filter(regex='Id10309')

	## adult_3_12
	source['a'] = source.filter(regex='Id10335').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_12" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_12" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_12" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_12" ] = '8'

	## adult_3_13
	source['a'] = source.filter(regex='Id10325').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_13" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_13" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_13" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_13" ] = '8'

	## adult_3_14
	source['a'] = source.filter(regex='Id10328').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_14" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_14" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_14" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_14" ] = '8'

	## adult_3_15
	source['a'] = source.filter(regex='Id10312').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_15" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_15" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_15" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_15" ] = '8'

	## adult_3_16
	source.loc[(source['adult_3_15'] == 1), 'adult_3_16'] = '5'


	## adult_3_16a
	source['adult_3_16a'] = source.filter(regex='Id10332')

	## adult_3_17
	source['a'] = source.filter(regex='Id10336').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_17" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_17" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_17" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_17" ] = '8'

	## adult_3_18
	source['a'] = source.filter(regex='Id10315').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_18" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_18" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_18" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_18" ] = '8'

	## adult_3_19
	source['a'] = source.filter(regex='Id10329').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_3_19" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_3_19" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_3_19" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_3_19" ] = '8'

	## adult_4_1
	source['a'] = source.filter(regex='Id10412').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_4_1" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_4_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_4_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_4_1" ] = '8'

	## adult_4_2
	source['a'] = source.filter(regex='Id10414').astype(str)
	source.loc[(source['a'] == 'cigarettes'), "adult_4_2" ] = '1'
	source.loc[(source['a'] == 'pipe'), "adult_4_2" ] = '2'
	source.loc[(source['a'] == 'chewing_tobacco'), "adult_4_2" ] = '3'
	source.loc[(source['a'] == 'local_form_of_tobacco'), "adult_4_2" ] = '4'
	source.loc[(source['a'] == 'other'), "adult_4_2" ] = '11'

	## adult_4_2a
	source['adult_4_2a'] = np.nan

	## adult_4_4
	source.loc[(source['adult_4_2a'] == 1), 'adult_4_4'] = '1'

	## adult_4_4a
	source['adult_4_4a'] = source.filter(regex='Id10415')

	## adult_6_1
	source['a'] = source.filter(regex='Id10432').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_6_1" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_6_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_6_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_6_1" ] = '8'

	## adult_6_2
	source['a'] = source.filter(regex='Id10433').astype(str)
	source.loc[(source['a'] == 'traditional_healer'), "adult_6_2" ] = '1'
	source.loc[(source['a'] == 'homeopath'), "adult_6_2" ] = '2'
	source.loc[(source['a'] == 'religious_leader'), "adult_6_2" ] = '3'
	source.loc[(source['a'] == 'government_hospital'), "adult_6_2" ] = '4'
	source.loc[(source['a'] == 'government_health_center_or_clinic'), "adult_6_2" ] = '5'
	source.loc[(source['a'] == 'private_hospital'), "adult_6_2" ] = '6'
	source.loc[(source['a'] == 'community_based_practitionerinsystem'), "adult_6_2" ] = '7'
	source.loc[(source['a'] == 'trained_birth_attendant'), "adult_6_2" ] = '8'
	source.loc[(source['a'] == 'private_physician'), "adult_6_2" ] = '9'
	source.loc[(source['a'] == 'pharmacy'), "adult_6_2" ] = '10'
	source.loc[(source['a'] == 'relative_friend'), "adult_6_2" ] = '12'
	source.loc[(source['a'] == 'dk'), "adult_6_2" ] = '99'
	source.loc[(source['a'] == 'ref'), "adult_6_2" ] = '88'

	## adult_6_3
	source['adult_6_3'] = source.filter(regex='Id10434')

	## adult_6_3a
	source['a'] = source.filter(regex='Id10435').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_6_3a" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_6_3a" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_6_3a" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_6_3a" ] = '8'

	## adult_6_3b
	source['adult_6_3b'] = source.filter(regex='Id10436')

	## adult_6_4
	source['a'] = source.filter(regex='Id10437').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_6_4" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_6_4" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_6_4" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_6_4" ] = '8'

	## adult_6_5
	source['a'] = source.filter(regex='Id10438').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_6_5" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_6_5" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_6_5" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_6_5" ] = '8'

	## adult_6_5c
	source['adult_6_5c'] = source.filter(regex='Id10444')

	## adult_6_6b
	source['a'] = source.filter(regex='Id10439')
	source['adult_6_6b'] = pd.to_datetime(source['a']).dt.year

	## adult_6_6c
	source['adult_6_6c'] = pd.to_datetime(source['a']).dt.month

	## adult_6_6d
	source['adult_6_6d'] = pd.to_datetime(source['a']).dt.day

	## adult_6_6f
	source['a'] = source.filter(regex='Id10440')
	source['adult_6_6f'] = pd.to_datetime(source['a']).dt.year

	## adult_6_6g
	source['adult_6_6g'] = pd.to_datetime(source['a']).dt.month

	## adult_6_6h
	source['adult_6_6h'] = pd.to_datetime(source['a']).dt.day

	## adult_6_7a
	source['a'] = source.filter(regex='Id10441')
	source['adult_6_7a'] = pd.to_datetime(source['a']).dt.year

	## adult_6_7b
	source['adult_6_7b'] = pd.to_datetime(source['a']).dt.month

	## adult_6_7c
	source['adult_6_7c'] = pd.to_datetime(source['a']).dt.day

	## adult_6_8
	source['adult_6_8'] = source.filter(regex='Id10444')

	## adult_6_9
	source['a'] = source.filter(regex='Id10462').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_6_9" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_6_9" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_6_9" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_6_9" ] = '8'

	## adult_6_10
	source['a'] = source.filter(regex='Id10463').astype(str)
	source.loc[(source['a'] == 'yes'), "adult_6_10" ] = '1'
	source.loc[(source['a'] == 'no'), "adult_6_10" ] = '0'
	source.loc[(source['a'] == 'dk'), "adult_6_10" ] = '9'
	source.loc[(source['a'] == 'ref'), "adult_6_10" ] = '8'

	## adult_6_11
	source['adult_6_11'] = source.filter(regex='Id10464')

	## adult_6_12
	source['adult_6_12'] = source.filter(regex='Id10466')

	## adult_6_13
	source['adult_6_13'] = source.filter(regex='Id10468')

	## adult_6_14
	source['adult_6_14'] = source.filter(regex='Id10470')

	## adult_6_15
	source['adult_6_15'] = source.filter(regex='Id10472')

	## adult_7_1
	source['a'] = source.filter(regex='Id10477').astype(str)
	source.loc[(source['a'].str.contains('Chronic Kidney Disease') == True), 'adult_7_1'] = '1'
	source.loc[(source['a'].str.contains('chronic kidney disease') == True), 'adult_7_1'] = '1'

	## adult_7_2
	source.loc[(source['a'].str.contains('Dialysis') == True), 'adult_7_2'] = '1'
	source.loc[(source['a'].str.contains('dialysis') == True), 'adult_7_2'] = '1'

	## adult_7_3
	source.loc[(source['a'].str.contains('Fever') == True), 'adult_7_3'] = '1'
	source.loc[(source['a'].str.contains('fever') == True), 'adult_7_3'] = '1'

	## adult_7_4
	source.loc[(source['a'].str.contains('Heart Attack') == True), 'adult_7_4'] = '1'
	source.loc[(source['a'].str.contains('heart attack') == True), 'adult_7_4'] = '1'

	## adult_7_5
	source.loc[(source['a'].str.contains('Heart Problems') == True), 'adult_7_5'] = '1'
	source.loc[(source['a'].str.contains('heart problems') == True), 'adult_7_5'] = '1'

	## adult_7_6
	source.loc[(source['a'].str.contains('Jaundice') == True), 'adult_7_6'] = '1'
	source.loc[(source['a'].str.contains('jaundice') == True), 'adult_7_6'] = '1'

	## adult_7_7
	source.loc[(source['a'].str.contains('Liver Failure') == True), 'adult_7_7'] = '1'
	source.loc[(source['a'].str.contains('liver failure') == True), 'adult_7_7'] = '1'

	## adult_7_8
	source.loc[(source['a'].str.contains('Malaria') == True), 'adult_7_8'] = '1'
	source.loc[(source['a'].str.contains('malaria') == True), 'adult_7_8'] = '1'

	## adult_7_9
	source.loc[(source['a'].str.contains('Pneumonia') == True), 'adult_7_9'] = '1'
	source.loc[(source['a'].str.contains('pneumonia') == True), 'adult_7_9'] = '1'

	## adult_7_10
	source.loc[(source['a'].str.contains('Renal kidney failure') == True), 'adult_7_10'] = '1'
	source.loc[(source['a'].str.contains('renal kidney failure') == True), 'adult_7_10'] = '1'

	## adult_7_11
	source.loc[(source['a'].str.contains('Suicide') == True), 'adult_7_11'] = '1'
	source.loc[(source['a'].str.contains('suicide') == True), 'adult_7_11'] = '1'

	## adult_7_99
	source.loc[(source['a'].str.contains('None') == True), 'adult_7_11'] = '1'
	source.loc[(source['a'].str.contains('none') == True), 'adult_7_11'] = '1'

	## child_4_47
	source['a'] = source.filter(regex='Id10077').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_47" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_47" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_47" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_47" ] = '8'

	## child_4_48 **
	source['child_4_48'] = np.nan

	## child_4_48a **
	source['child_4_48a'] = np.nan

	## child_4_49
	source['a'] = source.filter(regex='Id10098').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_49" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_49" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_49" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_49" ] = '8'

	## child_1_3
	source['a'] = source.filter(regex='Id10356').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_3" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_3" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_3" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_3" ] = '8'

	## child_1_4
	source['a'] = source.filter(regex='Id10357').astype(str)
	source.loc[(source['a'] == 'during_delivery'), "child_1_4" ] = '1'
	source.loc[(source['a'] == 'after_delivery'), "child_1_4" ] = '2'

	## child_1_5
	source.loc[(source['child_1_4'] == 2), 'child_1_5'] = '4'


	## child_1_5a
	source['a'] = source.filter(regex='Id10358')
	source['b'] = source.filter(regex='Id10359')
	source['child_1_5a'] = (source['a']*30.4) + (source['b'])

	## child_1_5b
	source['child_1_5b'] = source['a']

	## child_1_6
	source['a'] = source.filter(regex='Id10360').astype(str)
	source.loc[(source['a'] == 'hospital'), "child_1_6" ] = '1'
	source.loc[(source['a'] == 'other_health_facility'), "child_1_6" ] = '2'
	source.loc[(source['a'] == 'home'), "child_1_6" ] = '4'
	source.loc[(source['a'] == 'on_route_to_hospital_or_facility'), "child_1_6" ] = '3'
	source.loc[(source['a'] == 'other'), "child_1_6" ] = '5'
	source.loc[(source['a'] == 'DK'), "child_1_6" ] = '9'
	source.loc[(source['a'] == 'Ref'), "child_1_6" ] = '8'

	## child_1_6a
	source['child_1_6a'] = source.filter(regex='Id10360')

	## child_1_7
	source['a'] = source.filter(regex='Id10364').astype(str)
	source['b'] = source.filter(regex='Id10363').astype(str)
	source['c'] = source.filter(regex='Id10365').astype(str)
	source['child_1_7'] = '3'
	source.loc[source['a'] == 'yes', 'child_1_7'] = '1'
	source.loc[source['b'] == 'yes', 'child_1_7'] = '2'
	source.loc[source['c'] == 'yes', 'child_1_7'] = '3'

	## child_1_20
	source['child_1_20'] = '2'

	## child_1_20a
	source['child_1_20a'] = source.filter(regex='Id10351').astype(int)

	## child_1_20b
	source['child_1_20b'] = (source['child_1_20a'])/30

	## child_1_20c
	source['child_1_20c'] = source.filter(regex='Id10352')

	## child_1_21
	source['child_1_21'] = '3'

	## child_1_21a
	source['a'] = source.filter(regex='Id10121')
	source['b'] = source.filter(regex='Id10122')
	source['c'] = source.filter(regex='Id10120')
	source['child_1_21a'] = (source['a']*30.4) + (source['b']*7) + (source['c'])

	## child_1_21b
	source['child_1_21b'] = source['c']

	## child_1_25
	source['child_1_25'] = '3'


	## child_1_25a
	source['a'] = source.filter(regex='age_child_days')
	source['b'] = source.filter(regex='age_child_months')
	source['c'] = source.filter(regex='age_child_years')
	source['child_1_25a'] = source['a'] + source['b']*30.4 + source['c']*365

	## child_1_25b
	source['child_1_25b'] = source['b'] 

	## child_1_25c
	source['child_1_25c'] = source['c']

	## child_4_1
	source['a'] = source.filter(regex='Id10147').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_1" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_1" ] = '8'

	## child_4_2
	source['a'] = source.filter(regex='Id10148')
	source['child_4_2'] = '9'
	source.loc[source['a'] < 0, 'child_4_2'] = '1'
	source.loc[source['a'] >= 1, 'child_4_2'] = '2'


	## child_4_2a
	source['child_4_2a'] = source.filter(regex='Id10148')

	## child_4_3
	source['a'] = source.filter(regex='Id10149').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_3" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_3" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_3" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_3" ] = '8'

	## child_4_4
	source['a'] = source.filter(regex='Id10150').astype(str)
	source.loc[(source['a'] == 'mild'), "child_4_4" ] = '1'
	source.loc[(source['a'] == 'moderate'), "child_4_4" ] = '2'
	source.loc[(source['a'] == 'severe'), "child_4_4" ] = '3'

	## child_4_6
	source['a'] = source.filter(regex='Id10181').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_6" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_6" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_6" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_6" ] = '8'

	## child_4_7
	source['a'] = source.filter(regex='Id10183').astype(str)
	source.loc[(source['a'] !=np.nan), 'child_4_7'] ='1'
	source.loc[(source['a'] == 'dk'), 'child_4_7'] ='99'
	source.loc[(source['a'] == 'ref'), 'child_4_7'] ='88'

	## child_4_7a
	source['child_4_7a'] = source['a']

	## child_4_9
	source['a'] = source.filter(regex='Id10185').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_9" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_9" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_9" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_9" ] = '8'

	## child_4_12
	source['a'] = source.filter(regex='Id10153').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_12" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_12" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_12" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_12" ] = '8'

	## child_4_13
	source['a'] = source.filter(regex='Id10154').astype(str)
	source.loc[(source['a'] !=np.nan), 'child_4_13'] ='1'
	source.loc[(source['a'] == 'dk'), 'child_4_13'] ='9'
	source.loc[(source['a'] == 'ref'), 'child_4_13'] ='8'

	## child_4_13a
	source['child_4_13a'] = source['a']

	## child_4_14
	source['a'] = source.filter(regex='Id10156').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_14" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_14" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_14" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_14" ] = '8'

	## child_4_16
	source['a'] = source.filter(regex='Id10159').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_16" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_16" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_16" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_16" ] = '8'

	## child_4_17
	source['a'] = source.filter(regex='Id10161').astype(str)
	source.loc[(source['a'] !=np.nan), 'child_4_17'] ='1'
	source.loc[(source['a'] == 'dk'), 'child_4_17'] ='9'
	source.loc[(source['a'] == 'ref'), 'child_4_17'] ='8'

	## child_4_17a
	source['child_4_17a'] = source['a']

	## child_4_18
	source['a'] = source.filter(regex='Id10166').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_18" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_18" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_18" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_18" ] = '8'

	## child_4_19
	source['a'] = source.filter(regex='Id10167').astype(str)
	source.loc[(source['a'] !=np.nan), 'child_4_19'] ='1'
	source.loc[(source['a'] == 'dk'), 'child_4_19'] ='9'
	source.loc[(source['a'] == 'ref'), 'child_4_19'] ='8'

	## child_4_19a
	source['child_4_19a'] = source['a']

	## child_4_20
	source['a'] = source.filter(regex='Id10172').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_20" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_20" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_20" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_20" ] = '8'

	## child_4_23
	source['a'] = source.filter(regex='Id10173').astype(str)
	source['child_4_23'] = '0'
	source.loc[(source['a'].str.contains('grunting') == True), 'child_4_23'] = '1'

	## child_4_25
	source['a'] = source.filter(regex='Id10220').astype(str)
	source['b'] = source.filter(regex='Id10219')
	source.loc[source['b'] == 'no', "child_4_25" ] = '0'
	source.loc[(source['a'] == 'yes'), "child_4_25" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_25" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_25" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_25" ] = '8'

	## child_4_26
	source['a'] = source.filter(regex='Id10214').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_26" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_26" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_26" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_26" ] = '8'

	## child_4_27
	source['child_4_27'] = source.filter(regex='Id10216')

	## child_4_28
	source['a'] = source.filter(regex='Id10208').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_28" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_28" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_28" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_28" ] = '8'

	## child_4_29
	source['a'] = source.filter(regex='Id10278').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_29" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_29" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_29" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_29" ] = '8'

	## child_4_30
	source['a'] = source.filter(regex='Id10233').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_30" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_30" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_30" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_30" ] = '8'

	## child_4_33
	source['a'] = source.filter(regex='Id10234').astype(str)
	source.loc[(source['a'] !=np.nan), 'child_4_33'] ='1'
	source.loc[(source['a'] == 'dk'), 'child_4_33'] ='9'
	source.loc[(source['a'] == 'ref'), 'child_4_33'] ='8'

	## child_4_33a
	source.loc[(source['regex=Id'] == ''), 'child_4_33a'] = ''
	source['child_4_33a'] = source['a']

	## child_4_38
	source['a'] = source.filter(regex='Id10238').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_38" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_38" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_38" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_38" ] = '8'

	## child_4_39
	source['a'] = source.filter(regex='Id10267').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_39" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_39" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_39" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_39" ] = '8'

	## child_4_40
	source['a'] = source.filter(regex='Id10200').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_40" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_40" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_40" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_40" ] = '8'

	## child_4_41
	source['a'] = source.filter(regex='Id10268').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_41" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_41" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_41" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_41" ] = '8'

	## child_4_42
	source['a'] = source.filter(regex='Id10256').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_42" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_42" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_42" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_42" ] = '8'

	## child_4_44
	source['a'] = source.filter(regex='Id10241').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_44" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_44" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_44" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_44" ] = '8'

	## child_4_46
	source['a'] = source.filter(regex='Id10239').astype(str)
	source.loc[(source['a'] == 'yes'), "child_4_46" ] = '1'
	source.loc[(source['a'] == 'no'), "child_4_46" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_4_46" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_4_46" ] = '8'

	## child_5_0a
	source['a'] = source.filter(regex='Id10435').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_0a" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_0a" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_0a" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_0a" ] = '8'

	## child_5_0b
	source['child_5_0b'] = source.filter(regex='Id10436')


	## child_5_1
	source['a'] = source.filter(regex='Id10432').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_1" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_1" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_1" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_1" ] = '8'

	## child_5_2
	source['a'] = source.filter(regex='Id10433').astype(str)
	source.loc[(source['a'] == 'traditional_healer'), "child_5_2" ] = '1'
	source.loc[(source['a'] == 'homeopath'), "child_5_2" ] = '2'
	source.loc[(source['a'] == 'religious_leader'), "child_5_2" ] = '3'
	source.loc[(source['a'] == 'government_hospital'), "child_5_2" ] = '4'
	source.loc[(source['a'] == 'government_health_center_or_clinic'), "child_5_2" ] = '5'
	source.loc[(source['a'] == 'private_hospital'), "child_5_2" ] = '6'
	source.loc[(source['a'] == 'community_based_practitionerinsystem'), "child_5_2" ] = '7'
	source.loc[(source['a'] == 'trained_birth_attendant'), "child_5_2" ] = '8'
	source.loc[(source['a'] == 'private_physician'), "child_5_2" ] = '19'
	source.loc[(source['a'] == 'pharmacy'), "child_5_2" ] = '10'
	source.loc[(source['a'] == 'relative_friend'), "child_5_2" ] = '12'
	source.loc[(source['a'] == 'dk'), "child_5_2" ] = '99'
	source.loc[(source['a'] == 'ref'), "child_5_2" ] = '88'

	## child_5_3
	source['child_5_3'] = source.filter(regex='Id10434')

	## child_5_4
	source['a'] = source.filter(regex='Id10437').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_4" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_4" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_4" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_4" ] = '8'

	## child_5_5
	source['a'] = source.filter(regex='Id10438').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_5" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_5" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_5" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_5" ] = '8'

	## child_5_6b
	source['a'] = source.filter(regex='Id10439')
	source['child_5_6b'] = pd.to_datetime(source['a']).dt.year

	## child_5_6c
	source['child_5_6c'] = pd.to_datetime(source['a']).dt.month

	## child_5_6d
	source['child_5_6d'] = pd.to_datetime(source['a']).dt.day

	## child_5_7b
	source['a'] = source.filter(regex='Id10440')
	source['child_5_7b'] = pd.to_datetime(source['a']).dt.year

	## child_5_7c
	source['child_5_7c'] = pd.to_datetime(source['a']).dt.month

	## child_5_7d
	source['child_5_7d'] = pd.to_datetime(source['a']).dt.day

	## child_5_6f
	source['child_5_6f'] = source.filter(regex='Id10442')

	## child_5_7f
	source['child_5_7f'] = source.filter(regex='Id10443')

	## child_5_8a
	source['a'] = source.filter(regex='Id10441')
	source['child_5_8a'] = pd.to_datetime(source['a']).dt.year

	## child_5_8b
	source['child_5_8b'] = pd.to_datetime(source['a']).dt.month

	## child_5_8c
	source['child_5_8c'] = pd.to_datetime(source['a']).dt.day

	## child_5_9
	source['child_5_9'] = source.filter(regex='Id10443')

	## child_5_10
	source['a'] = source.filter(regex='Id10462').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_10" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_10" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_10" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_10" ] = '8'

	## child_5_11
	source['a'] = source.filter(regex='Id10463').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_11" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_11" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_11" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_11" ] = '8'

	## child_5_12
	source['child_5_12'] = source.filter(regex='Id10464')

	## child_5_13
	source['child_5_13'] = source.filter(regex='Id10466')

	## child_5_14
	source['child_5_14'] = source.filter(regex='Id10468')

	## child_5_15
	source['child_5_15'] = source.filter(regex='Id10470')

	## child_5_16
	source['child_5_16'] = source.filter(regex='Id10472')

	## child_5_17
	source['a'] = source.filter(regex='Id10445').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_17" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_17" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_17" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_17" ] = '8'


	## child_5_18
	source['a'] = source.filter(regex='Id10126').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_18" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_18" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_18" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_18" ] = '8'

	## child_5_19
	source['a'] = source.filter(regex='Id10446').astype(str)
	source.loc[(source['a'] == 'yes'), "child_5_19" ] = '1'
	source.loc[(source['a'] == 'no'), "child_5_19" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_5_19" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_5_19" ] = '8'

	## child_6_1
	source['a'] = source.filter(regex='Id10478').astype(str)
	source.loc[(source['a'].str.contains('abdomen') == True), 'child_6_1'] = '1'

	## child_6_2
	source.loc[(source['a'].str.contains('cancer') == True), 'child_6_2'] = '1'

	## child_6_3
	source.loc[(source['a'].str.contains('dehydration') == True), 'child_6_3'] = '1'


	## child_6_4
	source.loc[(source['a'].str.contains('dengue') == True), 'child_6_4'] = '1'


	## child_6_5
	source.loc[(source['a'].str.contains('diarrhea') == True), 'child_6_5'] = '1'


	## child_6_6
	source.loc[(source['a'].str.contains('fever') == True), 'child_6_6'] = '1'


	## child_6_7
	source.loc[(source['a'].str.contains('heart_problem') == True), 'child_6_7'] = '1'


	## child_6_8
	source.loc[(source['a'].str.contains('jaundice') == True), 'child_6_8'] = '1'


	## child_6_9
	source.loc[(source['a'].str.contains('pneumonia') == True), 'child_6_9'] = '1'


	## child_6_10
	source.loc[(source['a'].str.contains('rash') == True), 'child_6_10'] = '1'


	## child_6_99
	source.loc[(source['a'].str.contains('None') == True), 'child_6_99'] = '1'


	## child_1_3
	source['a'] = source.filter(regex='Id10356').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_3" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_3" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_3" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_3" ] = '8'

	## child_1_8
	source['child_1_8'] = '1'


	## child_1_8a
	source['child_1_8a'] = source.filter(regex='Id10366')

	## child_1_8b
	source['child_1_8b'] = np.nan

	## child_1_7
	source['a'] = source.filter(regex='Id10364')
	source['b'] = source.filter(regex='Id10363')
	source['c'] = source.filter(regex='Id10365')
	source['child_1_7'] = '3'
	source.loc[source['a'] == 'yes', 'child_1_7'] = '1'
	source.loc[source['b'] == 'yes', 'child_1_7'] = '2'
	source.loc[source['c'] == 'yes', 'child_1_7'] = '4'

	## child_1_11
	source['a'] = source.filter(regex='Id10114').astype(str)
	source['b'] = source.filter(regex='Id10104').astype(str)
	source['c'] = source.filter(regex='Id10109').astype(str)
	source['d'] = source.filter(regex='Id10110').astype(str)
	source['child_1_11'] = '9'
	source.loc[source['a'] == 'yes', 'child_1_11'] = '2'
	source.loc[(source['b'] != 'no')|(source['c'] != 'no')|(source['d'] != 'no')|(source['a'] == 'no'), 'child_1_11'] = '1'

	## child_1_12
	source['a'] = source.filter(regex='Id10104').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_12" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_12" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_12" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_12" ] = '8'

	## child_1_13
	source['a'] = source.filter(regex='Id10109').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_13" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_13" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_13" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_13" ] = '8'

	## child_1_14
	source['a'] = source.filter(regex='Id10110').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_14" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_14" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_14" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_14" ] = '8'

	## child_1_15
	source['child_1_15'] = '0'
	source.loc[(source['child_1_12'] == 0) & (source['child_1_13'] == 0) & (source['child_1_14'] == 0), 'child_1_15'] = '1'

	## child_1_16
	source['a'] = source.filter(regex='Id10115').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_16" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_16" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_16" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_16" ] = '8'

	## child_1_17
	source['a'] = source.filter(regex='Id10116').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_17" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_17" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_17" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_17" ] = '8'

	## child_1_18
	source['a'] = source.filter(regex='Id10370').astype(str)
	source.loc[(source['a'] == 'yes'), "child_1_18" ] = '1'
	source.loc[(source['a'] == 'no'), "child_1_18" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_1_18" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_1_18" ] = '8'

	## child_1_19
	source['a'] = source.filter(regex='Id10373').astype(str)
	source['b'] = source.filter(regex='Id10372').astype(str)
	source['c'] = source.filter(regex='Id10371').astype(str)
	source.loc[source['a'] == 'yes', 'child_1_19'] = '1'
	source.loc[source['b'] == 'yes', 'child_1_19'] = '2'
	source.loc[source['c'] == 'yes', 'child_1_19'] = '3'

	## child_1_19a
	source['child_1_19a'] = np.nan

	## child_1_26
	source['child_1_26'] = source.filter(regex='age_neonate_days')

	## child_2_1
	source['a'] = source.filter(regex='Id10399').astype(str)
	source['b'] = source.filter(regex='Id10396').astype(str)
	source['c'] = source.filter(regex='Id10401').astype(str)
	source['d'] = source.filter(regex='Id10397').astype(str)
	source['e'] = source.filter(regex='Id10403').astype(str)
	source['f'] = source.filter(regex='Id10405').astype(str)
	source['g'] = source.filter(regex='Id10404').astype(str)
	source['h'] = source.filter(regex='Id10402').astype(str)
	source['i'] = source.filter(regex='Id10395').astype(str)
	source.loc[source['a'] == 'yes', 'child_2_1'] = '1'
	source.loc[source['b'] == 'yes', 'child_2_1'] = '2'
	source.loc[source['c'] == 'yes', 'child_2_1'] = '3'
	source.loc[source['d'] == 'yes', 'child_2_1'] = '4'
	source.loc[source['e'] == 'yes', 'child_2_1'] = '5'
	source.loc[source['f'] == 'yes', 'child_2_1'] = '6'
	source.loc[source['g'] == 'yes', 'child_2_1'] = '7'
	source.loc[source['h'] == 'yes', 'child_2_1'] = '8'
	source.loc[source['i'] == 'yes', 'child_2_1'] = '9'

	## child_2_4
	source['a'] = source.filter(regex='Id10377').astype(str)
	source.loc[(source['a'] == 'yes'), "child_2_4" ] = '1'
	source.loc[(source['a'] == 'no'), "child_2_4" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_2_4" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_2_4" ] = '8'

	## child_2_8
	source['a'] = source.filter(regex='Id10385').astype(str)
	source.loc[(source['a'] == 'green_or_brown'), "child_2_8" ] = '1'
	source.loc[(source['a'] == 'clear'), "child_2_8" ] = '2'
	source.loc[(source['a'] == 'other'), "child_2_8" ] = '3'
	source.loc[(source['a'] == 'dk'), "child_2_8" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_2_8" ] = '8'

	## child_2_8a
	source['child_2_8a'] = source.filter(regex='Id10385')

	## child_2_10
	source['child_2_10'] = '5'


	## child_2_10a
	source['a'] = source.filter(regex='Id10382').astype(str)
	source.loc[source['a'] != np.nan, 'child_2_10a'] = source['a']
	source.loc[source['a'] == np.nan, 'child_2_10a'] = '99'

	## child_2_15
	source['a'] = source.filter(regex='Id10339').astype(str)
	source.loc[(source['a'] == 'Doctor'), "child_2_15" ] = '1'
	source.loc[(source['a'] == 'Midwife'), "child_2_15" ] = '2'
	source.loc[(source['a'] == 'Nurse'), "child_2_15" ] = '2'
	source.loc[(source['a'] == 'Relative'), "child_2_15" ] = '3'
	source.loc[(source['a'] == 'Self_mother'), "child_2_15" ] = '4'
	source.loc[(source['a'] == 'Traditional_birth_attendant'), "child_2_15" ] = '5'
	source.loc[(source['a'] == 'Other'), "child_2_15" ] = '6'
	source.loc[(source['a'] == 'DK'), "child_2_15" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_2_15" ] = '8'

	## child_2_15a
	source['child_2_15a'] = source.filter(regex='Id10339')

	## child_2_17
	source['child_2_17'] = '9'
	source.loc[source['a'] == 'yes', 'child_2_17'] = '2'
	source.loc[source['b'] == 'yes', 'child_2_17'] = '1'
	source.loc[source['c'] == 'yes', 'child_2_17'] = '4'

	## child_3_2
	source['a'] = source.filter(regex='Id10370').astype(str)
	source.loc[(source['a'] == 'yes'), "child_3_2" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_2" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_2" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_2" ] = '8'

	## child_3_3
	source['a'] = source.filter(regex='Id10373').astype(str)
	source['b'] = source.filter(regex='Id10372').astype(str)
	source['c'] = source.filter(regex='Id10371').astype(str)
	source.loc[source['a'] == 'yes', 'child_3_3'] = '1'
	source.loc[source['b'] == 'yes', 'child_3_3'] = '2'
	source.loc[source['c'] == 'yes', 'child_3_3'] = '3'

	## child_3_3a
	source['child_3_3a'] = np.nan

	## child_3_4
	source['a'] = source.filter(regex='Id10110').astype(str)
	source['b'] = source.filter(regex='Id10111').astype(str)
	source.loc[source['a'] == 'no', 'child_3_4'] = '0'
	source.loc[(source['b'] == 'yes'), "child_3_4" ] = '1'
	source.loc[(source['b'] == 'no'), "child_3_4" ] = '0'
	source.loc[(source['b'] == 'dk'), "child_3_4" ] = '9'
	source.loc[(source['b'] == 'ref'), "child_3_4" ] = '8'

	## child_3_5
	source['a'] = source.filter(regex='Id10112').astype(str)
	source.loc[(source['a'] == 'yes'), "child_3_5" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_5" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_5" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_5" ] = '8'

	## child_3_6
	source['a'] = source.filter(regex='Id10110').astype(str)
	source['b'] = source.filter(regex='Id10113').astype(str)
	source.loc[source['a'] == 'no', 'child_3_6'] = '0'
	source.loc[(source['b'] == 'yes'), "child_3_6" ] = '1'
	source.loc[(source['b'] == 'no'), "child_3_6" ] = '0'
	source.loc[(source['b'] == 'dk'), "child_3_6" ] = '9'
	source.loc[(source['b'] == 'ref'), "child_3_6" ] = '8'

	## child_3_7
	source['a'] = source.filter(regex='Id10104').astype(str)
	source['b'] = source.filter(regex='Id10105').astype(str)
	source.loc[source['a'] == 'no', 'child_3_7'] = '0'
	source.loc[(source['b'] == 'yes'), "child_3_7" ] = '1'
	source.loc[(source['b'] == 'no'), "child_3_7" ] = '0'
	source.loc[(source['b'] == 'dk'), "child_3_7" ] = '9'
	source.loc[(source['b'] == 'ref'), "child_3_7" ] = '8'

	## child_3_8
	source['a'] = source.filter(regex='Id10106')
	source['child_3_8'] = '9'
	source.loc[source['a'] <= 5, 'child_3_8'] = '1'
	source.loc[(source['a'] > 5) & (source['a'] <=30), 'child_3_8'] = '2'
	source.loc[(source['a'] > 30) & (source['a'] <=998), 'child_3_8'] = '3'
	source.loc[source['a'] > 999, 'child_3_8'] = '4'

	## child_3_9
	source['a'] = source.filter(regex='Id10107').astype(str)
	source.loc[(source['a'] == 'yes'), "child_3_9" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_9" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_9" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_9" ] = '8'

	## child_3_11
	source['a'] = source.filter(regex='Id10271').astype(str)
	source.loc[(source['a'] == 'yes'), "child_3_11" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_11" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_11" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_11" ] = '8'

	## child_3_12
	source['a'] = source.filter(regex='Id10272').astype(str)
	source.loc[(source['a'] == 'yes'), "child_3_12" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_12" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_12" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_12" ] = '8'

	## child_3_17
	source['a'] = source.filter(regex='Id10159').astype(str)
	source.loc[(source['a'] == 'yes'), "child_3_17" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_17" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_17" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_17" ] = '8'

	## child_3_19
	source['child_3_19'] = '4'

	## child_3_19a
	source['child_3_19a'] = source.filter(regex='Id10161')

	## child_3_20
	source['a'] = source.filter(regex='Id10166')
	source.loc[(source['a'] == 'yes'), "child_3_20" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_20" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_20" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_20" ] = '8'

	## child_3_22
	source['child_3_22'] = '4'


	## child_3_22a
	source['child_3_22a'] = source.filter(regex='Id10167')

	## child_3_23
	source['a'] = source.filter(regex='Id10172')
	source.loc[(source['a'] == 'yes'), "child_3_23" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_23" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_23" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_23" ] = '8'

	## child_3_29
	source['a'] = source.filter(regex='Id10284')
	source.loc[(source['a'] == 'yes'), "child_3_29" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_29" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_29" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_29" ] = '8'

	## child_3_30
	source['child_3_30'] = '4'

	## child_3_30a
	source['child_3_30a'] = source.filter(regex='Id10285')

	## child_3_32
	source['a'] = source.filter(regex='Id10286')
	source.loc[(source['a'] == 'yes'), "child_3_32" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_32" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_32" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_32" ] = '8'

	## child_3_33
	source['a'] = source.filter(regex='Id10281')
	source.loc[(source['a'] == 'yes'), "child_3_33" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_33" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_33" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_33" ] = '8'

	## child_3_35
	source['a'] = source.filter(regex='Id10287')
	source.loc[(source['a'] == 'yes'), "child_3_35" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_35" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_35" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_35" ] = '8'

	## child_3_40
	source['a'] = source.filter(regex='Id10240')
	source.loc[(source['a'] == 'yes'), "child_3_40" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_40" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_40" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_40" ] = '8'

	## child_3_47
	source['a'] = source.filter(regex='Id10289')
	source.loc[(source['a'] == 'yes'), "child_3_47" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_47" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_47" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_47" ] = '8'

	## child_3_49
	source['a'] = source.filter(regex='Id10290')
	source.loc[(source['a'] == 'yes'), "child_3_49" ] = '1'
	source.loc[(source['a'] == 'no'), "child_3_49" ] = '0'
	source.loc[(source['a'] == 'dk'), "child_3_49" ] = '9'
	source.loc[(source['a'] == 'ref'), "child_3_49" ] = '8'

	## neonate_6_1
	source.loc[(source['a'].str.contains('asphyxia') == True), 'neonate_6_1'] = '1'

	## neonate_6_2
	source.loc[(source['a'].str.contains('incubator') == True), 'neonate_6_2'] = '1'

	## neonate_6_3
	source.loc[(source['a'].str.contains('lung_problem') == True), 'neonate_6_3'] = '1'

	## neonate_6_4
	source.loc[(source['a'].str.contains('pneumonia') == True), 'neonate_6_3'] = '1'

	## neonate_6_5
	source.loc[(source['a'].str.contains('preterm_delivery') == True), 'neonate_6_3'] = '1'

	## neonate_6_6
	source.loc[(source['a'].str.contains('respiratory_distress') == True), 'neonate_6_3'] = '1'

	## neonate_6_99
	source.loc[(source['a'].str.contains('None') == True), 'neonate_6_3'] = '1'

	out = source['sid', 'gen_2_4', 'gen_3_1', 'gen_5_0', 'gen_5_1a', 'gen_5_1b',
       'gen_5_1c', 'gen_5_2', 'gen_5_3a', 'gen_5_3b', 'gen_5_3c',
       'gen_5_4', 'gen_5_4a', 'gen_5_4b', 'gen_5_4c', 'gen_5_4d',
       'gen_5_5', 'gen_5_2b', 'gen_6_1', 'gen_6_2b', 'gen_6_2c',
       'gen_6_2d', 'gen_6_3', 'gen_6_4', 'gen_6_5', 'gen_6_6', 'gen_6_7',
       'gen_6_8', 'gen_6_9', 'gen_6_10', 'adult_5_1', 'adult_5_2',
       'adult_5_2a', 'adult_5_3', 'adult_5_4', 'adult_1_1', 'adult_1_1a',
       'adult_1_1c', 'adult_1_1m', 'adult_1_1g', 'adult_1_1h',
       'adult_1_1i', 'adult_1_1d', 'adult_1_1l', 'adult_1_1n', 'adult_2_2',
       'adult_2_4', 'adult_2_5', 'adult_2_7', 'adult_2_9', 'adult_2_10',
       'adult_2_11', 'adult_2_13', 'adult_2_14', 'adult_2_15',
       'adult_2_15a', 'adult_2_21', 'adult_2_22', 'adult_2_22a',
       'adult_2_22b', 'adult_2_25', 'adult_2_26', 'adult_2_26a',
       'adult_2_26b', 'adult_2_27', 'adult_2_29', 'adult_2_30',
       'adult_2_31', 'adult_2_32', 'adult_2_34', 'adult_2_35',
       'adult_2_36', 'adult_2_43', 'adult_2_44', 'adult_2_47',
       'adult_2_50', 'adult_2_51', 'adult_2_52', 'adult_2_53',
       'adult_2_55', 'adult_2_56', 'adult_2_57', 'adult_2_58',
       'adult_2_58a', 'adult_2_58b', 'adult_2_59', 'adult_2_60',
       'adult_2_61', 'adult_2_62', 'adult_2_62a', 'adult_2_62b',
       'adult_2_62c', 'adult_2_63', 'adult_2_64', 'adult_2_65',
       'adult_2_65a', 'adult_2_65b', 'adult_2_66', 'adult_2_67',
       'adult_2_68', 'adult_2_68a', 'adult_2_68b', 'adult_2_72',
       'adult_2_73', 'adult_2_73a', 'adult_2_73b', 'adult_2_74',
       'adult_2_75', 'adult_2_77', 'adult_2_82', 'adult_2_83',
       'adult_2_83a', 'adult_2_83b', 'adult_2_84', 'adult_2_85',
       'adult_2_87', 'adult_2_87a', 'adult_3_1', 'adult_3_2', 'adult_3_3a',
       'adult_3_3', 'adult_3_4', 'adult_3_5', 'adult_3_6', 'adult_3_7',
       'adult_3_8', 'adult_3_8a', 'adult_3_9', 'adult_3_10', 'adult_3_11',
       'adult_3_11a', 'adult_3_12', 'adult_3_13', 'adult_3_14',
       'adult_3_15', 'adult_3_16', 'adult_3_16a', 'adult_3_17',
       'adult_3_18', 'adult_3_19', 'adult_4_1', 'adult_4_2', 'adult_4_2a',
       'adult_4_4', 'adult_4_4a', 'adult_6_1', 'adult_6_2', 'adult_6_3',
       'adult_6_3a', 'adult_6_3b', 'adult_6_4', 'adult_6_5', 'adult_6_5c',
       'adult_6_6b', 'adult_6_6c', 'adult_6_6d', 'adult_6_6f',
       'adult_6_6g', 'adult_6_6h', 'adult_6_7a', 'adult_6_7b',
       'adult_6_7c', 'adult_6_8', 'adult_6_9', 'adult_6_10', 'adult_6_11',
       'adult_6_12', 'adult_6_13', 'adult_6_14', 'adult_6_15', 'adult_7_1',
       'adult_7_2', 'adult_7_3', 'adult_7_4', 'adult_7_5', 'adult_7_6',
       'adult_7_7', 'adult_7_8', 'adult_7_9', 'adult_7_10', 'adult_7_11',
       'adult_7_99', 'child_4_47', 'child_4_48', 'child_4_48a',
       'child_4_49', 'child_1_3', 'child_1_4', 'child_1_5', 'child_1_5a',
       'child_1_5b', 'child_1_6', 'child_1_6a', 'child_1_7', 'child_1_20',
       'child_1_20a', 'child_1_20b', 'child_1_20c', 'child_1_21',
       'child_1_21a', 'child_1_21b', 'child_1_25', 'child_1_25a',
       'child_1_25b', 'child_1_25c', 'child_4_1', 'child_4_2',
       'child_4_2a', 'child_4_3', 'child_4_4', 'child_4_6', 'child_4_7',
       'child_4_7a', 'child_4_9', 'child_4_12', 'child_4_13',
       'child_4_13a', 'child_4_14', 'child_4_16', 'child_4_17',
       'child_4_17a', 'child_4_18', 'child_4_19', 'child_4_19a',
       'child_4_20', 'child_4_23', 'child_4_25', 'child_4_26',
       'child_4_27', 'child_4_28', 'child_4_29', 'child_4_30',
       'child_4_33', 'child_4_33a', 'child_4_38', 'child_4_39',
       'child_4_40', 'child_4_41', 'child_4_42', 'child_4_44',
       'child_4_46', 'child_5_0a', 'child_5_0b', 'child_5_1', 'child_5_2',
       'child_5_3', 'child_5_4', 'child_5_5', 'child_5_6b', 'child_5_6c',
       'child_5_6d', 'child_5_7b', 'child_5_7c', 'child_5_7d',
       'child_5_6f', 'child_5_7f', 'child_5_8a', 'child_5_8b',
       'child_5_8c', 'child_5_9', 'child_5_10', 'child_5_11', 'child_5_12',
       'child_5_13', 'child_5_14', 'child_5_15', 'child_5_16',
       'child_5_17', 'child_5_18', 'child_5_19', 'child_6_1', 'child_6_2',
       'child_6_3', 'child_6_4', 'child_6_5', 'child_6_6', 'child_6_7',
       'child_6_8', 'child_6_9', 'child_6_10', 'child_6_99', 'child_1_3',
       'child_1_8', 'child_1_8a', 'child_1_8b', 'child_1_7', 'child_1_11',
       'child_1_12', 'child_1_13', 'child_1_14', 'child_1_15',
       'child_1_16', 'child_1_17', 'child_1_18', 'child_1_19',
       'child_1_19a', 'child_1_20', 'child_1_20a', 'child_1_20b',
       'child_1_21', 'child_1_21a', 'child_1_21b', 'child_1_26',
       'child_2_1', 'child_2_4', 'child_2_8', 'child_2_8a', 'child_2_10',
       'child_2_10a', 'child_2_15', 'child_2_15a', 'child_2_17',
       'child_3_2', 'child_3_3', 'child_3_3a', 'child_3_4', 'child_3_5',
       'child_3_6', 'child_3_7', 'child_3_8', 'child_3_9', 'child_3_11',
       'child_3_12', 'child_3_17', 'child_3_19', 'child_3_19a',
       'child_3_20', 'child_3_22', 'child_3_22a', 'child_3_23',
       'child_3_29', 'child_3_30', 'child_3_30a', 'child_3_32',
       'child_3_33', 'child_3_35', 'child_3_40', 'child_3_47',
       'child_3_49', 'child_5_0a', 'child_5_0b', 'child_5_1', 'child_5_2',
       'child_5_3', 'child_5_4', 'child_5_5', 'child_5_6b', 'child_5_6c',
       'child_5_6d', 'child_5_7b', 'child_5_7c', 'child_5_7d',
       'child_5_6f', 'child_5_7f', 'child_5_8a', 'child_5_8b',
       'child_5_8c', 'child_5_9', 'child_5_10', 'child_5_11', 'child_5_12',
       'child_5_13', 'child_5_14', 'child_5_15', 'child_5_16',
       'neonate_6_1', 'neonate_6_2', 'neonate_6_3', 'neonate_6_4',
       'neonate_6_5', 'neonate_6_6', 'neonate_6_99']

out.index = range(1, len(out)+1)
out.to_csv(final, index_label='ID')

